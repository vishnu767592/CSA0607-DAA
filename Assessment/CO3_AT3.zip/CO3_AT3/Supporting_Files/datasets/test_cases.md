# Test cases used by the programs

| Module | Test | Expected |
|---|---|---|
| 1 | Sample orders sorted by timestamp | 101/O4, 102/O2, 102/O5, 103/O6, 105/O1, 105/O3 (stable) |
| 1 | 20,000 random orders with many equal timestamps | identical to Python's stable `sorted` |
| 1 | External merge sort of 100,000 orders in 10 runs | identical to in-memory stable result |
| 2 | Sample scores 42,17,63,8,55,29 | 8,17,29,42,55,63; first partition leaves pivot 42 at index 3 |
| 2 | Sorted, reverse, random, nearly sorted, all-equal arrays | match `sorted` |
| 3 | Key 102 in sorted sample | first index 1 (order O2) |
| 3 | Missing key, empty array, single element, all equal | -1 / index 0 as appropriate |
| 3 | 1,000 random arrays vs `bisect_left` | same index everywhere |
| 4 | A x B for the 2x2 sample | [[50,38],[38,34]] |
| 4 | Random 8x8..128x128, and 100x100 (padding) | equal to conventional product |
