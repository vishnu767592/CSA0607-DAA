"""Final comparison chart: work BEFORE (current / naive) vs AFTER (proposed design) for the production workloads."""
import math
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

OUT = Path(__file__).resolve().parents[2] / "Final_Design_and_Analysis"
n1, n2, n3 = 10_000_000, 100_000, 10_000_000
L = math.ceil(math.log2(n1))
before = [n1 * n1 // 2, n2 * (n2 - 1) // 2, n3, 1024 ** 3 + 1024 ** 2 * 1023]
after = [n1 * L - 2 ** L + 1, 2 * n2 * math.log(n2), math.floor(math.log2(n3)) + 1, 629_407_744 + 672_288_768]
labels = ["M1 Sort 10M orders\n(n^2 sort -> Merge Sort)", "M2 Sort 100k scores\n(first pivot -> median-of-3)",
          "M3 Lookup in 10M orders\n(linear -> binary)", "M4 Multiply 1024x1024\n(conventional -> hybrid Strassen)"]
x = range(4); w = 0.38
fig, ax = plt.subplots(figsize=(9, 5))
ax.bar([i - w / 2 for i in x], before, w, label="before / naive", color="#C0504D")
ax.bar([i + w / 2 for i in x], after, w, label="proposed design", color="#4F81BD")
ax.set_yscale("log"); ax.set_xticks(list(x)); ax.set_xticklabels(labels, fontsize=8)
ax.set_ylabel("basic operations (log scale)"); ax.set_title("KartIQ: work per run before and after redesign")
for i in x:
    ax.text(i - w / 2, before[i], f"{before[i]:.1e}", ha="center", va="bottom", fontsize=7)
    ax.text(i + w / 2, after[i], f"{after[i]:.1e}", ha="center", va="bottom", fontsize=7)
ax.legend(); ax.grid(alpha=.3, axis="y", which="both"); plt.tight_layout()
plt.savefig(OUT / "before_vs_after.png", dpi=150)
print("Saved Final_Design_and_Analysis/before_vs_after.png")
