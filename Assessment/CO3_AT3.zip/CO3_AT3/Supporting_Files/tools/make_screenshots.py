"""Renders every source file and every execution output as a PNG 'screenshot' (syntax-highlighted)."""
import html
from pathlib import Path
from playwright.sync_api import sync_playwright
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import PythonLexer, TextLexer

ROOT = Path(__file__).resolve().parents[2]
fmt = HtmlFormatter(style="default", noclasses=True, linenos="inline")
jobs = []
for mod in ROOT.glob("Module_*"):
    for py in (mod / "Source_Code").glob("*.py"):
        jobs.append((py, mod / "Report" / "screenshots" / f"source_{py.stem}.png", PythonLexer(), py.name))
    out = mod / "Report" / "execution_output.txt"
    if out.exists():
        jobs.append((out, mod / "Report" / "screenshots" / "program_output.png", TextLexer(), "program output"))

with sync_playwright() as p:
    b = p.chromium.launch(); page = b.new_page(viewport={"width": 1150, "height": 600}, device_scale_factor=1.5)
    for src, dst, lexer, title in jobs:
        dst.parent.mkdir(exist_ok=True)
        body = highlight(src.read_text(encoding="utf8"), lexer, fmt)
        page.set_content(f"""<html><body style="margin:0;background:#fff;font-family:Consolas,'DejaVu Sans Mono',monospace;font-size:13px">
        <div style="background:#2d2d2d;color:#eee;padding:6px 12px;font-family:Arial;font-size:13px">{html.escape(title)}</div>
        <div style="padding:8px 12px">{body}</div></body></html>""")
        page.screenshot(path=str(dst), full_page=True)
        print("screenshot:", dst.relative_to(ROOT))
    b.close()
