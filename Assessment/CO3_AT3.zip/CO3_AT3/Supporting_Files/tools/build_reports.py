from pathlib import Path
R = Path(__file__).resolve().parents[2]
def out(mod): return (R/mod/'Report'/'execution_output.txt').read_text()

M1 = f'''# Module 1 – Merge Sort for Nightly Order Consolidation

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Sort about 10,000,000 orders by timestamp for the audit report. |
| Key issues | **Stability** (orders with equal timestamps must keep gateway arrival order); **guaranteed running time**; **O(n) extra memory**; data may not fit in RAM. |
| Consequence of a poor choice | An unstable sort breaks gateway reconciliation; an O(n²) sort needs about 5 × 10¹³ comparisons and misses the nightly deadline. |

## 2. Algorithm design (divide, conquer, combine)
* **Divide** – split the array at the middle (left half gets ⌈n/2⌉ elements).
* **Conquer** – sort each half recursively; a one-element array is already sorted.
* **Combine** – merge two sorted halves with two pointers; on a tie take the **left** element first (`<=`), which makes the sort stable.

Pseudocode: `Pseudocode/merge_sort_pseudocode.md`. Program: `Source_Code/merge_sort.py` (reads `Supporting_Files/datasets/orders_sample.csv`).

## 3. Execution trace on the sample orders
Input: `105/O1, 102/O2, 105/O3, 101/O4, 102/O5, 103/O6`

| Merge | Left + Right | Result | Comparisons |
|---|---|---|---|
| M1 | [105/O1] + [102/O2] | 102/O2, 105/O1 | 1 |
| M2 | [102/O2, 105/O1] + [105/O3] | 102/O2, 105/O1, 105/O3 | 2 |
| M3 | [101/O4] + [102/O5] | 101/O4, 102/O5 | 1 |
| M4 | [101/O4, 102/O5] + [103/O6] | 101/O4, 102/O5, 103/O6 | 2 |
| M5 | [102/O2, 105/O1, 105/O3] + [101/O4, 102/O5, 103/O6] | 101/O4, 102/O2, 102/O5, 103/O6, 105/O1, 105/O3 | 4 |

Total 10 comparisons; the full program trace is in the execution output (section 9).

## 4. Stability
O2 and O5 share timestamp 102 and O1 and O3 share 105. Because a tie is resolved in favour of the left half (which holds the earlier arrivals), the output keeps `O2 before O5` and `O1 before O3`. The program also runs an unstable selection sort on the same data, which swaps O1 and O3 – showing why stability must be designed in.

## 5. Recurrence and solution
Merging n elements needs at most n − 1 comparisons, so `T(n) = 2T(n/2) + (n − 1), T(1) = 0`.
Recursion tree: log₂ n levels, about n comparisons per level, so `T(n) ≈ n log₂ n − n + 1` (n a power of 2).
Master theorem (a = 2, b = 2, f(n) = Θ(n) = Θ(n^(log₂2))), case 2: **T(n) = Θ(n log n)** in the best, average and worst case.
Exact worst case: `n⌈log₂ n⌉ − 2^⌈log₂ n⌉ + 1`.

## 6. Production workload: n = 10,000,000
* n log₂ n = 232,534,967 comparisons (average estimate, about 2.3 × 10⁸).
* Exact worst case = 10⁷ × 24 − 2²⁴ + 1 = **223,222,785**.
* A quadratic sort needs n²/2 = 50,000,000,000,000 comparisons, about 224,000 times more.

## 7. Memory and data larger than RAM
* Extra space is O(n): one buffer allocated once and reused. With 16-byte records: 160 MB data + 160 MB buffer = 320 MB.
* **External merge sort** (implemented and tested): form sorted runs that fit in memory, write them to disk, then do a k-way merge with a min-heap keyed on (timestamp, run number). The run number as tie-breaker keeps the result stable. Demo: 100,000 orders, 10 runs, 1 merge pass – output identical to the in-memory stable sort.
* If each payment gateway already emits time-ordered orders, a direct k-way merge of the gateway streams costs only O(n log k).

## 8. Experimental results
Comparisons are deterministic (seeded data); times depend on the machine.

| n | comparisons | n log₂ n | worst-case formula |
|---|---|---|---|
| 1,000 | 8,705 | 9,966 | 8,977 |
| 4,000 | 42,878 | 47,863 | 43,905 |
| 16,000 | 203,310 | 223,453 | 207,617 |
| 64,000 | 941,447 | 1,021,810 | 958,465 |
| 128,000 | 2,010,131 | 2,171,620 | 2,044,929 |

Measured comparisons always lie below the worst-case formula and grow as n log n.

![comparisons](merge_sort_comparisons.png)

## 9. Limitations, trade-offs and improvements
* **Trade-off:** guaranteed Θ(n log n) and stability are bought with O(n) extra memory. In-place stable merges exist but are slower and far more complex.
* **Limitation:** Python's per-element overhead makes absolute times large; the comparison counts, not seconds, are the evidence.
* **Improvements:** reuse one buffer; switch to insertion sort for tiny sub-arrays; skip the merge when the last element of the left half is ≤ the first of the right half (helps almost-sorted input); use external merge sort or a k-way merge of gateway streams when data exceeds RAM.

## 10. Conclusion
Merge Sort is the right choice for the audit report: stable, Θ(n log n) for any input order, and naturally extendable to disk.

## 11. Screenshots
![source](screenshots/source_merge_sort.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
{out("Module_1_Merge_Sort")}```
'''

M2 = f'''# Module 2 – Quick Sort for the Live Seller Leaderboard

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Re-sort 100,000 seller scores every few seconds; the data is nearly sorted. |
| Key issues | **Worst-case behaviour** (first-element pivot on sorted data), recursion depth, in-place sorting; stability is not required. |
| Consequence of a poor choice | About n(n − 1)/2 ≈ 5 × 10⁹ comparisons per refresh, so the board freezes; recursion depth ≈ n risks stack overflow. |

## 2. Algorithm design
* **Divide** – PARTITION around a pivot; the pivot lands in its final position, giving a left part (≤ pivot) and a right part (> pivot).
* **Conquer** – sort both parts recursively.
* **Combine** – nothing to do, the array is already in place.

Three variants are implemented and compared: (1) **current** first-element pivot, (2) **improved** median-of-three with insertion-sort cut-off (16) and recursion on the smaller side, (3) **random** pivot. Pseudocode: `Pseudocode/quick_sort_pseudocode.md`.

## 3. One partition step on 42, 17, 63, 8, 55, 29
```text
start        : [42, 17, 63, 8, 55, 29]   pivot = 42
swap a[2],a[5]: [42, 17, 29, 8, 55, 63]
pivot -> a[3] : [8, 17, 29] |42| [55, 63]       (7 comparisons)
```
The left part {{8, 17, 29}} and right part {{55, 63}} are then sorted recursively (full trace in the output appendix). Total comparisons for the whole sample: 17.

## 4. Why the first-element pivot is slow
On sorted or nearly sorted data the first element is the smallest of its range. The partition then produces an empty left part and n − 1 elements on the right, level after level (see the second trace in the output: pivots 8, 17, 29, 42, 55 peel off one element each). The result is n levels with about n work each.

## 5. Recurrences and solutions
* **Best case** (pivot = median): `T(n) = 2T(n/2) + n` → **Θ(n log n)** (Master theorem, case 2).
* **Worst case** (pivot = min or max): `T(n) = T(n−1) + (n−1)` → (n−1) + (n−2) + … + 1 = n(n−1)/2 → **Θ(n²)**.
* **Average case**: ≈ 2 n ln n ≈ 1.39 n log₂ n → Θ(n log n).

## 6. Production workload: n = 100,000 sellers
| Case | Formula | Comparisons |
|---|---|---|
| First-element pivot on nearly sorted data (≈ worst) | n(n−1)/2 | 4,999,950,000 |
| Best case | n log₂ n | 1,660,964 |
| Average (random / median-of-three) | 2 n ln n | 2,302,585 |

The current design does roughly 2,000–3,000 times more work than a good pivot strategy.

## 7. Experiment: nearly sorted data (1% of positions swapped)
| n | first pivot | depth | median-of-three | depth | random pivot | n log₂ n |
|---|---|---|---|---|---|---|
| 250 | 19,961 | 144 | 1,325 | 6 | 2,077 | 1,991 |
| 500 | 68,727 | 265 | 3,046 | 6 | 4,818 | 4,483 |
| 1,000 | 204,897 | 424 | 7,109 | 8 | 11,914 | 9,966 |
| 2,000 | 638,770 | 795 | 16,282 | 10 | 26,317 | 21,932 |
| 4,000 | 1,316,235 | 750 | 37,055 | 12 | 58,886 | 47,863 |

At n = 4,000 the first-element pivot needs about 35 times more comparisons than median-of-three (and 22 times more than a random pivot), and its recursion depth is in the hundreds, whereas the improved version stays near n log₂ n with depth 6–12.

![comparisons](quick_sort_comparisons.png)

## 8. Improved pivot strategy and justification
* **Median-of-three** (first, middle, last): on sorted/nearly sorted data the middle element is close to the true median, so splits are balanced. Cost: 3 extra comparisons per partition.
* **Random pivot:** expected 2 n ln n for every input order; no input can force the worst case.
* **Insertion sort for ≤ 16 elements** (fast on nearly sorted data) and **recursion on the smaller part first** (stack depth O(log n)).

## 9. Limitations and trade-offs (observed in the experiments)
* Quick Sort is **not stable** (not needed for scores).
* Median-of-three is not a guarantee: on the *reverse-sorted* test it needed 506,360 comparisons for n = 2,000, well above n log₂ n ≈ 21,932 (see output). A random pivot did not show this weakness.
* With **many equal keys** this partition scheme degrades to Θ(n²) for every pivot rule (all-equal test: about 2 × 10⁶ comparisons). A three-way (Dutch national flag) partition fixes this.
* Worst case is still Θ(n²) in theory; **introsort** (switch to Heap Sort at depth 2 log n) gives a hard O(n log n) bound.

## 10. Improvements recommended
Use median-of-three or random pivot with insertion-sort cut-off; add three-way partitioning if many ties are expected; if only a few scores change between refreshes, insertion sort / an adaptive sort (O(n + d) for d inversions) can be even cheaper.

## 11. Screenshots
![source](screenshots/source_quick_sort.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
{out("Module_2_Quick_Sort")}```
'''

M3 = f'''# Module 3 – Binary Search for Order Lookup

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Find the **first** order with a given timestamp in 10,000,000 sorted orders. |
| Key issues | Sorted-data precondition (provided by Module 1), duplicate timestamps, O(log n) time with O(1) memory. |
| Consequence of a poor choice | Linear scan: up to 10⁷ comparisons per lookup (seconds). A plain binary search returns *any* equal order, and on unsorted data it returns wrong answers. |

## 2. Why sorted order is essential
Binary search discards half of the array after each comparison. If `A[mid] < key`, everything left of `mid` is dropped – valid only if those elements are ≤ `A[mid]`, which holds only in a sorted list. Because Module 1 is stable, the first order found among equal timestamps is also the earliest arrival.

## 3. Algorithm design
* **Divide** – compute `mid = lo + (hi − lo)/2`.
* **Conquer** – continue in exactly one half.
* **Combine** – nothing to combine.
* **First occurrence** – on a match record `result = mid` and continue in the left half (`hi = mid − 1`).

Pseudocode: `Pseudocode/binary_search_pseudocode.md`; program: `Source_Code/binary_search.py`.

## 4. Execution trace (sorted list from Module 1)
List: `101/O4, 102/O2, 102/O5, 103/O6, 105/O1, 105/O3`

```text
first_occurrence(key=102)
  probe 1: range [0..5] mid=2 A[2]=102  match -> result=2, search left (hi=1)
  probe 2: range [0..1] mid=0 A[0]=101  101 < 102 -> search right (lo=1)
  probe 3: range [1..1] mid=1 A[1]=102  match -> result=1, search left (hi=0)
  result index = 1 -> order O2
```
The standard search returns index 2 (order O5) for the same key, which is wrong for support staff; the modified search returns O2. Keys 105 (→ O1) and 104 (not found, −1) are traced in the output appendix.

## 5. Recurrence and solution
`T(n) = T(n/2) + 1, T(1) = 1`. Unrolling: `T(n) = T(n/2^k) + k`, and with k = log₂ n, `T(n) = log₂ n + 1`. In general **T(n) = ⌊log₂ n⌋ + 1 = Θ(log n)**. Master theorem: a = 1, b = 2, f(n) = Θ(1) = Θ(n⁰), case 2.

## 6. Production workload: n = 10,000,000
2²³ = 8,388,608 ≤ 10⁷ < 2²⁴ = 16,777,216, so ⌊log₂ 10⁷⌋ = 23 and the **maximum is 23 + 1 = 24 probes**. A linear scan needs up to 10,000,000 (416,667 times more). The program confirmed 24 as the largest probe count over 3,005 test keys on a 10,000,000-element virtual list.

## 7. Experimental results
| n | ⌊log₂ n⌋ + 1 | max probes observed | linear worst case |
|---|---|---|---|
| 1,000 | 10 | 10 | 1,000 |
| 10,000 | 14 | 14 | 10,000 |
| 100,000 | 17 | 17 | 100,000 |
| 1,000,000 | 20 | 20 | 1,000,000 |
| 10,000,000 | 24 | 24 | 10,000,000 |

On a real list of 1,000,000 orders the binary search was more than a thousand times faster than a linear scan (exact timing in the output appendix, machine dependent).

![comparisons](binary_search_comparisons.png)

## 8. Testing
Edge cases (empty array, single element, all-equal array, missing key) and 1,000 random arrays × 23 keys compared with Python's `bisect_left` all pass.

## 9. Limitations, trade-offs and improvements
* Needs the data to **stay sorted**; inserting new orders into an array is O(n). A B-tree or balanced tree handles continuous inserts.
* For lookups by exact order ID a **hash table** gives O(1).
* The first-occurrence variant always runs about log₂ n iterations (it does not stop on a match), which is still only 24 for 10⁷ orders.
* Use `lo + (hi − lo)/2` to avoid integer overflow in fixed-width languages.

## 10. Screenshots
![source](screenshots/source_binary_search.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
{out("Module_3_Binary_Search")}```
'''

M4 = f'''# Module 4 – Strassen's Matrix Multiplication for Recommendation Scores

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Compute C = A × B for n × n matrices, n = 1,024. |
| Key issues | Matrix size (n³ ≈ 1.07 × 10⁹ multiplications), power-of-two sizes, temporary memory, recursion overhead. |
| Consequence of a poor choice | Conventional multiplication is too slow, so scores refresh only daily; Strassen recursed down to 1 × 1 is slow in practice (overhead, extra additions, cache misses). |

## 2. Algorithm design
* **Divide** – split each matrix into four (n/2) × (n/2) blocks.
* **Conquer** – compute **7** recursive block products M1…M7 (instead of 8).
* **Combine** – build C from additions and subtractions.

```text
M1 = (A11 + A22)(B11 + B22)      C11 = M1 + M4 - M5 + M7
M2 = (A21 + A22) B11             C12 = M3 + M5
M3 = A11 (B12 - B22)             C21 = M2 + M4
M4 = A22 (B21 - B11)             C22 = M1 - M2 + M3 + M6
M5 = (A11 + A12) B22
M6 = (A21 - A11)(B11 + B12)
M7 = (A12 - A22)(B21 + B22)
```
Pseudocode: `Pseudocode/strassen_pseudocode.md`; program: `Source_Code/strassen.py` (reads `matrices_sample.json`; pads when n is not a power of 2).

## 3. Verification on the 2 × 2 sample
A = [[1, 7], [3, 5]], B = [[1, 3], [7, 5]]

| Product | Calculation | Value |
|---|---|---|
| M1 | (1+5)(1+5) | 36 |
| M2 | (3+5)·1 | 8 |
| M3 | 1·(3−5) | −2 |
| M4 | 5·(7−1) | 30 |
| M5 | (1+7)·5 | 40 |
| M6 | (3−1)(1+3) | 8 |
| M7 | (7−5)(7+5) | 24 |

C11 = 36+30−40+24 = 50, C12 = −2+40 = 38, C21 = 8+30 = 38, C22 = 36−8−2+8 = 34 → **C = [[50, 38], [38, 34]]**, equal to the conventional product. The program also tests random matrices of size 4…128 (cut-offs 1 and 8) and a 100 × 100 matrix (padded to 128), all equal to the conventional result.

## 4. Recurrence and solution
Seven half-size products and 18 block additions/subtractions: `T(n) = 7T(n/2) + 18(n/2)² = 7T(n/2) + Θ(n²)`. Since log₂ 7 ≈ 2.807 > 2, the leaves dominate (Master theorem case 1): **T(n) = Θ(n^(log₂ 7)) ≈ Θ(n^2.81)**.
For n = 2^k: multiplications `M(k) = 7^k`; additions `A(n) = 6(7^k − 4^k)`. The program measured exactly these values for n = 2…32.
Extra space: Θ(n²) for the temporary matrices.

## 5. Production workload: n = 1,024 (k = 10)
| Method | Multiplications | Additions | Total | vs conventional |
|---|---|---|---|---|
| Conventional | 1,073,741,824 | 1,072,693,248 | 2,146,435,072 | 100.0% |
| Strassen to 1 × 1 | 282,475,249 | 1,688,560,038 | 1,971,035,287 | 91.8% |
| Hybrid, cut-off 128 | 719,323,136 | 741,130,240 | 1,460,453,376 | 68.0% |
| Hybrid, cut-off 64 | 629,407,744 | 672,288,768 | 1,301,696,512 | 60.6% |
| Hybrid, cut-off 32 | 550,731,776 | 630,492,160 | 1,181,223,936 | 55.0% |
| Hybrid, cut-off 16 | 481,890,304 | 626,189,568 | 1,108,079,872 | 51.6% |

Pure Strassen uses only 7¹⁰/1024³ = 26.3% of the multiplications (3.8 times fewer) but needs 1.69 × 10⁹ additions, so the **total saving is only about 8%**.

![multiplications](strassen_multiplications.png)
![total operations](strassen_total_operations.png)

## 6. Measured running time (machine dependent)
| n | conventional | Strassen cut = 1 | hybrid cut = 16 | hybrid cut = 32 |
|---|---|---|---|---|
| 32 | 0.0026 s | 0.0494 s | 0.0029 s | 0.0022 s |
| 64 | 0.0171 s | 0.4470 s | 0.0340 s | 0.0267 s |
| 128 | 0.1582 s | 3.2596 s | 0.1725 s | 0.1580 s |

NumPy experiment, n = 1,024: `numpy.matmul` (optimised BLAS) 0.043 s versus hybrid Strassen 0.082–0.113 s (cut-offs 128, 256, 64). **Strassen was never faster in any measurement** (a hybrid whose cut-off equals n is just the conventional method), even though it performs fewer operations on paper. Timings come from the run saved in `execution_output.txt` and vary a little between runs and machines.

## 7. Why Strassen is not faster in practice, and the practical hybrid
* 18 extra block additions with large constants and temporary matrices (Θ(n²) memory, allocation and copying).
* Recursion and slicing overhead on tiny blocks – pure Strassen (cut = 1) was about 20× slower at n = 128.
* Conventional/BLAS code is cache-blocked, vectorised and multithreaded; Strassen's irregular memory access cannot match it.
* Needs power-of-two padding; slightly weaker numerical stability.

**Hybrid:** run Strassen only while the blocks are large, then call an optimised conventional kernel below a cut-off n₀ (typically 64–256, tuned by measurement). For n = 1,024 and n₀ = 64 this needs 7⁴ = 2,401 base products of size 64 × 64 (629,407,744 multiplications, 58.6% of conventional). The 7 sub-products are independent and can run on separate cores.

## 8. Recommendation
Use hybrid Strassen only after benchmarking on the production hardware. If an optimised BLAS/GPU library is available, calling it directly can beat any hand-written Strassen (as measured above); Strassen pays off mainly for very large matrices or when multiplications are much more expensive than additions.

## 9. Screenshots
![source](screenshots/source_strassen.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
{out("Module_4_Strassen_Matrix_Multiplication")}```
'''
for m, t in [("Module_1_Merge_Sort", M1), ("Module_2_Quick_Sort", M2), ("Module_3_Binary_Search", M3), ("Module_4_Strassen_Matrix_Multiplication", M4)]:
    (R/m/'Report'/f"{m.split('_')[0]}_{m.split('_')[1]}_Report.md").write_text(t, encoding='utf8')
print("reports written")
