# Pseudocode – Binary Search for Order Lookup

Precondition: `A` is sorted by timestamp (output of Module 1).

## Standard binary search (returns ANY match)
```
BINARY-SEARCH(A, n, key)
    lo <- 0 ; hi <- n - 1
    while lo <= hi do
        mid <- lo + (hi - lo) div 2          // DIVIDE  (no overflow)
        if A[mid].ts = key then return mid
        else if A[mid].ts < key then lo <- mid + 1      // CONQUER the right half only
        else hi <- mid - 1                              // CONQUER the left half only
    return -1                                // COMBINE: nothing to combine
```

## First occurrence (required by customer support)
```
FIRST-OCCURRENCE(A, n, key)
    lo <- 0 ; hi <- n - 1 ; result <- -1
    while lo <= hi do
        mid <- lo + (hi - lo) div 2
        if A[mid].ts = key then
            result <- mid                    // remember the match ...
            hi <- mid - 1                    // ... and look for an EARLIER one
        else if A[mid].ts < key then lo <- mid + 1
        else hi <- mid - 1
    return result                            // -1 when the timestamp does not exist
```
Last occurrence: on a match set `result <- mid ; lo <- mid + 1`.

Recurrence: `T(n) = T(n/2) + 1`, `T(1) = 1`  ->  `floor(log2 n) + 1` probes; extra space `O(1)`.
