"""
CSA06 CO3 - Module 3: Order Lookup (Binary Search, first occurrence)
Run:  python binary_search.py
"""
import bisect, csv, math, random, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / "Supporting_Files" / "datasets" / "orders_sample.csv"
RESULTS = ROOT / "Supporting_Files" / "results"
REPORT = HERE.parent / "Report"


def standard_binary_search(a, key):
    """Textbook version: returns ANY matching index (not necessarily the first)."""
    lo, hi, probes = 0, len(a) - 1, 0
    while lo <= hi:
        mid = lo + (hi - lo) // 2
        probes += 1
        if a[mid][0] == key: return mid, probes
        if a[mid][0] < key: lo = mid + 1
        else: hi = mid - 1
    return -1, probes


def first_occurrence(a, key, trace=None):
    """Divide: pick mid.  Conquer: continue in ONE half.  Combine: nothing to combine.
    On a match remember it and keep searching the LEFT half for an earlier one."""
    lo, hi, result, probes = 0, len(a) - 1, -1, 0
    while lo <= hi:
        lo0, hi0 = lo, hi
        mid = lo + (hi - lo) // 2
        probes += 1
        k = a[mid][0]
        if k == key:
            action = f"match -> result={mid}, search left (hi={mid - 1})"
            result, hi = mid, mid - 1
        elif k < key:
            action = f"{k} < {key} -> search right (lo={mid + 1})"
            lo = mid + 1
        else:
            action = f"{k} > {key} -> search left (hi={mid - 1})"
            hi = mid - 1
        if trace is not None:
            trace.append(f"  probe {probes}: range [{lo0}..{hi0}] mid={mid} A[{mid}]={k}  {action}")
    return result, probes


def last_occurrence(a, key):
    lo, hi, result, probes = 0, len(a) - 1, -1, 0
    while lo <= hi:
        mid = lo + (hi - lo) // 2
        probes += 1
        if a[mid][0] == key: result, lo = mid, mid + 1
        elif a[mid][0] < key: lo = mid + 1
        else: hi = mid - 1
    return result, probes


def linear_search(a, key):
    for i, r in enumerate(a):
        if r[0] == key: return i, i + 1
    return -1, len(a)


class VirtualOrders:
    """Sorted orders generated on the fly (timestamp = i // 3): lets us test n = 10,000,000 without 400 MB of RAM."""
    def __init__(self, n): self.n = n
    def __len__(self): return self.n
    def __getitem__(self, i): return (i // 3, f"O{i}")


def main():
    print("=" * 78 + "\nMODULE 3 - BINARY SEARCH FOR ORDER LOOKUP\n" + "=" * 78)
    with open(DATA, newline="") as f:
        sample = [(int(t), o) for t, o in list(csv.reader(f))[1:]]
    ordered = [(101, "O4"), (102, "O2"), (102, "O5"), (103, "O6"), (105, "O1"), (105, "O3")]  # Module 1 output
    assert sorted(sample, key=lambda r: r[0]) == ordered
    print("\nSorted list from Module 1:", ordered)

    for key in (102, 105, 104):
        print(f"\n--- first_occurrence(key={key}) ---")
        trace = []
        idx, probes = first_occurrence(ordered, key, trace)
        print("\n".join(trace))
        print(f"  result index = {idx}" + (f" -> order {ordered[idx][1]}" if idx >= 0 else " (not found)") + f"; probes = {probes}")
    assert first_occurrence(ordered, 102)[0] == 1 and first_occurrence(ordered, 105)[0] == 4 and first_occurrence(ordered, 104)[0] == -1
    print("\nstandard binary search for 102 returns index", standard_binary_search(ordered, 102)[0],
          "(order", ordered[standard_binary_search(ordered, 102)[0]][1] + ") - NOT the first order O2")
    print("last_occurrence(102) =", last_occurrence(ordered, 102)[0], "(order O5)")

    print("\n--- Edge cases ---")
    assert first_occurrence([], 5)[0] == -1
    assert first_occurrence([(5, "X")], 5)[0] == 0 and first_occurrence([(5, "X")], 4)[0] == -1
    assert first_occurrence([(7, str(i)) for i in range(50)], 7)[0] == 0
    print("empty array, single element, all-equal array, missing key -> PASS")

    print("\n--- Randomised check against bisect_left (1,000 arrays) ---")
    rnd = random.Random(2)
    for _ in range(1000):
        n = rnd.randrange(0, 60)
        arr = sorted((rnd.randrange(20), f"x{i}") for i in range(n))
        keys = [r[0] for r in arr]
        for key in range(-1, 22):
            exp = bisect.bisect_left(keys, key)
            exp = exp if exp < n and keys[exp] == key else -1
            assert first_occurrence(arr, key)[0] == exp
    print("all 1,000 arrays x 23 keys agree -> PASS")

    print("\n--- Experiment: maximum probes versus n (binary) and comparisons (linear, worst case) ---")
    print(f"{'n':>12} {'floor(log2 n)+1':>16} {'max probes observed':>20} {'linear worst':>14}")
    rows = []
    rnd = random.Random(8)
    for n in (10 ** 3, 10 ** 4, 10 ** 5, 10 ** 6, 10 ** 7):
        v = VirtualOrders(n)
        tmax = (n - 1) // 3
        keys = [rnd.randrange(-2, tmax + 3) for _ in range(3000)] + [0, tmax, tmax + 1, -1, tmax // 2]
        mx = max(first_occurrence(v, k)[1] for k in keys)
        rows.append((n, math.floor(math.log2(n)) + 1, mx, n))
        print(f"{n:>12,} {math.floor(math.log2(n)) + 1:>16} {mx:>20} {n:>14,}")
    with open(RESULTS / "module3_results.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["n", "floor_log2_n_plus_1", "max_probes_observed", "linear_worst"]); w.writerows(rows)

    print("\n--- Timing on a real list of 1,000,000 orders (200 lookups) ---")
    arr = [(i // 3, f"O{i}") for i in range(1_000_000)]
    keys = [rnd.randrange(0, 333_334) for _ in range(200)]
    t0 = time.perf_counter(); [first_occurrence(arr, k) for k in keys]; tb = time.perf_counter() - t0
    t0 = time.perf_counter(); [linear_search(arr, k) for k in keys]; tl = time.perf_counter() - t0
    print(f"binary search: {tb * 1000:.2f} ms total | linear scan: {tl * 1000:.0f} ms total | speed-up about {tl / tb:,.0f}x")

    n = 10_000_000
    print(f"\n--- Production workload n = {n:,} ---")
    print(f"maximum binary-search probes = floor(log2 n)+1 = {math.floor(math.log2(n)) + 1}; linear scan = {n:,} "
          f"({n / (math.floor(math.log2(n)) + 1):,.0f}x more)")

    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        ns = [r[0] for r in rows]
        plt.figure(figsize=(7, 4.2))
        plt.plot(ns, [r[3] for r in rows], "o-", label="linear search (worst case)")
        plt.plot(ns, [r[2] for r in rows], "s-", label="binary search (max probes observed)")
        plt.xscale("log"); plt.yscale("log"); plt.xlabel("number of orders n"); plt.ylabel("comparisons (log scale)")
        plt.title("Order lookup: linear vs binary search"); plt.legend(); plt.grid(alpha=.3, which="both")
        plt.tight_layout(); plt.savefig(REPORT / "binary_search_comparisons.png", dpi=150); plt.close()
        print("\nGraph saved: Report/binary_search_comparisons.png")
    except ImportError:
        print("matplotlib not installed - graph skipped")


if __name__ == "__main__":
    main()
