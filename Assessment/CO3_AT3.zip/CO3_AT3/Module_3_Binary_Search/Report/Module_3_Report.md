# Module 3 – Binary Search for Order Lookup

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Find the **first** order with a given timestamp in 10,000,000 sorted orders. |
| Key issues | Sorted-data precondition (provided by Module 1), duplicate timestamps, O(log n) time with O(1) memory. |
| Consequence of a poor choice | Linear scan: up to 10⁷ comparisons per lookup (seconds). A plain binary search returns *any* equal order, and on unsorted data it returns wrong answers. |

## 2. Why sorted order is essential
Binary search discards half of the array after each comparison. If `A[mid] < key`, everything left of `mid` is dropped – valid only if those elements are ≤ `A[mid]`, which holds only in a sorted list. Because Module 1 is stable, the first order found among equal timestamps is also the earliest arrival.

## 3. Algorithm design
* **Divide** – compute `mid = lo + (hi − lo)/2`.
* **Conquer** – continue in exactly one half.
* **Combine** – nothing to combine.
* **First occurrence** – on a match record `result = mid` and continue in the left half (`hi = mid − 1`).

Pseudocode: `Pseudocode/binary_search_pseudocode.md`; program: `Source_Code/binary_search.py`.

## 4. Execution trace (sorted list from Module 1)
List: `101/O4, 102/O2, 102/O5, 103/O6, 105/O1, 105/O3`

```text
first_occurrence(key=102)
  probe 1: range [0..5] mid=2 A[2]=102  match -> result=2, search left (hi=1)
  probe 2: range [0..1] mid=0 A[0]=101  101 < 102 -> search right (lo=1)
  probe 3: range [1..1] mid=1 A[1]=102  match -> result=1, search left (hi=0)
  result index = 1 -> order O2
```
The standard search returns index 2 (order O5) for the same key, which is wrong for support staff; the modified search returns O2. Keys 105 (→ O1) and 104 (not found, −1) are traced in the output appendix.

## 5. Recurrence and solution
`T(n) = T(n/2) + 1, T(1) = 1`. Unrolling: `T(n) = T(n/2^k) + k`, and with k = log₂ n, `T(n) = log₂ n + 1`. In general **T(n) = ⌊log₂ n⌋ + 1 = Θ(log n)**. Master theorem: a = 1, b = 2, f(n) = Θ(1) = Θ(n⁰), case 2.

## 6. Production workload: n = 10,000,000
2²³ = 8,388,608 ≤ 10⁷ < 2²⁴ = 16,777,216, so ⌊log₂ 10⁷⌋ = 23 and the **maximum is 23 + 1 = 24 probes**. A linear scan needs up to 10,000,000 (416,667 times more). The program confirmed 24 as the largest probe count over 3,005 test keys on a 10,000,000-element virtual list.

## 7. Experimental results
| n | ⌊log₂ n⌋ + 1 | max probes observed | linear worst case |
|---|---|---|---|
| 1,000 | 10 | 10 | 1,000 |
| 10,000 | 14 | 14 | 10,000 |
| 100,000 | 17 | 17 | 100,000 |
| 1,000,000 | 20 | 20 | 1,000,000 |
| 10,000,000 | 24 | 24 | 10,000,000 |

On a real list of 1,000,000 orders the binary search was more than a thousand times faster than a linear scan (exact timing in the output appendix, machine dependent).

![comparisons](binary_search_comparisons.png)

## 8. Testing
Edge cases (empty array, single element, all-equal array, missing key) and 1,000 random arrays × 23 keys compared with Python's `bisect_left` all pass.

## 9. Limitations, trade-offs and improvements
* Needs the data to **stay sorted**; inserting new orders into an array is O(n). A B-tree or balanced tree handles continuous inserts.
* For lookups by exact order ID a **hash table** gives O(1).
* The first-occurrence variant always runs about log₂ n iterations (it does not stop on a match), which is still only 24 for 10⁷ orders.
* Use `lo + (hi − lo)/2` to avoid integer overflow in fixed-width languages.

## 10. Screenshots
![source](screenshots/source_binary_search.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
==============================================================================
MODULE 3 - BINARY SEARCH FOR ORDER LOOKUP
==============================================================================

Sorted list from Module 1: [(101, 'O4'), (102, 'O2'), (102, 'O5'), (103, 'O6'), (105, 'O1'), (105, 'O3')]

--- first_occurrence(key=102) ---
  probe 1: range [0..5] mid=2 A[2]=102  match -> result=2, search left (hi=1)
  probe 2: range [0..1] mid=0 A[0]=101  101 < 102 -> search right (lo=1)
  probe 3: range [1..1] mid=1 A[1]=102  match -> result=1, search left (hi=0)
  result index = 1 -> order O2; probes = 3

--- first_occurrence(key=105) ---
  probe 1: range [0..5] mid=2 A[2]=102  102 < 105 -> search right (lo=3)
  probe 2: range [3..5] mid=4 A[4]=105  match -> result=4, search left (hi=3)
  probe 3: range [3..3] mid=3 A[3]=103  103 < 105 -> search right (lo=4)
  result index = 4 -> order O1; probes = 3

--- first_occurrence(key=104) ---
  probe 1: range [0..5] mid=2 A[2]=102  102 < 104 -> search right (lo=3)
  probe 2: range [3..5] mid=4 A[4]=105  105 > 104 -> search left (hi=3)
  probe 3: range [3..3] mid=3 A[3]=103  103 < 104 -> search right (lo=4)
  result index = -1 (not found); probes = 3

standard binary search for 102 returns index 2 (order O5) - NOT the first order O2
last_occurrence(102) = 2 (order O5)

--- Edge cases ---
empty array, single element, all-equal array, missing key -> PASS

--- Randomised check against bisect_left (1,000 arrays) ---
all 1,000 arrays x 23 keys agree -> PASS

--- Experiment: maximum probes versus n (binary) and comparisons (linear, worst case) ---
           n  floor(log2 n)+1  max probes observed   linear worst
       1,000               10                   10          1,000
      10,000               14                   14         10,000
     100,000               17                   17        100,000
   1,000,000               20                   20      1,000,000
  10,000,000               24                   24     10,000,000

--- Timing on a real list of 1,000,000 orders (200 lookups) ---
binary search: 2.64 ms total | linear scan: 3885 ms total | speed-up about 1,473x

--- Production workload n = 10,000,000 ---
maximum binary-search probes = floor(log2 n)+1 = 24; linear scan = 10,000,000 (416,667x more)

Graph saved: Report/binary_search_comparisons.png
```
