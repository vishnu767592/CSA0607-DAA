# Pseudocode – Merge Sort (stable) for Nightly Order Consolidation

```
MERGE-SORT(A, lo, hi, BUF)            // sorts A[lo .. hi-1] by timestamp, hi exclusive
    if hi - lo <= 1 then return       // base case: 0 or 1 element is sorted
    mid <- (lo + hi + 1) div 2        // DIVIDE : left half gets ceil(n/2) elements
    MERGE-SORT(A, lo, mid, BUF)       // CONQUER: sort left half
    MERGE-SORT(A, mid, hi, BUF)       // CONQUER: sort right half
    MERGE(A, lo, mid, hi, BUF)        // COMBINE: merge two sorted halves

MERGE(A, lo, mid, hi, BUF)
    i <- lo ; j <- mid ; k <- lo
    while i < mid and j < hi do
        if A[i].timestamp <= A[j].timestamp then     // "<=" : tie -> take LEFT element  => STABLE
            BUF[k] <- A[i] ; i <- i + 1
        else
            BUF[k] <- A[j] ; j <- j + 1
        k <- k + 1
    while i < mid do  BUF[k] <- A[i] ; i <- i + 1 ; k <- k + 1
    while j < hi  do  BUF[k] <- A[j] ; j <- j + 1 ; k <- k + 1
    copy BUF[lo .. hi-1] back into A[lo .. hi-1]

SORT-ORDERS(A)
    allocate BUF of size n ONCE
    MERGE-SORT(A, 0, n, BUF)

EXTERNAL-MERGE-SORT(file, M)          // M = number of records that fit in memory
    repeat: read M records -> SORT-ORDERS -> write as sorted run R_r      // run formation
    build min-heap with the first record of every run, key = (timestamp, run number)
    while heap not empty do                                               // k-way merge
        pop smallest (ts, r, rec) ; output rec ; push next record of run r
```

Recurrence: `T(n) = 2T(n/2) + (n - 1)`, `T(1) = 0`  ->  `Theta(n log n)`.  Extra space: `O(n)` (one buffer).
