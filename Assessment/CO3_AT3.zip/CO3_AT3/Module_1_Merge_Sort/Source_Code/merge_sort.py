"""
CSA06 CO3 - Module 1: Nightly Order Consolidation (stable Merge Sort)
Run:  python merge_sort.py
"""
import csv, heapq, math, os, random, tempfile, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / "Supporting_Files" / "datasets" / "orders_sample.csv"
RESULTS = ROOT / "Supporting_Files" / "results"
REPORT = HERE.parent / "Report"


def fmt(seq):
    return "[" + ", ".join(f"{t}/{o}" for t, o in seq) + "]"


# ---------------------------------------------------------------- Merge Sort
def merge(a, lo, mid, hi, buf, st, trace, depth):
    """COMBINE: merge sorted a[lo:mid] and a[mid:hi]. Ties go to the LEFT run (stable)."""
    left, right = a[lo:mid], a[mid:hi]
    i, j, k = lo, mid, lo
    while i < mid and j < hi:
        st["cmp"] += 1
        if a[i][0] <= a[j][0]:          # <= keeps equal keys in arrival order
            buf[k] = a[i]; i += 1
        else:
            buf[k] = a[j]; j += 1
        k += 1
    while i < mid:
        buf[k] = a[i]; i += 1; k += 1
    while j < hi:
        buf[k] = a[j]; j += 1; k += 1
    a[lo:hi] = buf[lo:hi]
    if trace is not None:
        trace.append(f"{'  ' * depth}COMBINE  {fmt(left)} + {fmt(right)} -> {fmt(a[lo:hi])}   (comparisons so far: {st['cmp']})")


def merge_sort(a, lo, hi, buf, st, trace=None, depth=0):
    """DIVIDE at the middle, CONQUER both halves recursively, COMBINE with merge()."""
    if hi - lo <= 1:
        return
    mid = (lo + hi + 1) // 2           # left half gets ceil(n/2)
    if trace is not None:
        trace.append(f"{'  ' * depth}DIVIDE   {fmt(a[lo:hi])} -> {fmt(a[lo:mid])} | {fmt(a[mid:hi])}")
    merge_sort(a, lo, mid, buf, st, trace, depth + 1)
    merge_sort(a, mid, hi, buf, st, trace, depth + 1)
    merge(a, lo, mid, hi, buf, st, trace, depth)


def sort_orders(orders, trace=None):
    a = list(orders)
    buf = [None] * len(a)               # ONE reusable O(n) buffer
    st = {"cmp": 0}
    merge_sort(a, 0, len(a), buf, st, trace)
    return a, st["cmp"]


# --------------------------------------------- unstable sort (for comparison)
def selection_sort(orders):
    a = list(orders)
    for i in range(len(a)):
        m = i
        for j in range(i + 1, len(a)):
            if a[j][0] < a[m][0]:
                m = j
        a[i], a[m] = a[m], a[i]
    return a


# ------------------------------------------------------ External merge sort
def external_merge_sort(orders, chunk_size):
    """Run formation (stable in-memory merge sort) + k-way merge with a heap.
    Ties are broken by run number, so the result is stable."""
    tmp = tempfile.mkdtemp(prefix="kartiq_runs_")
    run_files = []
    for r, start in enumerate(range(0, len(orders), chunk_size)):
        run, _ = sort_orders(orders[start:start + chunk_size])
        path = os.path.join(tmp, f"run_{r}.csv")
        with open(path, "w", newline="") as f:
            csv.writer(f).writerows(run)
        run_files.append(path)

    def reader(path):
        with open(path, newline="") as f:
            for ts, oid in csv.reader(f):
                yield int(ts), oid

    heap, readers = [], [reader(p) for p in run_files]
    for r, rd in enumerate(readers):
        first = next(rd, None)
        if first:
            heap.append((first[0], r, first[1]))
    heapq.heapify(heap)
    out = []
    while heap:
        ts, r, oid = heapq.heappop(heap)
        out.append((ts, oid))
        nxt = next(readers[r], None)
        if nxt:
            heapq.heappush(heap, (nxt[0], r, nxt[1]))
    for p in run_files:
        os.remove(p)
    os.rmdir(tmp)
    return out, len(run_files)


def gen_orders(n, seed=1):
    rnd = random.Random(seed)
    span = max(2, n // 4)                  # many equal timestamps
    return [(rnd.randrange(span), f"O{i + 1}") for i in range(n)]


def is_stable_sorted(result, original):
    return result == sorted(original, key=lambda r: r[0])   # Python's sorted is stable


def main():
    print("=" * 78 + "\nMODULE 1 - MERGE SORT FOR NIGHTLY ORDER CONSOLIDATION\n" + "=" * 78)
    with open(DATA, newline="") as f:
        rows = list(csv.reader(f))[1:]
    sample = [(int(t), o) for t, o in rows]
    print("\nInput (timestamp/order id):", fmt(sample))

    print("\n--- Divide / Conquer / Combine trace ---")
    trace = []
    out, cmp_ = sort_orders(sample, trace)
    print("\n".join(trace))
    print("\nSorted output :", fmt(out))
    print("Comparisons   :", cmp_)
    expected = [(101, "O4"), (102, "O2"), (102, "O5"), (103, "O6"), (105, "O1"), (105, "O3")]
    assert out == expected, "sample output differs from expected"
    print("Verification  : output matches the expected stable order -> PASS")

    print("\n--- Stability check on equal timestamps ---")
    for ts in (102, 105):
        ids = [o for t, o in out if t == ts]
        arrival = [o for t, o in sample if t == ts]
        print(f"timestamp {ts}: output order {ids}, arrival order {arrival} -> {'kept' if ids == arrival else 'BROKEN'}")
    uns = selection_sort(sample)
    print("Unstable selection sort on the same data:", fmt(uns))
    print("   -> timestamp 105 order:", [o for t, o in uns if t == 105], "(arrival order was ['O1', 'O3'])")

    print("\n--- Correctness on 20,000 random orders (many ties) ---")
    big = gen_orders(20000, seed=7)
    res, _ = sort_orders(big)
    print("Matches stable reference sort:", is_stable_sorted(res, big))
    assert is_stable_sorted(res, big)

    print("\n--- Experiment: comparisons and time versus n ---")
    print(f"{'n':>9} {'comparisons':>13} {'n*log2(n)':>13} {'worst-case formula':>19} {'time (s)':>9}")
    rows_out = []
    for n in (1000, 2000, 4000, 8000, 16000, 32000, 64000, 128000):
        data = gen_orders(n, seed=n)
        t0 = time.perf_counter()
        res, c = sort_orders(data)
        dt = time.perf_counter() - t0
        assert is_stable_sorted(res, data)
        L = math.ceil(math.log2(n))
        worst = n * L - 2 ** L + 1
        rows_out.append((n, c, round(n * math.log2(n)), worst, round(dt, 4)))
        print(f"{n:>9,} {c:>13,} {round(n * math.log2(n)):>13,} {worst:>19,} {dt:>9.3f}")
    RESULTS.mkdir(parents=True, exist_ok=True)
    with open(RESULTS / "module1_results.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["n", "comparisons", "n_log2_n", "worst_case_formula", "seconds"]); w.writerows(rows_out)

    print("\n--- Production workload: n = 10,000,000 orders (theoretical) ---")
    n = 10_000_000
    L = math.ceil(math.log2(n))
    print(f"n*log2(n)              = {n * math.log2(n):,.0f}")
    print(f"worst case n*{L} - 2^{L} + 1 = {n * L - 2 ** L + 1:,}")
    print(f"quadratic sort n^2/2   = {n * n // 2:,}")
    rec = 16
    print(f"memory: data {n * rec / 1e6:.0f} MB + buffer {n * rec / 1e6:.0f} MB = {2 * n * rec / 1e6:.0f} MB (16-byte records)")

    print("\n--- External merge sort demo: 100,000 orders, 10,000 per run ---")
    data = gen_orders(100000, seed=99)
    res, runs = external_merge_sort(data, 10000)
    print(f"runs written: {runs}; k-way merge passes: 1; stable & correct: {is_stable_sorted(res, data)}")
    assert is_stable_sorted(res, data)

    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        ns = [r[0] for r in rows_out]
        plt.figure(figsize=(7, 4.2))
        plt.plot(ns, [r[1] for r in rows_out], "o-", label="measured comparisons")
        plt.plot(ns, [r[2] for r in rows_out], "s--", label="n log2 n")
        plt.plot(ns, [r[3] for r in rows_out], "^:", label="worst-case formula")
        plt.xlabel("number of orders n"); plt.ylabel("comparisons"); plt.title("Merge Sort: comparisons vs n")
        plt.legend(); plt.grid(alpha=.3); plt.tight_layout()
        plt.savefig(REPORT / "merge_sort_comparisons.png", dpi=150); plt.close()
        print("\nGraph saved: Report/merge_sort_comparisons.png")
    except ImportError:
        print("matplotlib not installed - graph skipped")


if __name__ == "__main__":
    main()
