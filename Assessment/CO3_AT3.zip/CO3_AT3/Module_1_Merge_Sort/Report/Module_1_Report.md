# Module 1 – Merge Sort for Nightly Order Consolidation

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Sort about 10,000,000 orders by timestamp for the audit report. |
| Key issues | **Stability** (orders with equal timestamps must keep gateway arrival order); **guaranteed running time**; **O(n) extra memory**; data may not fit in RAM. |
| Consequence of a poor choice | An unstable sort breaks gateway reconciliation; an O(n²) sort needs about 5 × 10¹³ comparisons and misses the nightly deadline. |

## 2. Algorithm design (divide, conquer, combine)
* **Divide** – split the array at the middle (left half gets ⌈n/2⌉ elements).
* **Conquer** – sort each half recursively; a one-element array is already sorted.
* **Combine** – merge two sorted halves with two pointers; on a tie take the **left** element first (`<=`), which makes the sort stable.

Pseudocode: `Pseudocode/merge_sort_pseudocode.md`. Program: `Source_Code/merge_sort.py` (reads `Supporting_Files/datasets/orders_sample.csv`).

## 3. Execution trace on the sample orders
Input: `105/O1, 102/O2, 105/O3, 101/O4, 102/O5, 103/O6`

| Merge | Left + Right | Result | Comparisons |
|---|---|---|---|
| M1 | [105/O1] + [102/O2] | 102/O2, 105/O1 | 1 |
| M2 | [102/O2, 105/O1] + [105/O3] | 102/O2, 105/O1, 105/O3 | 2 |
| M3 | [101/O4] + [102/O5] | 101/O4, 102/O5 | 1 |
| M4 | [101/O4, 102/O5] + [103/O6] | 101/O4, 102/O5, 103/O6 | 2 |
| M5 | [102/O2, 105/O1, 105/O3] + [101/O4, 102/O5, 103/O6] | 101/O4, 102/O2, 102/O5, 103/O6, 105/O1, 105/O3 | 4 |

Total 10 comparisons; the full program trace is in the execution output (section 9).

## 4. Stability
O2 and O5 share timestamp 102 and O1 and O3 share 105. Because a tie is resolved in favour of the left half (which holds the earlier arrivals), the output keeps `O2 before O5` and `O1 before O3`. The program also runs an unstable selection sort on the same data, which swaps O1 and O3 – showing why stability must be designed in.

## 5. Recurrence and solution
Merging n elements needs at most n − 1 comparisons, so `T(n) = 2T(n/2) + (n − 1), T(1) = 0`.
Recursion tree: log₂ n levels, about n comparisons per level, so `T(n) ≈ n log₂ n − n + 1` (n a power of 2).
Master theorem (a = 2, b = 2, f(n) = Θ(n) = Θ(n^(log₂2))), case 2: **T(n) = Θ(n log n)** in the best, average and worst case.
Exact worst case: `n⌈log₂ n⌉ − 2^⌈log₂ n⌉ + 1`.

## 6. Production workload: n = 10,000,000
* n log₂ n = 232,534,967 comparisons (average estimate, about 2.3 × 10⁸).
* Exact worst case = 10⁷ × 24 − 2²⁴ + 1 = **223,222,785**.
* A quadratic sort needs n²/2 = 50,000,000,000,000 comparisons, about 224,000 times more.

## 7. Memory and data larger than RAM
* Extra space is O(n): one buffer allocated once and reused. With 16-byte records: 160 MB data + 160 MB buffer = 320 MB.
* **External merge sort** (implemented and tested): form sorted runs that fit in memory, write them to disk, then do a k-way merge with a min-heap keyed on (timestamp, run number). The run number as tie-breaker keeps the result stable. Demo: 100,000 orders, 10 runs, 1 merge pass – output identical to the in-memory stable sort.
* If each payment gateway already emits time-ordered orders, a direct k-way merge of the gateway streams costs only O(n log k).

## 8. Experimental results
Comparisons are deterministic (seeded data); times depend on the machine.

| n | comparisons | n log₂ n | worst-case formula |
|---|---|---|---|
| 1,000 | 8,705 | 9,966 | 8,977 |
| 4,000 | 42,878 | 47,863 | 43,905 |
| 16,000 | 203,310 | 223,453 | 207,617 |
| 64,000 | 941,447 | 1,021,810 | 958,465 |
| 128,000 | 2,010,131 | 2,171,620 | 2,044,929 |

Measured comparisons always lie below the worst-case formula and grow as n log n.

![comparisons](merge_sort_comparisons.png)

## 9. Limitations, trade-offs and improvements
* **Trade-off:** guaranteed Θ(n log n) and stability are bought with O(n) extra memory. In-place stable merges exist but are slower and far more complex.
* **Limitation:** Python's per-element overhead makes absolute times large; the comparison counts, not seconds, are the evidence.
* **Improvements:** reuse one buffer; switch to insertion sort for tiny sub-arrays; skip the merge when the last element of the left half is ≤ the first of the right half (helps almost-sorted input); use external merge sort or a k-way merge of gateway streams when data exceeds RAM.

## 10. Conclusion
Merge Sort is the right choice for the audit report: stable, Θ(n log n) for any input order, and naturally extendable to disk.

## 11. Screenshots
![source](screenshots/source_merge_sort.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
==============================================================================
MODULE 1 - MERGE SORT FOR NIGHTLY ORDER CONSOLIDATION
==============================================================================

Input (timestamp/order id): [105/O1, 102/O2, 105/O3, 101/O4, 102/O5, 103/O6]

--- Divide / Conquer / Combine trace ---
DIVIDE   [105/O1, 102/O2, 105/O3, 101/O4, 102/O5, 103/O6] -> [105/O1, 102/O2, 105/O3] | [101/O4, 102/O5, 103/O6]
  DIVIDE   [105/O1, 102/O2, 105/O3] -> [105/O1, 102/O2] | [105/O3]
    DIVIDE   [105/O1, 102/O2] -> [105/O1] | [102/O2]
    COMBINE  [105/O1] + [102/O2] -> [102/O2, 105/O1]   (comparisons so far: 1)
  COMBINE  [102/O2, 105/O1] + [105/O3] -> [102/O2, 105/O1, 105/O3]   (comparisons so far: 3)
  DIVIDE   [101/O4, 102/O5, 103/O6] -> [101/O4, 102/O5] | [103/O6]
    DIVIDE   [101/O4, 102/O5] -> [101/O4] | [102/O5]
    COMBINE  [101/O4] + [102/O5] -> [101/O4, 102/O5]   (comparisons so far: 4)
  COMBINE  [101/O4, 102/O5] + [103/O6] -> [101/O4, 102/O5, 103/O6]   (comparisons so far: 6)
COMBINE  [102/O2, 105/O1, 105/O3] + [101/O4, 102/O5, 103/O6] -> [101/O4, 102/O2, 102/O5, 103/O6, 105/O1, 105/O3]   (comparisons so far: 10)

Sorted output : [101/O4, 102/O2, 102/O5, 103/O6, 105/O1, 105/O3]
Comparisons   : 10
Verification  : output matches the expected stable order -> PASS

--- Stability check on equal timestamps ---
timestamp 102: output order ['O2', 'O5'], arrival order ['O2', 'O5'] -> kept
timestamp 105: output order ['O1', 'O3'], arrival order ['O1', 'O3'] -> kept
Unstable selection sort on the same data: [101/O4, 102/O2, 102/O5, 103/O6, 105/O3, 105/O1]
   -> timestamp 105 order: ['O3', 'O1'] (arrival order was ['O1', 'O3'])

--- Correctness on 20,000 random orders (many ties) ---
Matches stable reference sort: True

--- Experiment: comparisons and time versus n ---
        n   comparisons     n*log2(n)  worst-case formula  time (s)
    1,000         8,705         9,966               8,977     0.002
    2,000        19,364        21,932              19,953     0.004
    4,000        42,878        47,863              43,905     0.009
    8,000        93,712       103,726              95,809     0.021
   16,000       203,310       223,453             207,617     0.047
   32,000       438,702       478,905             447,233     0.109
   64,000       941,447     1,021,810             958,465     0.250
  128,000     2,010,131     2,171,620           2,044,929     0.579

--- Production workload: n = 10,000,000 orders (theoretical) ---
n*log2(n)              = 232,534,967
worst case n*24 - 2^24 + 1 = 223,222,785
quadratic sort n^2/2   = 50,000,000,000,000
memory: data 160 MB + buffer 160 MB = 320 MB (16-byte records)

--- External merge sort demo: 100,000 orders, 10,000 per run ---
runs written: 10; k-way merge passes: 1; stable & correct: True

Graph saved: Report/merge_sort_comparisons.png
```
