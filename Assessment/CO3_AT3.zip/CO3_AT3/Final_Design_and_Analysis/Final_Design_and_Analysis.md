# Final Algorithmic Design and Analysis – KartIQ Divide-and-Conquer Engine

## 1. Final design (one choice per module)
| Module | Chosen algorithm | Time complexity | Extra memory | Reason for the choice |
|---|---|---|---|---|
| 1 – Nightly Order Consolidation | **Stable Merge Sort** with one reusable buffer; external k-way merge when data exceeds RAM | Θ(n log n) in every case (≈ 2.2 × 10⁸ comparisons for 10⁷ orders) | O(n) buffer (≈ 160 MB for 10⁷ 16-byte records) | Equal timestamps must keep gateway arrival order; running time must not depend on input order. |
| 2 – Live Seller Leaderboard | **Quick Sort** with median-of-three (or random) pivot, insertion-sort cut-off 16, recursion on the smaller part | Average Θ(n log n) (≈ 2.3 × 10⁶ for 10⁵ sellers); worst Θ(n²) but very unlikely | O(log n) stack | In-place and fast; the pivot fix removes the nearly-sorted slowdown (35× fewer comparisons than first-element pivot at n = 4,000 in the experiment). |
| 3 – Order Lookup | **Binary search, first-occurrence version** | Θ(log n): at most 24 probes for 10⁷ orders | O(1) | Uses the sorted list from Module 1; returns the earliest order for a timestamp. |
| 4 – Recommendation Scores | **Hybrid Strassen**: recurse to a cut-off of 64–128, then optimised conventional multiplication | Θ(n^2.81); 629,407,744 multiplications for n = 1,024 (cut-off 64) vs 1,073,741,824 | Θ(n²) temporaries | Fewer multiplications than n³ while keeping the speed of tuned small-block kernels. |

## 2. Main trade-off and condition for changing each decision
| Module | Main trade-off | Change the decision when… |
|---|---|---|
| 1 | Guaranteed time and stability cost O(n) extra memory (an unstable in-place sort would break the audit order). | Data far exceeds RAM → external merge sort; each gateway already delivers sorted streams → k-way merge, O(n log k). |
| 2 | Not stable and the worst case Θ(n²) remains possible in theory; median-of-three is weak on some inputs (reverse-sorted test: 506,360 comparisons for n = 2,000) and all-equal data. | A hard real-time bound is needed → introsort / Heap Sort; many ties → three-way partition; only a few scores change → insertion sort, O(n + d). |
| 3 | Requires the data to stay sorted; inserting into an array is O(n). | Orders arrive continuously → B-tree / balanced tree; lookups by exact order ID → hash table, O(1). |
| 4 | Fewer multiplications but more additions, more memory and slightly lower numerical stability; measured pure-Python and NumPy runs were **not** faster than conventional multiplication. | n is small, an optimised BLAS/GPU library is available (it won in our experiment), or the matrices are sparse → use that instead. |

## 3. Complexity comparison of the alternatives
| Module | Poor / current choice | Cost for the production workload | Proposed choice | Cost |
|---|---|---|---|---|
| 1 | Quadratic sort (or unstable sort) | n²/2 = 5 × 10¹³ comparisons (or wrong order) | Merge Sort | ≤ 223,222,785 comparisons |
| 2 | Quick Sort, first-element pivot | n(n−1)/2 = 4,999,950,000 comparisons | Median-of-three / random pivot | ≈ 1.7–2.3 × 10⁶ comparisons |
| 3 | Linear scan | up to 10,000,000 comparisons | Binary search | ≤ 24 probes |
| 4 | Conventional multiplication | 1,073,741,824 multiplications (2,146,435,072 operations) | Hybrid Strassen (cut-off 64) | 629,407,744 multiplications (1,301,696,512 operations) |

![before vs after](before_vs_after.png)

## 4. Memory requirements summary
| Module | Memory | Note |
|---|---|---|
| 1 | Data 160 MB + buffer 160 MB = 320 MB (16-byte records) | Disk-based runs if RAM is smaller. |
| 2 | 100,000 scores in place, O(log n) stack | Negligible. |
| 3 | O(1) | Only the sorted array from Module 1. |
| 4 | Two 1,024² matrices plus Θ(n²) temporaries | With 8-byte values, each matrix is 8 MiB; temporaries add a small multiple of that. |

## 5. Recommendations
1. Deploy stable Merge Sort for the nightly report; add the k-way merge of gateway streams to cut the work further.
2. Replace the first-element pivot by median-of-three or a random pivot, with insertion-sort cut-off and smaller-side recursion; consider introsort for a worst-case guarantee.
3. Use the first-occurrence binary search on the Module 1 output; keep the list sorted or move to a tree when new orders must be inserted live.
4. For recommendation scores, benchmark first. Use an optimised BLAS/GPU library as the default; use hybrid Strassen (cut-off 64–256) only if measurements on the production hardware show a gain.
5. Re-measure after each change: the repository's `run_all.sh` regenerates every result, graph and screenshot.

## 6. Overall conclusion
Each module is limited by a different property of its data – ties (Module 1), near-sortedness (Module 2), sortedness (Module 3) and size (Module 4). Choosing the divide-and-conquer algorithm and variant that fits that property reduces the work by factors of about 10⁵ (sorting 10⁷ orders), 10³ (leaderboard refresh) and 10⁵ (lookups), and by about 40% for matrix multiplication in operation count. Experiments also show the limits: Strassen's theoretical advantage did not translate into faster measured runs against optimised libraries.
