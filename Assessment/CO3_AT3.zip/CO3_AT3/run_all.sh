#!/usr/bin/env bash
# Runs all four modules and stores the console output next to each report.
set -e
cd "$(dirname "$0")"
python3 Module_1_Merge_Sort/Source_Code/merge_sort.py > Module_1_Merge_Sort/Report/execution_output.txt
python3 Module_2_Quick_Sort/Source_Code/quick_sort.py > Module_2_Quick_Sort/Report/execution_output.txt
python3 Module_3_Binary_Search/Source_Code/binary_search.py > Module_3_Binary_Search/Report/execution_output.txt
python3 Module_4_Strassen_Matrix_Multiplication/Source_Code/strassen.py > Module_4_Strassen_Matrix_Multiplication/Report/execution_output.txt
python3 Supporting_Files/tools/final_charts.py
python3 Supporting_Files/tools/make_screenshots.py
echo "All modules executed. Outputs, graphs and screenshots refreshed."
