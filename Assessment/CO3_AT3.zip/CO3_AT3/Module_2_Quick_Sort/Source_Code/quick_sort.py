"""
CSA06 CO3 - Module 2: Live Seller Leaderboard (Quick Sort)
Compares the CURRENT first-element pivot with the IMPROVED median-of-three
(+ insertion-sort cut-off) and a random pivot.
Run:  python quick_sort.py
"""
import csv, math, random, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / "Supporting_Files" / "datasets" / "seller_scores_sample.csv"
RESULTS = ROOT / "Supporting_Files" / "results"
REPORT = HERE.parent / "Report"


# ------------------------------------------------------------- partition
def partition(a, lo, hi, st, show=False):
    """Pivot = a[lo].  i moves right past elements <= pivot, j moves left past elements > pivot.
    Swap a[i], a[j] while i < j; finally put the pivot at a[j]."""
    pivot = a[lo]
    i, j = lo, hi + 1
    if show:
        print(f"  start        : {a[lo:hi + 1]}   pivot = {pivot}")
    while True:
        i += 1
        while i <= hi:
            st["cmp"] += 1
            if a[i] <= pivot: i += 1
            else: break
        j -= 1
        while True:
            st["cmp"] += 1
            if a[j] > pivot: j -= 1
            else: break
        if i >= j:
            break
        a[i], a[j] = a[j], a[i]
        if show:
            print(f"  swap a[{i}],a[{j}]: {a[lo:hi + 1]}")
    a[lo], a[j] = a[j], a[lo]
    if show:
        print(f"  pivot -> a[{j}] : {a[lo:j]} |{a[j]}| {a[j + 1:hi + 1]}")
    return j


# ---------------------------------------- 1) CURRENT: first-element pivot
def quick_first(a, st):
    """Explicit stack (a Python recursion would overflow on sorted data). Tracks max depth."""
    stack = [(0, len(a) - 1, 1)]
    while stack:
        lo, hi, d = stack.pop()
        st["depth"] = max(st["depth"], d)
        if lo < hi:
            p = partition(a, lo, hi, st)
            stack.append((lo, p - 1, d + 1)); stack.append((p + 1, hi, d + 1))


# ------------------------- 2) IMPROVED: median-of-three + insertion cut-off
def insertion(a, lo, hi, st):
    for k in range(lo + 1, hi + 1):
        x, j = a[k], k - 1
        while j >= lo:
            st["cmp"] += 1
            if a[j] > x: a[j + 1] = a[j]; j -= 1
            else: break
        a[j + 1] = x


def median3_to_front(a, lo, hi, st):
    mid = (lo + hi) // 2
    st["cmp"] += 3
    trio = sorted([(a[lo], lo), (a[mid], mid), (a[hi], hi)])
    m = trio[1][1]
    a[lo], a[m] = a[m], a[lo]


def quick_improved(a, lo, hi, st, depth=1, cutoff=16):
    while lo < hi:
        st["depth"] = max(st["depth"], depth)
        if hi - lo + 1 <= cutoff:
            insertion(a, lo, hi, st); return
        median3_to_front(a, lo, hi, st)
        p = partition(a, lo, hi, st)
        if p - lo < hi - p:                       # recurse on the smaller part, loop on the larger
            quick_improved(a, lo, p - 1, st, depth + 1, cutoff); lo = p + 1
        else:
            quick_improved(a, p + 1, hi, st, depth + 1, cutoff); hi = p - 1
        depth += 1


# ------------------------------------------------ 3) random pivot
def quick_random(a, lo, hi, st, rnd, depth=1):
    while lo < hi:
        st["depth"] = max(st["depth"], depth)
        r = rnd.randint(lo, hi)
        a[lo], a[r] = a[r], a[lo]
        p = partition(a, lo, hi, st)
        if p - lo < hi - p:
            quick_random(a, lo, p - 1, st, rnd, depth + 1); lo = p + 1
        else:
            quick_random(a, p + 1, hi, st, rnd, depth + 1); hi = p - 1
        depth += 1


def run(kind, data):
    a, st = list(data), {"cmp": 0, "depth": 0}
    t0 = time.perf_counter()
    if kind == "first": quick_first(a, st)
    elif kind == "median3": quick_improved(a, 0, len(a) - 1, st)
    else: quick_random(a, 0, len(a) - 1, st, random.Random(5))
    st["time"] = time.perf_counter() - t0
    assert a == sorted(data), f"{kind} produced a wrong result"
    return a, st


def nearly_sorted(n, swaps_pct=1.0, seed=3):
    rnd = random.Random(seed)
    a = list(range(1, n + 1))
    for _ in range(max(1, int(n * swaps_pct / 100))):
        i, j = rnd.randrange(n), rnd.randrange(n)
        a[i], a[j] = a[j], a[i]
    return a


def trace_sort(a, lo, hi, depth, st):
    """Recursive trace of the full sample sort (divide = partition, combine = nothing)."""
    if lo >= hi:
        if lo == hi: print(f"{'  ' * depth}single element {a[lo]} (sorted)")
        return
    print(f"{'  ' * depth}DIVIDE  a[{lo}..{hi}] = {a[lo:hi + 1]}")
    p = partition(a, lo, hi, st)
    print(f"{'  ' * depth}  pivot {a[p]} fixed at index {p}; left={a[lo:p]} right={a[p + 1:hi + 1]}")
    trace_sort(a, lo, p - 1, depth + 1, st)
    trace_sort(a, p + 1, hi, depth + 1, st)


def main():
    print("=" * 78 + "\nMODULE 2 - QUICK SORT FOR THE LIVE SELLER LEADERBOARD\n" + "=" * 78)
    with open(DATA, newline="") as f:
        scores = [int(r[1]) for r in list(csv.reader(f))[1:]]
    print("\nSample scores:", scores)

    print("\n--- One partition step (first element as pivot) ---")
    a = list(scores); st = {"cmp": 0, "depth": 0}
    p = partition(a, 0, len(a) - 1, st, show=True)
    print(f"  comparisons in this partition: {st['cmp']}; pivot final index = {p}")
    assert p == 3 and a == [8, 17, 29, 42, 55, 63]

    print("\n--- Full divide / conquer trace on the sample ---")
    a = list(scores); st = {"cmp": 0, "depth": 0}
    trace_sort(a, 0, len(a) - 1, 0, st)
    print(f"Sorted: {a}   total comparisons: {st['cmp']}")
    assert a == sorted(scores)

    print("\n--- Why first-element pivot is slow: already sorted sample [8,17,29,42,55,63] ---")
    a = sorted(scores); st = {"cmp": 0, "depth": 0}
    trace_sort(a, 0, len(a) - 1, 0, st)
    print(f"comparisons = {st['cmp']}  (every level peels off only ONE element: quadratic growth, recursion depth = n = {len(a)})")

    print("\n--- Correctness on different input patterns (n = 2,000) ---")
    n = 2000; rnd = random.Random(11)
    patterns = {
        "random": [rnd.randrange(10 ** 6) for _ in range(n)],
        "sorted": list(range(n)),
        "reverse": list(range(n, 0, -1)),
        "nearly sorted": nearly_sorted(n),
        "all equal": [7] * n,
    }
    for name, data in patterns.items():
        res = []
        for kind in ("first", "median3", "random"):
            _, s = run(kind, data); res.append(f"{kind}={s['cmp']:,}")
        print(f"{name:>13}: " + "  ".join(res) + "   -> all correct")

    print("\n--- Experiment: NEARLY SORTED data (1% of positions swapped) ---")
    print(f"{'n':>7} | {'first-pivot cmp':>16} {'depth':>6} | {'median-of-3 cmp':>16} {'depth':>6} | {'random cmp':>11} | {'n log2 n':>10} {'n(n-1)/2':>13}")
    rows = []
    for n in (250, 500, 1000, 2000, 4000):
        data = nearly_sorted(n)
        _, f1 = run("first", data); _, f2 = run("median3", data); _, f3 = run("random", data)
        rows.append((n, f1["cmp"], f1["depth"], f2["cmp"], f2["depth"], f3["cmp"], round(n * math.log2(n)), n * (n - 1) // 2,
                     round(f1["time"], 4), round(f2["time"], 4)))
        print(f"{n:>7} | {f1['cmp']:>16,} {f1['depth']:>6} | {f2['cmp']:>16,} {f2['depth']:>6} | {f3['cmp']:>11,} | {round(n * math.log2(n)):>10,} {n * (n - 1) // 2:>13,}")
    RESULTS.mkdir(parents=True, exist_ok=True)
    with open(RESULTS / "module2_results.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["n", "first_pivot_cmp", "first_depth", "median3_cmp", "median3_depth", "random_cmp", "n_log2_n", "n_n_minus_1_over_2", "first_sec", "median3_sec"])
        w.writerows(rows)

    print("\n--- Production workload: n = 100,000 sellers (theoretical) ---")
    n = 100_000
    print(f"worst / first-pivot on nearly sorted : n(n-1)/2 = {n * (n - 1) // 2:,}")
    print(f"best (balanced splits)               : n log2 n = {n * math.log2(n):,.0f}")
    print(f"average (random / median-of-3)       : 2 n ln n = {2 * n * math.log(n):,.0f}")
    print(f"ratio worst / average                : {n * (n - 1) / 2 / (2 * n * math.log(n)):,.0f}x")

    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        ns = [r[0] for r in rows]
        plt.figure(figsize=(7, 4.2))
        plt.plot(ns, [r[1] for r in rows], "o-", label="first-element pivot")
        plt.plot(ns, [r[3] for r in rows], "s-", label="median-of-three + insertion cut-off")
        plt.plot(ns, [r[5] for r in rows], "d-", label="random pivot")
        plt.plot(ns, [r[6] for r in rows], "k--", label="n log2 n")
        plt.yscale("log"); plt.xscale("log")
        plt.xlabel("number of sellers n"); plt.ylabel("comparisons (log scale)")
        plt.title("Quick Sort on nearly sorted scores"); plt.legend(); plt.grid(alpha=.3, which="both")
        plt.tight_layout(); plt.savefig(REPORT / "quick_sort_comparisons.png", dpi=150); plt.close()
        print("\nGraph saved: Report/quick_sort_comparisons.png")
    except ImportError:
        print("matplotlib not installed - graph skipped")


if __name__ == "__main__":
    main()
