# Module 2 – Quick Sort for the Live Seller Leaderboard

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Re-sort 100,000 seller scores every few seconds; the data is nearly sorted. |
| Key issues | **Worst-case behaviour** (first-element pivot on sorted data), recursion depth, in-place sorting; stability is not required. |
| Consequence of a poor choice | About n(n − 1)/2 ≈ 5 × 10⁹ comparisons per refresh, so the board freezes; recursion depth ≈ n risks stack overflow. |

## 2. Algorithm design
* **Divide** – PARTITION around a pivot; the pivot lands in its final position, giving a left part (≤ pivot) and a right part (> pivot).
* **Conquer** – sort both parts recursively.
* **Combine** – nothing to do, the array is already in place.

Three variants are implemented and compared: (1) **current** first-element pivot, (2) **improved** median-of-three with insertion-sort cut-off (16) and recursion on the smaller side, (3) **random** pivot. Pseudocode: `Pseudocode/quick_sort_pseudocode.md`.

## 3. One partition step on 42, 17, 63, 8, 55, 29
```text
start        : [42, 17, 63, 8, 55, 29]   pivot = 42
swap a[2],a[5]: [42, 17, 29, 8, 55, 63]
pivot -> a[3] : [8, 17, 29] |42| [55, 63]       (7 comparisons)
```
The left part {8, 17, 29} and right part {55, 63} are then sorted recursively (full trace in the output appendix). Total comparisons for the whole sample: 17.

## 4. Why the first-element pivot is slow
On sorted or nearly sorted data the first element is the smallest of its range. The partition then produces an empty left part and n − 1 elements on the right, level after level (see the second trace in the output: pivots 8, 17, 29, 42, 55 peel off one element each). The result is n levels with about n work each.

## 5. Recurrences and solutions
* **Best case** (pivot = median): `T(n) = 2T(n/2) + n` → **Θ(n log n)** (Master theorem, case 2).
* **Worst case** (pivot = min or max): `T(n) = T(n−1) + (n−1)` → (n−1) + (n−2) + … + 1 = n(n−1)/2 → **Θ(n²)**.
* **Average case**: ≈ 2 n ln n ≈ 1.39 n log₂ n → Θ(n log n).

## 6. Production workload: n = 100,000 sellers
| Case | Formula | Comparisons |
|---|---|---|
| First-element pivot on nearly sorted data (≈ worst) | n(n−1)/2 | 4,999,950,000 |
| Best case | n log₂ n | 1,660,964 |
| Average (random / median-of-three) | 2 n ln n | 2,302,585 |

The current design does roughly 2,000–3,000 times more work than a good pivot strategy.

## 7. Experiment: nearly sorted data (1% of positions swapped)
| n | first pivot | depth | median-of-three | depth | random pivot | n log₂ n |
|---|---|---|---|---|---|---|
| 250 | 19,961 | 144 | 1,325 | 6 | 2,077 | 1,991 |
| 500 | 68,727 | 265 | 3,046 | 6 | 4,818 | 4,483 |
| 1,000 | 204,897 | 424 | 7,109 | 8 | 11,914 | 9,966 |
| 2,000 | 638,770 | 795 | 16,282 | 10 | 26,317 | 21,932 |
| 4,000 | 1,316,235 | 750 | 37,055 | 12 | 58,886 | 47,863 |

At n = 4,000 the first-element pivot needs about 35 times more comparisons than median-of-three (and 22 times more than a random pivot), and its recursion depth is in the hundreds, whereas the improved version stays near n log₂ n with depth 6–12.

![comparisons](quick_sort_comparisons.png)

## 8. Improved pivot strategy and justification
* **Median-of-three** (first, middle, last): on sorted/nearly sorted data the middle element is close to the true median, so splits are balanced. Cost: 3 extra comparisons per partition.
* **Random pivot:** expected 2 n ln n for every input order; no input can force the worst case.
* **Insertion sort for ≤ 16 elements** (fast on nearly sorted data) and **recursion on the smaller part first** (stack depth O(log n)).

## 9. Limitations and trade-offs (observed in the experiments)
* Quick Sort is **not stable** (not needed for scores).
* Median-of-three is not a guarantee: on the *reverse-sorted* test it needed 506,360 comparisons for n = 2,000, well above n log₂ n ≈ 21,932 (see output). A random pivot did not show this weakness.
* With **many equal keys** this partition scheme degrades to Θ(n²) for every pivot rule (all-equal test: about 2 × 10⁶ comparisons). A three-way (Dutch national flag) partition fixes this.
* Worst case is still Θ(n²) in theory; **introsort** (switch to Heap Sort at depth 2 log n) gives a hard O(n log n) bound.

## 10. Improvements recommended
Use median-of-three or random pivot with insertion-sort cut-off; add three-way partitioning if many ties are expected; if only a few scores change between refreshes, insertion sort / an adaptive sort (O(n + d) for d inversions) can be even cheaper.

## 11. Screenshots
![source](screenshots/source_quick_sort.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
==============================================================================
MODULE 2 - QUICK SORT FOR THE LIVE SELLER LEADERBOARD
==============================================================================

Sample scores: [42, 17, 63, 8, 55, 29]

--- One partition step (first element as pivot) ---
  start        : [42, 17, 63, 8, 55, 29]   pivot = 42
  swap a[2],a[5]: [42, 17, 29, 8, 55, 63]
  pivot -> a[3] : [8, 17, 29] |42| [55, 63]
  comparisons in this partition: 7; pivot final index = 3

--- Full divide / conquer trace on the sample ---
DIVIDE  a[0..5] = [42, 17, 63, 8, 55, 29]
  pivot 42 fixed at index 3; left=[8, 17, 29] right=[55, 63]
  DIVIDE  a[0..2] = [8, 17, 29]
    pivot 8 fixed at index 0; left=[] right=[17, 29]
    DIVIDE  a[1..2] = [17, 29]
      pivot 17 fixed at index 1; left=[] right=[29]
      single element 29 (sorted)
  DIVIDE  a[4..5] = [55, 63]
    pivot 55 fixed at index 4; left=[] right=[63]
    single element 63 (sorted)
Sorted: [8, 17, 29, 42, 55, 63]   total comparisons: 17

--- Why first-element pivot is slow: already sorted sample [8,17,29,42,55,63] ---
DIVIDE  a[0..5] = [8, 17, 29, 42, 55, 63]
  pivot 8 fixed at index 0; left=[] right=[17, 29, 42, 55, 63]
  DIVIDE  a[1..5] = [17, 29, 42, 55, 63]
    pivot 17 fixed at index 1; left=[] right=[29, 42, 55, 63]
    DIVIDE  a[2..5] = [29, 42, 55, 63]
      pivot 29 fixed at index 2; left=[] right=[42, 55, 63]
      DIVIDE  a[3..5] = [42, 55, 63]
        pivot 42 fixed at index 3; left=[] right=[55, 63]
        DIVIDE  a[4..5] = [55, 63]
          pivot 55 fixed at index 4; left=[] right=[63]
          single element 63 (sorted)
comparisons = 25  (every level peels off only ONE element: quadratic growth, recursion depth = n = 6)

--- Correctness on different input patterns (n = 2,000) ---
       random: first=25,938  median3=23,211  random=27,019   -> all correct
       sorted: first=2,002,998  median3=16,133  random=26,470   -> all correct
      reverse: first=2,001,998  median3=506,360  random=25,338   -> all correct
nearly sorted: first=638,770  median3=16,282  random=26,317   -> all correct
    all equal: first=2,000,999  median3=2,006,831  random=2,000,999   -> all correct

--- Experiment: NEARLY SORTED data (1% of positions swapped) ---
      n |  first-pivot cmp  depth |  median-of-3 cmp  depth |  random cmp |   n log2 n      n(n-1)/2
    250 |           19,961    144 |            1,325      6 |       2,077 |      1,991        31,125
    500 |           68,727    265 |            3,046      6 |       4,818 |      4,483       124,750
   1000 |          204,897    424 |            7,109      8 |      11,914 |      9,966       499,500
   2000 |          638,770    795 |           16,282     10 |      26,317 |     21,932     1,999,000
   4000 |        1,316,235    750 |           37,055     12 |      58,886 |     47,863     7,998,000

--- Production workload: n = 100,000 sellers (theoretical) ---
worst / first-pivot on nearly sorted : n(n-1)/2 = 4,999,950,000
best (balanced splits)               : n log2 n = 1,660,964
average (random / median-of-3)       : 2 n ln n = 2,302,585
ratio worst / average                : 2,171x

Graph saved: Report/quick_sort_comparisons.png
```
