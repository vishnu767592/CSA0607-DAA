# Pseudocode – Quick Sort for the Live Seller Leaderboard

## A. Partition (pivot = first element of the range)
```
PARTITION(A, lo, hi)
    pivot <- A[lo] ; i <- lo ; j <- hi + 1
    loop
        repeat i <- i + 1 until i > hi or A[i] > pivot      // scan right
        repeat j <- j - 1 until A[j] <= pivot               // scan left
        if i >= j then exit loop
        swap A[i], A[j]
    swap A[lo], A[j]                                         // pivot goes to its final place
    return j
```

## B. CURRENT implementation – first-element pivot
```
QUICK-SORT(A, lo, hi)
    if lo < hi then
        p <- PARTITION(A, lo, hi)        // DIVIDE
        QUICK-SORT(A, lo, p - 1)         // CONQUER
        QUICK-SORT(A, p + 1, hi)         // CONQUER      (COMBINE = nothing, the array is already in place)
```
Best case `T(n) = 2T(n/2) + n = Theta(n log n)`; worst case (sorted / nearly sorted) `T(n) = T(n-1) + n - 1 = Theta(n^2)`.

## C. IMPROVED implementation – median-of-three + insertion-sort cut-off + smaller-side recursion
```
QUICK-SORT-IMPROVED(A, lo, hi)
    while lo < hi do
        if hi - lo + 1 <= 16 then INSERTION-SORT(A, lo, hi) ; return
        m <- (lo + hi) div 2
        move the median of A[lo], A[m], A[hi] to A[lo]           // median-of-three pivot
        p <- PARTITION(A, lo, hi)
        if (p - lo) < (hi - p) then                              // recurse on SMALLER part, loop on larger
            QUICK-SORT-IMPROVED(A, lo, p - 1) ; lo <- p + 1
        else
            QUICK-SORT-IMPROVED(A, p + 1, hi) ; hi <- p - 1
```
Stack depth is `O(log n)`.  Random-pivot variant: swap `A[lo]` with `A[random(lo, hi)]` before `PARTITION`.
