# Module 4 – Strassen's Matrix Multiplication for Recommendation Scores

## 1. Understanding the module
| Item | Detail |
|---|---|
| Requirement | Compute C = A × B for n × n matrices, n = 1,024. |
| Key issues | Matrix size (n³ ≈ 1.07 × 10⁹ multiplications), power-of-two sizes, temporary memory, recursion overhead. |
| Consequence of a poor choice | Conventional multiplication is too slow, so scores refresh only daily; Strassen recursed down to 1 × 1 is slow in practice (overhead, extra additions, cache misses). |

## 2. Algorithm design
* **Divide** – split each matrix into four (n/2) × (n/2) blocks.
* **Conquer** – compute **7** recursive block products M1…M7 (instead of 8).
* **Combine** – build C from additions and subtractions.

```text
M1 = (A11 + A22)(B11 + B22)      C11 = M1 + M4 - M5 + M7
M2 = (A21 + A22) B11             C12 = M3 + M5
M3 = A11 (B12 - B22)             C21 = M2 + M4
M4 = A22 (B21 - B11)             C22 = M1 - M2 + M3 + M6
M5 = (A11 + A12) B22
M6 = (A21 - A11)(B11 + B12)
M7 = (A12 - A22)(B21 + B22)
```
Pseudocode: `Pseudocode/strassen_pseudocode.md`; program: `Source_Code/strassen.py` (reads `matrices_sample.json`; pads when n is not a power of 2).

## 3. Verification on the 2 × 2 sample
A = [[1, 7], [3, 5]], B = [[1, 3], [7, 5]]

| Product | Calculation | Value |
|---|---|---|
| M1 | (1+5)(1+5) | 36 |
| M2 | (3+5)·1 | 8 |
| M3 | 1·(3−5) | −2 |
| M4 | 5·(7−1) | 30 |
| M5 | (1+7)·5 | 40 |
| M6 | (3−1)(1+3) | 8 |
| M7 | (7−5)(7+5) | 24 |

C11 = 36+30−40+24 = 50, C12 = −2+40 = 38, C21 = 8+30 = 38, C22 = 36−8−2+8 = 34 → **C = [[50, 38], [38, 34]]**, equal to the conventional product. The program also tests random matrices of size 4…128 (cut-offs 1 and 8) and a 100 × 100 matrix (padded to 128), all equal to the conventional result.

## 4. Recurrence and solution
Seven half-size products and 18 block additions/subtractions: `T(n) = 7T(n/2) + 18(n/2)² = 7T(n/2) + Θ(n²)`. Since log₂ 7 ≈ 2.807 > 2, the leaves dominate (Master theorem case 1): **T(n) = Θ(n^(log₂ 7)) ≈ Θ(n^2.81)**.
For n = 2^k: multiplications `M(k) = 7^k`; additions `A(n) = 6(7^k − 4^k)`. The program measured exactly these values for n = 2…32.
Extra space: Θ(n²) for the temporary matrices.

## 5. Production workload: n = 1,024 (k = 10)
| Method | Multiplications | Additions | Total | vs conventional |
|---|---|---|---|---|
| Conventional | 1,073,741,824 | 1,072,693,248 | 2,146,435,072 | 100.0% |
| Strassen to 1 × 1 | 282,475,249 | 1,688,560,038 | 1,971,035,287 | 91.8% |
| Hybrid, cut-off 128 | 719,323,136 | 741,130,240 | 1,460,453,376 | 68.0% |
| Hybrid, cut-off 64 | 629,407,744 | 672,288,768 | 1,301,696,512 | 60.6% |
| Hybrid, cut-off 32 | 550,731,776 | 630,492,160 | 1,181,223,936 | 55.0% |
| Hybrid, cut-off 16 | 481,890,304 | 626,189,568 | 1,108,079,872 | 51.6% |

Pure Strassen uses only 7¹⁰/1024³ = 26.3% of the multiplications (3.8 times fewer) but needs 1.69 × 10⁹ additions, so the **total saving is only about 8%**.

![multiplications](strassen_multiplications.png)
![total operations](strassen_total_operations.png)

## 6. Measured running time (machine dependent)
| n | conventional | Strassen cut = 1 | hybrid cut = 16 | hybrid cut = 32 |
|---|---|---|---|---|
| 32 | 0.0026 s | 0.0494 s | 0.0029 s | 0.0022 s |
| 64 | 0.0171 s | 0.4470 s | 0.0340 s | 0.0267 s |
| 128 | 0.1582 s | 3.2596 s | 0.1725 s | 0.1580 s |

NumPy experiment, n = 1,024: `numpy.matmul` (optimised BLAS) 0.043 s versus hybrid Strassen 0.082–0.113 s (cut-offs 128, 256, 64). **Strassen was never faster in any measurement** (a hybrid whose cut-off equals n is just the conventional method), even though it performs fewer operations on paper. Timings come from the run saved in `execution_output.txt` and vary a little between runs and machines.

## 7. Why Strassen is not faster in practice, and the practical hybrid
* 18 extra block additions with large constants and temporary matrices (Θ(n²) memory, allocation and copying).
* Recursion and slicing overhead on tiny blocks – pure Strassen (cut = 1) was about 20× slower at n = 128.
* Conventional/BLAS code is cache-blocked, vectorised and multithreaded; Strassen's irregular memory access cannot match it.
* Needs power-of-two padding; slightly weaker numerical stability.

**Hybrid:** run Strassen only while the blocks are large, then call an optimised conventional kernel below a cut-off n₀ (typically 64–256, tuned by measurement). For n = 1,024 and n₀ = 64 this needs 7⁴ = 2,401 base products of size 64 × 64 (629,407,744 multiplications, 58.6% of conventional). The 7 sub-products are independent and can run on separate cores.

## 8. Recommendation
Use hybrid Strassen only after benchmarking on the production hardware. If an optimised BLAS/GPU library is available, calling it directly can beat any hand-written Strassen (as measured above); Strassen pays off mainly for very large matrices or when multiplications are much more expensive than additions.

## 9. Screenshots
![source](screenshots/source_strassen.png)
![output](screenshots/program_output.png)

## Appendix – full execution output
```text
==============================================================================
MODULE 4 - STRASSEN'S MATRIX MULTIPLICATION FOR RECOMMENDATION SCORES
==============================================================================

A = [[1, 7], [3, 5]] 
B = [[1, 3], [7, 5]]

--- Strassen on the 2x2 sample (divide into 1x1 blocks) ---
  M1 = (1+5)(1+5)     = 36
  M2 = (3+5)*1        = 8
  M3 = 1*(3-5)        = -2
  M4 = 5*(7-1)        = 30
  M5 = (1+7)*5        = 40
  M6 = (3-1)(1+3)     = 8
  M7 = (7-5)(7+5)     = 24
  C11 = M1+M4-M5+M7 = 50
  C12 = M3+M5       = 38
  C21 = M2+M4       = 38
  C22 = M1-M2+M3+M6 = 34

Strassen (program) : [[50, 38], [38, 34]] | multiplications = 7, additions/subtractions = 18
Conventional       : [[50, 38], [38, 34]] | multiplications = 8
Verification       : Strassen == conventional == expected -> PASS

--- Correctness on random matrices (cutoff = 1 and cutoff = 8) ---
  n =   4: PASS
  n =   8: PASS
  n =  16: PASS
  n =  32: PASS
  n =  64: PASS
  n = 128: PASS
  n = 100 (padded to 128): PASS

--- Operation counts measured by the program vs formulas (cutoff = 1) ---
    n  measured mults           7^k  measured adds    6(7^k-4^k)
    2               7             7             18            18
    4              49            49            198           198
    8             343           343          1,674         1,674
   16           2,401         2,401         12,870        12,870
   32          16,807        16,807         94,698        94,698

--- Production workload n = 1,024: scalar operation counts (from the recurrences) ---
method                 multiplications        additions             total  vs conventional
Conventional             1,073,741,824    1,072,693,248     2,146,435,072          100.0%
Strassen to 1x1            282,475,249    1,688,560,038     1,971,035,287           91.8%
Hybrid cut-off 128         719,323,136      741,130,240     1,460,453,376           68.0%
Hybrid cut-off 64          629,407,744      672,288,768     1,301,696,512           60.6%
Hybrid cut-off 32          550,731,776      630,492,160     1,181,223,936           55.0%
Hybrid cut-off 16          481,890,304      626,189,568     1,108,079,872           51.6%

--- Running time (pure Python, seconds) ---
    n  conventional  Strassen cut=1  hybrid cut=16  hybrid cut=32
   32        0.0026          0.0494         0.0029         0.0022
   64        0.0171          0.4470         0.0340         0.0267
  128        0.1582          3.2596         0.1725         0.1580

--- NumPy experiment (optimised BLAS base case), n = 1,024 ---
  numpy matmul (BLAS)            : 0.043 s
  Strassen hybrid, cut-off 256  : 0.095 s   correct: True
  Strassen hybrid, cut-off 128  : 0.082 s   correct: True
  Strassen hybrid, cut-off  64  : 0.113 s   correct: True

Graphs saved: Report/strassen_multiplications.png, Report/strassen_total_operations.png
```
