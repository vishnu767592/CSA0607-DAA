# Pseudocode – Strassen's Matrix Multiplication (with practical hybrid cut-off)

```
STRASSEN(A, B, n, CUTOFF)                   // n is a power of 2
    if n <= CUTOFF then return CONVENTIONAL(A, B)         // hybrid base case (CUTOFF = 1 gives pure Strassen)
    split A into A11 A12 / A21 A22 and B into B11 B12 / B21 B22          // DIVIDE (blocks of n/2)
    M1 <- STRASSEN(A11 + A22, B11 + B22)                                  // CONQUER: only 7 products
    M2 <- STRASSEN(A21 + A22, B11)
    M3 <- STRASSEN(A11,       B12 - B22)
    M4 <- STRASSEN(A22,       B21 - B11)
    M5 <- STRASSEN(A11 + A12, B22)
    M6 <- STRASSEN(A21 - A11, B11 + B12)
    M7 <- STRASSEN(A12 - A22, B21 + B22)
    C11 <- M1 + M4 - M5 + M7                                              // COMBINE
    C12 <- M3 + M5
    C21 <- M2 + M4
    C22 <- M1 - M2 + M3 + M6
    return C assembled from C11 C12 / C21 C22

CONVENTIONAL(A, B)
    for i, j: C[i][j] <- sum over k of A[i][k] * B[k][j]                  // n^3 multiplications

STRASSEN-ANY(A, B, n)                       // n not a power of 2
    m <- smallest power of 2 >= n ; pad A and B with zeros to m x m
    C <- STRASSEN(A', B', m, CUTOFF) ; return the top-left n x n block of C
```

Recurrence: `T(n) = 7T(n/2) + 18(n/2)^2 = 7T(n/2) + Theta(n^2)` -> `Theta(n^(log2 7)) = Theta(n^2.807)`.
Scalar multiplications for `n = 2^k`: `7^k`; additions: `6(7^k - 4^k)`.  Extra space `Theta(n^2)`.
