"""
CSA06 CO3 - Module 4: Recommendation Scores (Strassen's matrix multiplication)
Run:  python strassen.py
"""
import csv, json, math, random, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / "Supporting_Files" / "datasets" / "matrices_sample.json"
RESULTS = ROOT / "Supporting_Files" / "results"
REPORT = HERE.parent / "Report"


# ----------------------------------------------------------- matrix helpers
def add(X, Y, st):
    n = len(X); st["add"] += n * n
    return [[X[i][j] + Y[i][j] for j in range(n)] for i in range(n)]

def sub(X, Y, st):
    n = len(X); st["add"] += n * n
    return [[X[i][j] - Y[i][j] for j in range(n)] for i in range(n)]

def split(X):
    h = len(X) // 2
    return ([r[:h] for r in X[:h]], [r[h:] for r in X[:h]], [r[:h] for r in X[h:]], [r[h:] for r in X[h:]])

def join(C11, C12, C21, C22):
    return [a + b for a, b in zip(C11, C12)] + [a + b for a, b in zip(C21, C22)]


def conventional(A, B, st=None):
    n = len(A)
    if st is not None:
        st["mul"] += n ** 3; st["add"] += n * n * (n - 1)
    Bt = list(zip(*B))
    return [[sum(x * y for x, y in zip(row, col)) for col in Bt] for row in A]


def strassen(A, B, st, cutoff=1, trace=None, depth=0):
    """DIVIDE into 4 blocks, CONQUER with 7 recursive products, COMBINE with additions."""
    n = len(A)
    if n <= cutoff:
        return conventional(A, B, st)
    A11, A12, A21, A22 = split(A)
    B11, B12, B21, B22 = split(B)
    M1 = strassen(add(A11, A22, st), add(B11, B22, st), st, cutoff, trace, depth + 1)
    M2 = strassen(add(A21, A22, st), B11, st, cutoff, trace, depth + 1)
    M3 = strassen(A11, sub(B12, B22, st), st, cutoff, trace, depth + 1)
    M4 = strassen(A22, sub(B21, B11, st), st, cutoff, trace, depth + 1)
    M5 = strassen(add(A11, A12, st), B22, st, cutoff, trace, depth + 1)
    M6 = strassen(sub(A21, A11, st), add(B11, B12, st), st, cutoff, trace, depth + 1)
    M7 = strassen(sub(A12, A22, st), add(B21, B22, st), st, cutoff, trace, depth + 1)
    C11 = add(sub(add(M1, M4, st), M5, st), M7, st)
    C12 = add(M3, M5, st)
    C21 = add(M2, M4, st)
    C22 = add(add(sub(M1, M2, st), M3, st), M6, st)
    if trace is not None and n == 2:
        trace.update(dict(M1=M1[0][0], M2=M2[0][0], M3=M3[0][0], M4=M4[0][0], M5=M5[0][0], M6=M6[0][0], M7=M7[0][0]))
    return join(C11, C12, C21, C22)


def strassen_any(A, B, st, cutoff):
    """Pads to the next power of two when n is not a power of 2."""
    n = len(A); m = 1
    while m < n: m *= 2
    if m == n:
        return strassen(A, B, st, cutoff)
    pad = lambda X: [r + [0] * (m - n) for r in X] + [[0] * m for _ in range(m - n)]
    C = strassen(pad(A), pad(B), st, cutoff)
    return [r[:n] for r in C[:n]]


def rand_matrix(n, rnd):
    return [[rnd.randint(-9, 9) for _ in range(n)] for _ in range(n)]


def new_stats(): return {"mul": 0, "add": 0}


def main():
    print("=" * 78 + "\nMODULE 4 - STRASSEN'S MATRIX MULTIPLICATION FOR RECOMMENDATION SCORES\n" + "=" * 78)
    d = json.load(open(DATA)); A, B, expected = d["A"], d["B"], d["expected_C"]
    print("\nA =", A, "\nB =", B)

    print("\n--- Strassen on the 2x2 sample (divide into 1x1 blocks) ---")
    (a11, a12), (a21, a22) = A; (b11, b12), (b21, b22) = B
    M = {"M1": (a11 + a22) * (b11 + b22), "M2": (a21 + a22) * b11, "M3": a11 * (b12 - b22), "M4": a22 * (b21 - b11),
         "M5": (a11 + a12) * b22, "M6": (a21 - a11) * (b11 + b12), "M7": (a12 - a22) * (b21 + b22)}
    desc = {"M1": f"({a11}+{a22})({b11}+{b22})", "M2": f"({a21}+{a22})*{b11}", "M3": f"{a11}*({b12}-{b22})", "M4": f"{a22}*({b21}-{b11})",
            "M5": f"({a11}+{a12})*{b22}", "M6": f"({a21}-{a11})({b11}+{b12})", "M7": f"({a12}-{a22})({b21}+{b22})"}
    for k, v in M.items():
        print(f"  {k} = {desc[k]:<14} = {v}")
    C11 = M["M1"] + M["M4"] - M["M5"] + M["M7"]; C12 = M["M3"] + M["M5"]
    C21 = M["M2"] + M["M4"]; C22 = M["M1"] - M["M2"] + M["M3"] + M["M6"]
    print(f"  C11 = M1+M4-M5+M7 = {C11}\n  C12 = M3+M5       = {C12}\n  C21 = M2+M4       = {C21}\n  C22 = M1-M2+M3+M6 = {C22}")
    st = new_stats(); tr = {}
    C = strassen(A, B, st, cutoff=1, trace=tr)
    conv_st = new_stats(); Cc = conventional(A, B, conv_st)
    print("\nStrassen (program) :", C, f"| multiplications = {st['mul']}, additions/subtractions = {st['add']}")
    print("Conventional       :", Cc, f"| multiplications = {conv_st['mul']}")
    assert C == Cc == expected == [[C11, C12], [C21, C22]] and list(tr.values()) == list(M.values())
    print("Verification       : Strassen == conventional == expected -> PASS")

    print("\n--- Correctness on random matrices (cutoff = 1 and cutoff = 8) ---")
    rnd = random.Random(4)
    for n in (4, 8, 16, 32, 64, 128):
        X, Y = rand_matrix(n, rnd), rand_matrix(n, rnd)
        ref = conventional(X, Y)
        ok = all(strassen(X, Y, new_stats(), c) == ref for c in (1, 8))
        print(f"  n = {n:>3}: {'PASS' if ok else 'FAIL'}"); assert ok
    X, Y = rand_matrix(100, rnd), rand_matrix(100, rnd)
    assert strassen_any(X, Y, new_stats(), 8) == conventional(X, Y)
    print("  n = 100 (padded to 128): PASS")

    print("\n--- Operation counts measured by the program vs formulas (cutoff = 1) ---")
    print(f"{'n':>5} {'measured mults':>15} {'7^k':>13} {'measured adds':>14} {'6(7^k-4^k)':>13}")
    for k in range(1, 6):
        n = 2 ** k
        st = new_stats(); strassen(rand_matrix(n, rnd), rand_matrix(n, rnd), st, 1)
        print(f"{n:>5} {st['mul']:>15,} {7 ** k:>13,} {st['add']:>14,} {6 * (7 ** k - 4 ** k):>13,}")
        assert st["mul"] == 7 ** k and st["add"] == 6 * (7 ** k - 4 ** k)

    print("\n--- Production workload n = 1,024: scalar operation counts (from the recurrences) ---")
    def hybrid_counts(n, cut):
        k = int(math.log2(n // cut))
        mul = 7 ** k * cut ** 3
        add_ = sum(7 ** i * 18 * (n // 2 ** (i + 1)) ** 2 for i in range(k)) + 7 ** k * cut * cut * (cut - 1)
        return mul, add_
    n = 1024
    table = [("Conventional", n ** 3, n * n * (n - 1))]
    table.append(("Strassen to 1x1", 7 ** 10, 6 * (7 ** 10 - 4 ** 10)))
    for cut in (128, 64, 32, 16):
        m, a_ = hybrid_counts(n, cut); table.append((f"Hybrid cut-off {cut}", m, a_))
    print(f"{'method':<20} {'multiplications':>17} {'additions':>16} {'total':>17} {'vs conventional':>16}")
    base = table[0][1] + table[0][2]
    for name, m, a_ in table:
        print(f"{name:<20} {m:>17,} {a_:>16,} {m + a_:>17,} {(m + a_) / base:>15.1%}")
    with open(RESULTS / "module4_operation_counts.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["method", "multiplications", "additions", "total"]); w.writerows([(a, b, c, b + c) for a, b, c in table])

    print("\n--- Running time (pure Python, seconds) ---")
    print(f"{'n':>5} {'conventional':>13} {'Strassen cut=1':>15} {'hybrid cut=16':>14} {'hybrid cut=32':>14}")
    times = []
    for n in (32, 64, 128):
        X, Y = rand_matrix(n, rnd), rand_matrix(n, rnd)
        row = [n]
        for fn in (lambda: conventional(X, Y), lambda: strassen(X, Y, new_stats(), 1),
                   lambda: strassen(X, Y, new_stats(), 16), lambda: strassen(X, Y, new_stats(), 32)):
            t0 = time.perf_counter(); fn(); row.append(round(time.perf_counter() - t0, 4))
        times.append(row); print(f"{row[0]:>5} {row[1]:>13.4f} {row[2]:>15.4f} {row[3]:>14.4f} {row[4]:>14.4f}")
    with open(RESULTS / "module4_timing.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["n", "conventional_s", "strassen_cut1_s", "hybrid_cut16_s", "hybrid_cut32_s"]); w.writerows(times)

    try:
        import numpy as np
        print("\n--- NumPy experiment (optimised BLAS base case), n = 1,024 ---")
        def s_np(A, B, cut):
            n = A.shape[0]
            if n <= cut: return A @ B
            h = n // 2
            A11, A12, A21, A22 = A[:h, :h], A[:h, h:], A[h:, :h], A[h:, h:]
            B11, B12, B21, B22 = B[:h, :h], B[:h, h:], B[h:, :h], B[h:, h:]
            M1 = s_np(A11 + A22, B11 + B22, cut); M2 = s_np(A21 + A22, B11, cut); M3 = s_np(A11, B12 - B22, cut)
            M4 = s_np(A22, B21 - B11, cut); M5 = s_np(A11 + A12, B22, cut); M6 = s_np(A21 - A11, B11 + B12, cut)
            M7 = s_np(A12 - A22, B21 + B22, cut)
            C = np.empty_like(A)
            C[:h, :h] = M1 + M4 - M5 + M7; C[:h, h:] = M3 + M5; C[h:, :h] = M2 + M4; C[h:, h:] = M1 - M2 + M3 + M6
            return C
        r = np.random.default_rng(1)
        Xn, Yn = r.integers(-9, 10, (1024, 1024)).astype(np.float64), r.integers(-9, 10, (1024, 1024)).astype(np.float64)
        t0 = time.perf_counter(); Cn = Xn @ Yn; tm = time.perf_counter() - t0
        print(f"  numpy matmul (BLAS)            : {tm:.3f} s")
        for cut in (256, 128, 64):
            t0 = time.perf_counter(); Cs = s_np(Xn, Yn, cut); ts = time.perf_counter() - t0
            print(f"  Strassen hybrid, cut-off {cut:>3}  : {ts:.3f} s   correct: {np.allclose(Cs, Cn)}")
    except ImportError:
        print("numpy not installed - experiment skipped")

    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        ns = [2 ** k for k in range(1, 11)]
        plt.figure(figsize=(7, 4.2))
        plt.plot(ns, [n ** 3 for n in ns], "o-", label="conventional n^3")
        plt.plot(ns, [7 ** int(math.log2(n)) for n in ns], "s-", label="Strassen 7^k (to 1x1)")
        plt.plot(ns, [hybrid_counts(n, min(n, 64))[0] for n in ns], "^-", label="hybrid (cut-off 64)")
        plt.xscale("log", base=2); plt.yscale("log"); plt.xlabel("matrix size n"); plt.ylabel("scalar multiplications (log scale)")
        plt.title("Matrix multiplication: scalar multiplications"); plt.legend(); plt.grid(alpha=.3, which="both")
        plt.tight_layout(); plt.savefig(REPORT / "strassen_multiplications.png", dpi=150); plt.close()
        plt.figure(figsize=(7, 4.2))
        labels = [t[0] for t in table]; totals = [(t[1] + t[2]) / 1e9 for t in table]
        plt.barh(labels[::-1], totals[::-1], color="#4472C4"); plt.xlabel("total scalar operations (billions), n = 1,024")
        plt.title("Total operations (multiplications + additions)"); plt.tight_layout()
        plt.savefig(REPORT / "strassen_total_operations.png", dpi=150); plt.close()
        print("\nGraphs saved: Report/strassen_multiplications.png, Report/strassen_total_operations.png")
    except ImportError:
        print("matplotlib not installed - graphs skipped")


if __name__ == "__main__":
    main()
