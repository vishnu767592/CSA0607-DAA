# CSA06 – CO3 Case Study: Divide-and-Conquer Engine of "KartIQ", a Retail Data Analytics Platform

**Course:** CSA06 – Design and Analysis of Algorithms  **Assessment:** CO3 – Case Study (AT3)  
**Student:** Vishnuvardhan Reddy L  **Reg. No.:** _<fill in>_

KartIQ records about 10,000,000 orders a day and ranks 100,000 sellers. Four slow modules were analysed and redesigned with divide-and-conquer algorithms; every algorithm is implemented, executed on the sample data, traced, analysed and benchmarked.

## Repository structure
```
CO3_AT3/
├── Module_1_Merge_Sort/                     Pseudocode/  Source_Code/  Report/
├── Module_2_Quick_Sort/                     Pseudocode/  Source_Code/  Report/
├── Module_3_Binary_Search/                  Pseudocode/  Source_Code/  Report/
├── Module_4_Strassen_Matrix_Multiplication/ Pseudocode/  Source_Code/  Report/
├── Final_Design_and_Analysis/               final design, comparison tables, before/after chart
├── Supporting_Files/
│   ├── datasets/   sample inputs + test_cases.md
│   ├── results/    CSV files written by the experiments
│   └── tools/      chart and screenshot generators
├── run_all.sh      runs everything and refreshes outputs, graphs, screenshots
├── requirements.txt
└── README.md
```
Each module's `Report/` folder holds the report (`*_Report.md`), `execution_output.txt`, graphs (`*.png`) and `screenshots/` of the source code and program output.

## How to run
```bash
pip install -r requirements.txt        # matplotlib, numpy, pygments, playwright (only for graphs/screenshots)
python Module_1_Merge_Sort/Source_Code/merge_sort.py
python Module_2_Quick_Sort/Source_Code/quick_sort.py
python Module_3_Binary_Search/Source_Code/binary_search.py
python Module_4_Strassen_Matrix_Multiplication/Source_Code/strassen.py
./run_all.sh                           # everything at once (screenshots need: playwright install chromium)
```
The programs need only the Python standard library; matplotlib and numpy are optional (graphs and the BLAS experiment).

## Results at a glance
| Module | Algorithm | Complexity | Key result |
|---|---|---|---|
| 1 Order consolidation | Stable Merge Sort | Θ(n log n), O(n) space | Sample sorted with 10 comparisons, ties kept in arrival order; ≤ 223,222,785 comparisons for 10⁷ orders |
| 2 Seller leaderboard | Quick Sort, median-of-three pivot | Θ(n log n) average, O(log n) stack | First-element pivot ≈ 5 × 10⁹ comparisons for 10⁵ nearly sorted scores vs ≈ 2 × 10⁶ |
| 3 Order lookup | Binary search (first occurrence) | Θ(log n), O(1) | ≤ 24 probes for 10⁷ orders (confirmed by experiment) |
| 4 Recommendation scores | Hybrid Strassen | Θ(n^2.81), Θ(n²) space | 2×2 sample verified; 7¹⁰ = 282,475,249 vs 1,073,741,824 multiplications; not faster than BLAS in practice |

## Where to look
* Analysis, traces, recurrences, calculations, graphs, limitations: `Module_*/Report/*_Report.md`
* Final design, trade-offs, recommendations: `Final_Design_and_Analysis/Final_Design_and_Analysis.md`
* Pseudocode: `Module_*/Pseudocode/`
