"""Run every boundary case against the ORIGINAL and the CORRECTED module; write boundary_results.json."""
import json, math, os, sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Source_Code"))
import original_module as org
import corrected_module as cor

bl = ["10.0.0.5", "10.0.0.9", "172.16.4.2"]
T = [  # (function, description, call(module), expected)
 ("sort_alerts", "issued test data", lambda m: m.sort_alerts([("A1",3),("A2",9),("A3",5),("A4",9),("A5",1)]), [("A2",9),("A4",9),("A3",5),("A1",3),("A5",1)]),
 ("sort_alerts", "empty list", lambda m: m.sort_alerts([]), []),
 ("sort_alerts", "single alert", lambda m: m.sort_alerts([("A",4)]), [("A",4)]),
 ("sort_alerts", "equal severities (A,B,C all 5)", lambda m: m.sort_alerts([("A",5),("B",5),("C",5)]), [("A",5),("B",5),("C",5)]),
 ("sort_alerts", "already sorted (9,5,1)", lambda m: m.sort_alerts([("A",9),("B",5),("C",1)]), [("A",9),("B",5),("C",1)]),
 ("sort_alerts", "reverse sorted (1,5,9)", lambda m: m.sort_alerts([("A",1),("B",5),("C",9)]), [("C",9),("B",5),("A",1)]),
 ("sort_alerts", "ties mixed (2,7,2,7,2): stability", lambda m: m.sort_alerts([("a",2),("b",7),("c",2),("d",7),("e",2)]), [("b",7),("d",7),("a",2),("c",2),("e",2)]),
 ("is_blocked", "10.0.0.9 (middle entry)", lambda m: m.is_blocked(bl, "10.0.0.9"), True),
 ("is_blocked", "10.0.0.5 (first entry)", lambda m: m.is_blocked(bl, "10.0.0.5"), True),
 ("is_blocked", "172.16.4.2 (last entry)", lambda m: m.is_blocked(bl, "172.16.4.2"), True),
 ("is_blocked", "8.8.8.8 (not listed)", lambda m: m.is_blocked(bl, "8.8.8.8"), False),
 ("is_blocked", "empty blocklist", lambda m: m.is_blocked([], "1.1.1.1"), False),
 ("is_blocked", "single entry, match", lambda m: m.is_blocked(["9.9.9.9"], "9.9.9.9"), True),
 ("find_signature", "issued log 'FAILFAIXFAIL'", lambda m: m.find_signature("FAILFAIXFAIL", "FAIL"), [0, 8]),
 ("find_signature", "pattern at very end of log", lambda m: m.find_signature("xxxxFAIL", "FAIL"), [4]),
 ("find_signature", "pattern at very start", lambda m: m.find_signature("FAILxxxx", "FAIL"), [0]),
 ("find_signature", "pattern longer than log", lambda m: m.find_signature("FAI", "FAIL"), []),
 ("find_signature", "pattern one longer than log", lambda m: m.find_signature("FAIL", "FAILX"), []),
 ("find_signature", "pattern equals log", lambda m: m.find_signature("FAIL", "FAIL"), [0]),
 ("find_signature", "empty log", lambda m: m.find_signature("", "FAIL"), []),
 ("find_signature", "overlapping hits ('AAAA','AA')", lambda m: m.find_signature("AAAA", "AA"), [0, 1, 2]),
 ("find_signature", "near miss on last char ('FAIX')", lambda m: m.find_signature("FAIX", "FAIL"), []),
 ("find_signature", "empty pattern", lambda m: m.find_signature("abc", ""), []),
 ("closest_logins", "issued events", lambda m: m.closest_logins([(2,3),(12,30),(40,50),(5,1),(12,10),(3,4)]), ((0,5), math.sqrt(2))),
 ("closest_logins", "zero events", lambda m: m.closest_logins([]), (None, None)),
 ("closest_logins", "one event", lambda m: m.closest_logins([(1,1)]), (None, None)),
 ("closest_logins", "two events (0,0),(3,4)", lambda m: m.closest_logins([(0,0),(3,4)]), ((0,1), 5.0)),
 ("closest_logins", "duplicate locations", lambda m: m.closest_logins([(1,1),(9,9),(1,1)]), ((0,2), 0.0)),
 ("closest_logins", "tie: (0,0),(1,0),(2,0)", lambda m: m.closest_logins([(0,0),(1,0),(2,0)]), ((0,1), 1.0)),
]
out = []
for fn, desc, call, exp in T:
    rec = {"function": fn, "case": desc, "expected": repr(exp)}
    for key, mod in (("original", org), ("corrected", cor)):
        try:
            r = call(mod); rec[key] = repr(r); rec[key + "_ok"] = (r == exp)
        except Exception as e:
            rec[key] = f"CRASH {type(e).__name__}"; rec[key + "_ok"] = False
    out.append(rec)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "boundary_results.json"), "w"), indent=1)
print(f"{len(out)} cases | original passes {sum(r['original_ok'] for r in out)} | corrected passes {sum(r['corrected_ok'] for r in out)}")
for r in out:
    if not r["original_ok"]:
        print(f"  original FAIL: {r['function']:<15} {r['case']:<38} -> {r['original']}")
