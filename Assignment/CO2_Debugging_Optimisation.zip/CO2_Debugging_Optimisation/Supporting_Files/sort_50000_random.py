"""Measure insertion sort vs Timsort on 50,000 random alerts (the daily production volume)."""
import sys, time, random
sys.path.insert(0, "../Source_Code")
import optimised_module as opt
rng = random.Random(50000)
data = [(f"A{i}", rng.randint(1, 10)) for i in range(50000)]
st = {}
t = time.perf_counter(); a = opt.insertion_sort_alerts(list(data), st); t_ins = time.perf_counter() - t
t = time.perf_counter(); b = opt.sort_alerts(list(data)); t_tim = time.perf_counter() - t
assert a == b
print(f"n=50000 random: insertion sort comparisons={st['comparisons']}  time={t_ins:.2f}s | Timsort time={t_tim:.4f}s | ratio x{t_ins/t_tim:.0f}")
