"""Render source files / execution logs as terminal-style images for the report (Report/figures/)."""
import os
from PIL import Image, ImageDraw, ImageFont
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
FIG = os.path.join(ROOT, "Report", "figures")
FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 16)
BG, BAR, FG, DIM = (30, 32, 36), (52, 55, 62), (225, 227, 230), (140, 145, 155)
GREEN, RED, YEL = (120, 214, 140), (255, 120, 120), (240, 200, 110)

def render(lines, title, out, maxw=118):
    lines = [l.expandtabs(4)[:maxw] for l in lines]
    cw = FONT.getlength("M"); lh = 22
    W = int(max(cw * max(len(l) for l in lines) + 40, 640)); H = lh * len(lines) + 70
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    d.rectangle([0, 0, W, 36], fill=BAR)
    for k, c in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        d.ellipse([14 + 24 * k, 11, 26 + 24 * k, 23], fill=c)
    d.text((W / 2 - len(title) * cw / 2 * 0.8, 9), title, font=FONT, fill=DIM)
    y = 50
    for l in lines:
        col = FG
        if "[PASS]" in l or l.strip().startswith("PASS"): col = GREEN
        elif "[FAIL]" in l: col = RED
        elif "FIX D" in l: col = YEL
        elif l.lstrip().startswith("#") or l.lstrip().startswith('"""'): col = DIM
        d.text((20, y), l, font=FONT, fill=col); y += lh
    im.save(os.path.join(FIG, out)); print("wrote", out, im.size)

def read(p): return open(os.path.join(ROOT, p)).read().splitlines()

render(read("Source_Code/original_module.py")[1:], "original_module.py  (as issued)", "src_original.png")
render(read("Source_Code/corrected_module.py")[10:], "corrected_module.py  (nine fixes marked FIX D1-D9)", "src_corrected.png", 112)
render(read("Supporting_Files/execution_log_original.txt"), "$ python3 run_original.py", "out_original.png")
dbg = read("Supporting_Files/execution_log_debug_steps.txt")
render(dbg[:34], "$ python3 debug_steps.py   (sort_alerts + is_blocked)", "out_debug_1.png")
render(dbg[34:], "$ python3 debug_steps.py   (find_signature + closest_logins)", "out_debug_2.png")
th = read("Supporting_Files/execution_log_test_harness.txt")
render(th[:42], "$ python3 test_harness.py   (1/2)", "out_harness_1.png")
render(th[42:], "$ python3 test_harness.py   (2/2)", "out_harness_2.png")
def wrap(lines, width=150):
    out = []
    for l in lines:
        if len(l) <= width:
            out.append(l); continue
        parts = l.split(" | "); out.append(parts[0])
        out += ["      | " + p for p in parts[1:]]
    return out

ex = read("Supporting_Files/execution_log_experiments.txt")
cut = next(i for i, l in enumerate(ex) if l.startswith("== 2."))
render(ex[:cut], "$ python3 experiments.py   (closest_logins)", "out_exp_1.png", 150)
rest = wrap(ex[cut:])
mid = next(i for i, l in enumerate(rest) if l.startswith("== 3."))
render(rest[:mid], "$ python3 experiments.py   (insertion sort, run time)", "out_exp_2.png", 150)
render(rest[mid:], "$ python3 experiments.py   (blocklist, signature)", "out_exp_3.png", 150)
