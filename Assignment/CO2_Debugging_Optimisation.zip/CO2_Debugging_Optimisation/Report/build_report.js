// Builds CO2_Debugging_Optimisation_Report.docx from the real result files in this repository.
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, Header, Footer,
  AlignmentType, LevelFormat, HeadingLevel, BorderStyle, WidthType, ShadingType, PageNumber, PageBreak,
} = require("docx");

const ROOT = path.join(__dirname, "..");
const FIG = path.join(__dirname, "figures");
const SUP = path.join(ROOT, "Supporting_Files");
const W = 9026; // A4 content width in DXA (1" margins)

// ---------------------------------------------------------------- data loaders
const csv = (f) => {
  const [h, ...rows] = fs.readFileSync(path.join(SUP, f), "utf8").trim().split("\n").map((l) => l.split(","));
  return { h, rows };
};
const N = (x) => Number(x).toLocaleString("en-US");
const F = (x, d = 3) => Number(x).toFixed(d);
const closest = csv("closest_pair_results.csv").rows;
const stress = csv("closest_pair_stress.csv").rows;
const seeds = csv("closest_pair_20_seeds.csv").rows;
const ins = csv("insertion_sort_comparisons.csv").rows;
const stime = csv("sort_timing.csv").rows;
const blk = csv("blocklist_results.csv").rows[0];
const sig = csv("signature_results.csv").rows;
const boundary = JSON.parse(fs.readFileSync(path.join(SUP, "boundary_results.json"), "utf8"));
const optSource = fs.readFileSync(path.join(ROOT, "Source_Code", "optimised_module.py"), "utf8").split("\n");
const pseudo = (f) => fs.readFileSync(path.join(ROOT, "Pseudocode", f), "utf8").trimEnd().split("\n");

// ---------------------------------------------------------------- style helpers
const INK = "1A1A1A", BLUE = "1F3A5F", GREY = "5A5A5A", GOOD = "1B7F3B", BAD = "B3261E";
const FONT = "Arial", MONO = "Courier New";
let figN = 0, tabN = 0;

const run = (t, o = {}) => new TextRun({ text: t, font: o.mono ? MONO : FONT, size: o.size || 21, bold: o.bold, italics: o.italics, color: o.color || INK });
// inline markup: **bold** and `mono`
const runs = (text, base = {}) => {
  const out = [];
  text.split(/(\*\*[^*]+\*\*|`[^`]+`)/).forEach((p) => {
    if (!p) return;
    if (p.startsWith("**")) out.push(run(p.slice(2, -2), { ...base, bold: true }));
    else if (p.startsWith("`")) out.push(run(p.slice(1, -1), { ...base, mono: true, size: (base.size || 21) - 2 }));
    else out.push(run(p, base));
  });
  return out;
};
const P = (text, o = {}) =>
  new Paragraph({ children: runs(text, o), spacing: { before: o.before ?? 60, after: o.after ?? 100, line: 276 }, alignment: o.align, keepNext: o.keepNext });
const B = (text, level = 0) =>
  new Paragraph({ numbering: { reference: "bullets", level }, children: runs(text), spacing: { before: 20, after: 40, line: 264 } });
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: t, font: FONT })], pageBreakBefore: true });
const H1n = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun({ text: t, font: FONT })] });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text: t, font: FONT })], keepNext: true });
const H3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun({ text: t, font: FONT })], keepNext: true });
const caption = (t) =>
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 40, after: 160 }, children: [run(t, { italics: true, size: 18, color: GREY })] });
const figCap = (t) => caption(`Figure ${++figN} – ${t}`);
const tabCap = (t) => new Paragraph({ keepNext: true, spacing: { before: 140, after: 60 }, children: [run(`Table ${++tabN} – ${t}`, { italics: true, size: 18, color: GREY, bold: true })] });
const spacer = (n = 80) => new Paragraph({ spacing: { before: 0, after: n }, children: [] });

const codeBlock = (lines, size = 16) =>
  lines.map((l, i) =>
    new Paragraph({
      spacing: { before: 0, after: 0, line: 240 },
      indent: { left: 100, right: 100 },
      shading: { type: ShadingType.CLEAR, fill: "F3F4F6" },
      border: {
        left: { style: BorderStyle.SINGLE, size: 12, color: "9AA5B1", space: 6 },
        ...(i === 0 ? { top: { style: BorderStyle.SINGLE, size: 4, color: "D5D8DD", space: 4 } } : {}),
        ...(i === lines.length - 1 ? { bottom: { style: BorderStyle.SINGLE, size: 4, color: "D5D8DD", space: 4 } } : {}),
      },
      children: [new TextRun({ text: l.length ? l : " ", font: MONO, size, color: INK })],
    })
  );

const pngSize = (f) => {
  const b = fs.readFileSync(f);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
};
const image = (name, maxW = 600, maxH = 840) => {
  const f = path.join(FIG, name);
  const { w, h } = pngSize(f);
  const s = Math.min(maxW / w, maxH / h, 1.6);
  return new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { before: 80, after: 0 }, keepNext: true,
    children: [new ImageRun({ type: "png", data: fs.readFileSync(f), transformation: { width: Math.round(w * s), height: Math.round(h * s) },
      altText: { title: name, description: name, name } })],
  });
};

const thin = { style: BorderStyle.SINGLE, size: 4, color: "C9CDD3" };
const borders = { top: thin, bottom: thin, left: thin, right: thin };
const cell = (content, width, o = {}) => {
  const lines = Array.isArray(content) ? content : String(content).split("\n");
  return new TableCell({
    width: { size: width, type: WidthType.DXA }, borders,
    shading: o.fill ? { type: ShadingType.CLEAR, fill: o.fill } : undefined,
    margins: { top: 50, bottom: 50, left: 90, right: 90 },
    verticalAlign: "top",
    children: lines.map((l) => new Paragraph({
      alignment: o.align, spacing: { before: 0, after: 20, line: 250 },
      children: o.mono ? [new TextRun({ text: l || " ", font: MONO, size: o.size || 16, bold: o.bold, color: o.color || INK })]
                       : runs(l || " ", { size: o.size || 18, bold: o.bold, color: o.color }),
    })),
  });
};
// opts: mono = array of booleans per column, align = array, size
const table = (headers, rows, widths, o = {}) => {
  const sum = widths.reduce((a, b) => a + b, 0);
  if (sum !== W && !o.allowOdd) throw new Error("column widths sum " + sum + " != " + W);
  const head = new TableRow({ tableHeader: true, cantSplit: true, children: headers.map((h, i) => cell(h, widths[i], { fill: BLUE, bold: true, color: "FFFFFF", size: o.size || 18, align: o.align?.[i] })) });
  const body = rows.map((r, ri) => new TableRow({ cantSplit: true, children: r.map((c, i) => {
    const cc = typeof c === "object" && !Array.isArray(c) && c !== null ? c : { t: c };
    return cell(cc.t, widths[i], { fill: cc.fill || (ri % 2 ? "F7F8FA" : undefined), mono: o.mono?.[i], align: o.align?.[i], size: o.size, bold: cc.bold, color: cc.color });
  }) }));
  return new Table({ width: { size: sum, type: WidthType.DXA }, columnWidths: widths, rows: [head, ...body] });
};
const okc = (ok, text) => ({ t: text, color: ok ? GOOD : BAD, bold: true });
const short = (s, n = 40) => (s.length > n ? s.slice(0, n - 1) + "…" : s);

const callout = (title, lines) =>
  new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: [W],
    rows: [new TableRow({ children: [new TableCell({
      width: { size: W, type: WidthType.DXA },
      borders: { top: thin, bottom: thin, right: thin, left: { style: BorderStyle.SINGLE, size: 24, color: "2A78D6" } },
      shading: { type: ShadingType.CLEAR, fill: "EEF4FC" }, margins: { top: 100, bottom: 100, left: 180, right: 140 },
      children: [new Paragraph({ spacing: { after: 60 }, children: [run(title, { bold: true, color: BLUE })] }),
        ...lines.map((l) => new Paragraph({ spacing: { before: 0, after: 50, line: 264 }, children: runs(l, { size: 20 }) }))],
    })] })],
  });

// ================================================================= CONTENT
const c = []; // children of the main section

// ---------------------------------------------------------------- cover
c.push(new Paragraph({ spacing: { before: 600, after: 80 }, children: [run("DEPARTMENT OF COMPUTER SCIENCE AND ENGINEERING", { bold: true, size: 22, color: GREY })] }));
c.push(new Paragraph({ spacing: { before: 120, after: 60 }, children: [run("CSA06 – Design and Analysis of Algorithms", { bold: true, size: 40, color: BLUE })] }));
c.push(new Paragraph({ spacing: { before: 0, after: 60 }, children: [run("CO2 – Debugging and Optimisation Task", { size: 32, color: INK })] }));
c.push(new Paragraph({
  spacing: { before: 120, after: 360 }, border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: "2A78D6", space: 8 } },
  children: [run("SOC Alert-Triage Module of “SentinelOps”: Defect Analysis, Debugging, Optimisation and Evaluation", { size: 24, color: GREY })],
}));
c.push(table(["Field", "Details"], [
  ["Course Code & Name", "CSA06 – Design and Analysis of Algorithms"],
  ["Assessment", "CO2 – Debugging and Optimisation Task (Individual, 1.5 hrs, in class)"],
  ["Course Outcome Assessed", "Apply Brute Force technique to solve sorting, searching, Closest-Pair and Convex-Hull problems."],
  ["Maximum Marks", "50"],
  ["Student Reg. No.", "____________________________"],
  ["Student Name", "____________________________"],
  ["GitHub repository link", "https://github.com/<your-username>/CO2_Debugging_Optimisation   (fill in after upload)"],
  ["Date", "01 November 2026"],
], [2600, 6426], { size: 19 }));
c.push(spacer(300));
c.push(callout("Result at a glance", [
  "**9 defects** found and fixed (2 in `sort_alerts`, 2 in `is_blocked`, 2 in `find_signature`, 3 in `closest_logins`); the original module passed only **9 of 29** boundary/regression cases, the corrected module passes **29 of 29**.",
  "Optimised module: **67 of 67** harness checks pass, including 1,000+ random differential tests proving the optimised outputs are identical to the corrected module.",
  `At the production batch size (8,000 login events) the optimised closest-pair scan computed **${N(closest[4][3])}** distances instead of **${N(closest[4][2])}** (×${N(closest[4][4])}, one seeded run; mean ×${N(seeds[4][5])} over 20 seeds).`,
  "Sorting 50,000 random alerts: insertion sort **74.6 s** vs optimised stable sort **0.0056 s**. 50,000 blocklist queries: **2.75 s** vs **0.0047 s**.",
]));
c.push(spacer(200));
c.push(P("Marks map: (a) 10 • (b) 12 • (c) 10 • (d) 10 • (e) 8 = 50.   Rubric weights: Problem Identification 20 % • Debugging 25 % • Optimisation 20 % • Analysis 20 % • Code Quality 15 %.", { size: 18, color: GREY }));

// ---------------------------------------------------------------- 0. repo structure
c.push(H1("1. Deliverables and Repository Layout"));
c.push(P("All work lives in one repository organised exactly as requested. Every number, trace and figure in this report was produced by running the code in `Source_Code/`; the raw logs are stored in `Supporting_Files/`."));
c.push(...codeBlock([
  "CO2_Debugging_Optimisation/",
  "|-- Pseudocode/",
  "|     01_sort_alerts.txt        corrected + optimised pseudocode",
  "|     02_is_blocked.txt",
  "|     03_find_signature.txt",
  "|     04_closest_logins.txt",
  "|-- Source_Code/",
  "|     original_module.py        buggy module exactly as issued",
  "|     run_original.py           Part (a): reproduces the failures",
  "|     debug_steps.py            Part (b): one fix at a time + traces",
  "|     corrected_module.py       nine defects fixed (minimal edits)",
  "|     test_corrected.py         boundary tests for the corrected module",
  "|     optimised_module.py       final optimised module (docstrings)",
  "|     test_harness.py           67 checks incl. differential tests",
  "|     experiments.py            Part (d) measurements and charts",
  "|     experiments_seeds.py      20-seed closest-pair measurement",
  "|-- Report/",
  "|     CO2_Debugging_Optimisation_Report.docx   (this document)",
  "|     figures/                  charts + code / output captures",
  "|-- Supporting_Files/           CSV tables, JSON, execution logs",
  "`-- README.md",
]));
c.push(spacer());
c.push(table(["Required deliverable", "Where it is"], [
  ["Pseudocode for all four corrected and optimised functions", "Section 3 of this report and `Pseudocode/`"],
  ["Original, corrected and optimised programs + test harness", "`Source_Code/` (optimised module listed in Appendix A)"],
  ["Defect identification, root causes, debugging steps, source/output captures, test verification", "Sections 2 and 4"],
  ["Optimisation techniques", "Section 5"],
  ["Complexity analysis, experiments, tables, graphs", "Section 6"],
  ["Test datasets, logs, results", "`Supporting_Files/`"],
], [5200, 3826], { size: 19 }));

// ---------------------------------------------------------------- Part (a)
c.push(H1("2. Part (a) – Reproduce and Identify the Defects"));
c.push(P("The original module was saved unchanged as `original_module.py` and executed on the issued test data with `run_original.py` (Figures 1 and 2). For each function the expected output was derived by hand from the specification in the scenario, then compared with the actual output."));
c.push(image("src_original.png", 560, 640));
c.push(figCap("original_module.py exactly as issued (rendered capture of the source file)."));
c.push(image("out_original.png", 560, 300));
c.push(figCap("Output of run_original.py – every function disagrees with the expected result (rendered capture of the execution log)."));

c.push(H2("2.1 Expected versus actual output"));
c.push(tabCap("Expected and actual output of the original module on the issued test data"));
c.push(table(["Function", "Input", "Expected output", "Actual output", "What is wrong"], [
  ["sort_alerts", "A1:3, A2:9, A3:5, A4:9, A5:1", "[A2:9, A4:9, A3:5, A1:3, A5:1]", "[A4:9, A3:5, A3:5, A5:1, A5:1]", "A1 and A2 disappeared; A3 and A5 duplicated; equal-severity order not kept"],
  ["is_blocked", "10.0.0.9\n10.0.0.5\n8.8.8.8", "True\nTrue\nFalse", "False\nFalse\nFalse", "Blocked addresses reported as allowed; the last answer is right only by accident"],
  ["find_signature", "log FAILFAIXFAIL, pattern FAIL", "[0, 8]", "[0, 4]", "Final occurrence (index 8) missed; false occurrence at 4 (FAIX) reported"],
  ["closest_logins", "6 events (x, y) in km", "((0, 5), 1.414…)", "((0, 2), 60.44…)", "Returns the FARTHEST pair, not the closest"],
], [1300, 1800, 1900, 1900, 2126], { size: 17, mono: [true, false, true, true, false] }));

c.push(new Paragraph({ children: [new PageBreak()] }));
c.push(H2("2.2 Defect register"));
c.push(P("Nine defects were located. Line numbers refer to `original_module.py`; none were marked in the issued code. The listing in the brief lost its indentation when exported to PDF, so the `else:` in `is_blocked` is read as belonging to the `if` inside the loop. That reading is the one consistent with nine defects; under the alternative (loop-else) reading D4 disappears, D3 alone explains the output and the correction is identical."));
c.push(tabCap("Defect register (function, faulty line, nature of the error)"));
c.push(table(["ID", "Function", "Faulty line", "Nature of error", "Observed effect"], [
  ["D1", "sort_alerts", "while j > 0 and alerts[j][1] < key[1]:", "Off-by-one loop bound – index 0 is never compared or shifted", "First alert can never be passed by a higher-severity key"],
  ["D2", "sort_alerts", "alerts[j] = key", "Wrong insertion index – must be j + 1", "Overwrites a live alert → loss and duplication"],
  ["D3", "is_blocked", "return False   (inside if blocklist[i] == ip)", "Inverted return value on a match", "Every blocked IP is reported as not blocked"],
  ["D4", "is_blocked", "else: return False   (inside the loop)", "Premature exit: ‘not found’ returned after the FIRST non-matching entry", "Only entry 0 is ever examined; empty list returns None, not False"],
  ["D5", "find_signature", "for i in range(n - m):", "Off-by-one: n - m + 1 alignments exist", "Pattern at the very end of the log is missed"],
  ["D6", "find_signature", "if j == m - 1:", "Tests the loop index, not ‘no mismatch occurred’; also undefined when m = 0", "False hit when only the LAST character mismatches (FAIX); crash on empty pattern"],
  ["D7", "closest_logins", "min_dist = 0", "Wrong initial value – must be +infinity", "Nothing can ever be smaller than 0"],
  ["D8", "closest_logins", "if d > min_dist:", "Inverted comparison – keeps the larger distance", "Finds the farthest pair"],
  ["D9", "closest_logins", "for j in range(len(events)):", "Inner loop runs over all j: includes i = j and mirrored (j, i) pairs", "Self-pairs (d = 0) win once D7/D8 are fixed; every pair evaluated twice"],
], [520, 1250, 2450, 2650, 2156], { size: 16, mono: [false, false, true, false, false] }));
c.push(spacer(60));
c.push(P("**Extra finding.** Running the full boundary suite against the unmodified code gave 9 passes out of 29 cases (Section 4.4); the module also crashes with `UnboundLocalError` on an empty pattern and returns `None` instead of `False` for an empty blocklist. These are consequences of D6 and D4, not additional defects."));

// ---------------------------------------------------------------- Pseudocode
c.push(H1("3. Pseudocode for the Corrected and Optimised Algorithms"));
c.push(P("Pseudocode was written for each function before the code was changed. For every function part A is the corrected algorithm (same technique as the original) and part B is the optimised algorithm. The same text is stored in `Pseudocode/`."));
[["3.1 sort_alerts", "01_sort_alerts.txt"], ["3.2 is_blocked", "02_is_blocked.txt"], ["3.3 find_signature", "03_find_signature.txt"], ["3.4 closest_logins", "04_closest_logins.txt"]].forEach(([t, f]) => {
  c.push(H2(t));
  const lines = pseudo(f).filter((l) => !/^=+$/.test(l.trim()) && !/^ PSEUDOCODE/.test(l) && l.trim() !== "");
  c.push(...codeBlock(lines, 15));
});

// ---------------------------------------------------------------- Part (b)
c.push(H1("4. Part (b) – Root Causes and Systematic Debugging"));
c.push(P("The code was **not rewritten**. `debug_steps.py` contains the original functions plus one new version per defect; each version differs from its predecessor by exactly one line, and after every change the function was re-run on the issued test data. The final result is `corrected_module.py` (Figure 5), which differs from the original only in the nine marked lines (plus one guard for an empty pattern, explained in 4.3)."));

c.push(H2("4.1 Root cause of each defect"));
c.push(tabCap("Why each defect happens and how it produces the observed wrong output"));
c.push(table(["ID", "Root cause (what / why wrong)", "How it produced the observed output", "Verified by"], [
  ["D1", "The inner loop must keep shifting until it has passed index 0, so its guard has to be j >= 0. With j > 0 the loop stops while j = 0 and the element at index 0 is never compared or moved.",
    "Pass i=1: key A2:9 should pass A1:3. The loop never runs, so A1 is not shifted. Fixing D1 alone is worse: the loop now ends with j = -1, and alerts[-1] = key silently writes to the LAST element (Python wraps negative indices instead of raising an error).",
    "Re-test after D1 alone: output [A1,A1,A1,A1,A4]"],
  ["D2", "When the while loop ends, j points at the element that was NOT passed (or at -1). The key belongs in the gap one place to the right, j + 1. Writing to alerts[j] overwrites an element that was never shifted.",
    "Pass i=1 writes A2 over A1 (A1 lost, A2 twice). Pass i=2 writes A3 over A2’s slot, pass i=3 shifts A3 twice and overwrites index 0, pass i=4 overwrites A3. Final list: A1, A2 gone; A3, A5 duplicated (Table 5).",
    "Insertion trace (Tables 5 and 6); output matches expected after D1+D2"],
  ["D3", "A successful match must return True; the author returned False.",
    "10.0.0.5 is entry 0: match found → False. Every blocked address is reported as clean.",
    "After D3: 10.0.0.5 → True"],
  ["D4", "The ‘not found’ branch sits inside the loop, so the first entry that differs from ip ends the search. ‘Not found’ may only be returned after ALL entries were checked.",
    "10.0.0.9 is entry 1; entry 0 (10.0.0.5) differs → return False before entry 1 is read. An empty list never enters the loop and falls off the end, returning None.",
    "After D4: [True, True, False]"],
  ["D5", "A pattern of length m can start at indexes 0 … n-m (inclusive): n - m + 1 alignments. range(n - m) stops one short.",
    "The last window (start 8, ‘FAIL’) is never tried, so the occurrence at index 8 is missed. Any pattern at the very end of a log is invisible.",
    "After D5: [0, 4, 8] – index 8 now found, false 4 remains"],
  ["D6", "After the inner loop, j == m - 1 is true both when all characters matched AND when the mismatch happened on the last character (the loop breaks with j = m - 1). It tests the position, not the outcome. For m = 0, j is never assigned.",
    "Window 4 = ‘FAIX’: F, A, I match, X ≠ L at j = 3 = m - 1 → break, test true → false hit 4 recorded (Table 7). Patterns ending in the same prefix as other text therefore create phantom signatures.",
    "After D6 (for-else): [0, 8]"],
  ["D7", "A running minimum must start at +infinity. Starting at 0 means no distance (always ≥ 0) can ever be smaller.",
    "With D8 fixed the function would return (None, 0) for every input.",
    "After D7 alone: (None, inf)"],
  ["D8", "The comparison is inverted: d > min_dist keeps the largest distance seen.",
    "Together with min_dist = 0 the loop tracks a running maximum – the farthest pair (0, 2) at 60.44 km, exactly the observed output.",
    "After D7+D8: ((0, 0), 0.0)"],
  ["D9", "The closest pair must be taken over distinct unordered pairs, i < j. With j over all indexes, i = j gives d = 0 and (j, i) repeats (i, j).",
    "Once D7/D8 are fixed the self-pair (0, 0), d = 0, always wins – the report would flag a login as ‘closest’ to itself. Every real pair is also evaluated twice.",
    "After D9: ((0, 5), 1.4142…) = expected"],
], [520, 2750, 3700, 2056], { size: 16 }));

c.push(H2("4.2 One-defect-at-a-time re-testing"));
c.push(tabCap("Output after each individual correction (issued test data)"));
c.push(table(["Step", "Change (one line)", "Output on the issued test data", "Status"], [
  ["v0", "original", "[A4:9, A3:5, A3:5, A5:1, A5:1]", okc(false, "wrong")],
  ["v1", "D1: while j >= 0", "[A1:3, A1:3, A1:3, A1:3, A4:9]", okc(false, "worse – exposes D2")],
  ["v2", "D2: alerts[j + 1] = key", "[A2:9, A4:9, A3:5, A1:3, A5:1]", okc(true, "correct")],
  ["v0", "original is_blocked", "[False, False, False]", okc(false, "wrong")],
  ["v1", "D3: return True on match", "[False, True, False]", okc(false, "10.0.0.9 still wrong")],
  ["v2", "D4: return False after the loop", "[True, True, False]", okc(true, "correct")],
  ["v0", "original find_signature", "[0, 4]", okc(false, "wrong")],
  ["v1", "D5: range(n - m + 1)", "[0, 4, 8]", okc(false, "false hit remains")],
  ["v2", "D6: for-else", "[0, 8]", okc(true, "correct")],
  ["v0", "original closest_logins", "((0, 2), 60.44…)", okc(false, "wrong")],
  ["v1", "D7: min_dist = inf", "(None, inf)", okc(false, "wrong")],
  ["v2", "D8: if d < min_dist", "((0, 0), 0.0)", okc(false, "self pair wins")],
  ["v3", "D9: j in range(i + 1, n)", "((0, 5), 1.4142135623730951)", okc(true, "correct")],
], [700, 2700, 3626, 2000], { size: 17, mono: [true, true, true, false] }));
c.push(image("out_debug_1.png", 560, 700));
c.push(figCap("debug_steps.py output, part 1: insertion traces and is_blocked re-tests."));
c.push(image("out_debug_2.png", 560, 560));
c.push(figCap("debug_steps.py output, part 2: alignment table and closest_logins re-tests."));
c.push(image("src_corrected.png", 560, 800));
c.push(figCap("corrected_module.py – the nine repaired lines are highlighted and tagged FIX D1 … FIX D9."));

c.push(H2("4.3 Step-by-step traces"));
c.push(H3("Insertion sort on the alert list"));
c.push(tabCap("Original code – list after each pass (shows loss and duplication)"));
c.push(table(["Pass", "Key", "List after the pass", "Problem"], [
  ["start", "–", "A1:3, A2:9, A3:5, A4:9, A5:1", "–"],
  ["i = 1", "A2:9", "A2:9, A2:9, A3:5, A4:9, A5:1", "A1 overwritten – lost"],
  ["i = 2", "A3:5", "A2:9, A3:5, A3:5, A4:9, A5:1", "A3 written over slot 1"],
  ["i = 3", "A4:9", "A4:9, A3:5, A3:5, A3:5, A5:1", "A2 lost, A3 three times"],
  ["i = 4", "A5:1", "A4:9, A3:5, A3:5, A5:1, A5:1", "final: A1, A2 lost; A3, A5 duplicated"],
], [900, 900, 4000, 3226], { size: 17, mono: [true, true, true, false] }));
c.push(spacer());
c.push(tabCap("Corrected code – list after each pass (stable: A2 stays before A4)"));
c.push(table(["Pass", "Key", "Shifts", "List after the pass"], [
  ["start", "–", "–", "A1:3, A2:9, A3:5, A4:9, A5:1"],
  ["i = 1", "A2:9", "A1 shifts right (3 < 9)", "A2:9, A1:3, A3:5, A4:9, A5:1"],
  ["i = 2", "A3:5", "A1 shifts (3 < 5); A2:9 < 5 false → stop", "A2:9, A3:5, A1:3, A4:9, A5:1"],
  ["i = 3", "A4:9", "A1, A3 shift; A2:9 < 9 false → stop (strict <, equal not passed → stable)", "A2:9, A4:9, A3:5, A1:3, A5:1"],
  ["i = 4", "A5:1", "A1:3 < 1 false → no shift", "A2:9, A4:9, A3:5, A1:3, A5:1"],
], [900, 900, 4000, 3226], { size: 17, mono: [true, true, false, true] }));
c.push(H3("Alignment table for the signature scan"));
c.push(tabCap("Alignments of ‘FAIL’ against ‘FAILFAIXFAIL’ (n = 12, m = 4, 9 windows)"));
const align = [];
const log = "FAILFAIXFAIL", pat = "FAIL";
for (let i = 0; i <= log.length - pat.length; i++) {
  const st = []; let ok = true;
  for (let j = 0; j < pat.length; j++) {
    const eq = log[i + j] === pat[j];
    st.push(`${log[i + j]}${eq ? "=" : "≠"}${pat[j]}`);
    if (!eq) { ok = false; break; }
  }
  const orig = i === 4 ? okc(false, "FALSE HIT (j = m-1)") : i === 8 ? okc(false, "never scanned (D5)") : i === 0 ? "hit" : "no hit";
  align.push([String(i), log.slice(i, i + 4), st.join("  "), ok ? okc(true, "HIT") : "no", orig]);
}
c.push(table(["i", "Window", "Comparisons until stop", "Corrected", "Original code"], align, [500, 1100, 3300, 1500, 2626], { size: 17, mono: [true, true, true, false, false] }));
c.push(P("Windows 1–3 and 5–7 stop at the first character (1 comparison each); window 4 stops at the fourth. The corrected scan performs 4+1+1+1+4+1+1+1+4 = 18 character comparisons; the optimised code reports exactly this number.", { before: 80 }));
c.push(P("**Why the empty-pattern guard?** With for-else an empty pattern would match at every index (nothing can mismatch). A zero-length signature is meaningless for the SOC, so `find_signature` returns `[]`. This guard is hardening, not one of the nine defects."));

c.push(H2("4.4 Boundary and regression tests"));
c.push(P("The boundary cases requested in the brief (empty blocklist, pattern at the very end, pattern longer than the log, equal severities, fewer than two events) plus further edge cases were run against both the original and the corrected module (`Supporting_Files/boundary_table.py`). The corrected module passes all 29 cases here (36 checks in `test_corrected.py`)."));
c.push(tabCap("Boundary cases: original versus corrected module"));
c.push(table(["Function", "Case", "Expected", "Original", "Corrected"],
  boundary.map((r) => [r.function, r.case, short(r.expected, 34),
    r.original_ok ? okc(true, "PASS") : { t: "FAIL  " + short(r.original, 30), color: BAD },
    r.corrected_ok ? okc(true, "PASS") : okc(false, "FAIL")]),
  [1350, 2650, 2000, 2026, 1000], { size: 15, mono: [false, false, true, true, false] }));
c.push(P(`Summary: original ${boundary.filter((r) => r.original_ok).length}/${boundary.length} passed (the nine passes are mostly cases where the answer happens to coincide); corrected ${boundary.filter((r) => r.corrected_ok).length}/${boundary.length}.`, { before: 80 }));

// ---------------------------------------------------------------- Part (c)
c.push(H1("5. Part (c) – Optimising the Corrected Module"));
c.push(P("Every optimisation preserves the corrected outputs. This is enforced by differential tests in `test_harness.py`: 300 random alert lists, 3,000 random blocklist queries, 300 random logs, 300 random integer point sets (small spans create many ties and duplicates) and 100 float point sets are compared against `corrected_module.py` and against independent reference implementations."));

c.push(H2("5.1 sort_alerts – is insertion sort still suitable?"));
c.push(B("Insertion sort costs (n − 1) + I comparisons, where I is the number of out-of-order pairs (inversions). It is excellent when I is small, i.e. nearly sorted input, and quadratic when I is large."));
c.push(B("Measured: 8,000 alerts in random order needed 14.6 million comparisons; with 1 % of the alerts re-scored (nearly sorted) only 159,702; with 10 re-scored alerts 37,176 (Section 6.3). At the production volume of 50,000 alerts insertion sort took 74.6 s on random input but 1.1 s on nearly sorted input."));
c.push(B("**Verdict:** insertion sort remains suitable only if the stream is guaranteed to be nearly sorted and short. The SOC cannot guarantee ordering, so an adaptive algorithm with an O(n log n) worst case is the safe choice."));
c.push(B("**Optimisation:** `list.sort(key=severity, reverse=True)` (Timsort). It detects existing runs, so nearly sorted data costs O(n); the worst case is O(n log n); it is stable (`reverse=True` still keeps equal elements in arrival order), so equal-severity alerts keep arrival order. The corrected insertion sort is kept as `insertion_sort_alerts` for the comparison counts."));

c.push(H2("5.2 is_blocked – repeated blocklist lookups"));
c.push(B("A linear scan costs up to m comparisons per query, so q queries cost O(q·m)."));
c.push(B("**Optimisation:** build a hash index once (`build_blocklist` → `frozenset`, O(m) time and space) and answer each query by membership test, O(1) on average. Total O(m + q)."));
c.push(B("Rebuild the index only when the blocklist changes. Matching stays exact-string, so results equal the sequential search (checked on 3,000 random queries, including duplicates in the list)."));

c.push(H2("5.3 find_signature – no redundant comparisons"));
c.push(B("**Removed:** the per-window `j == m-1` test (replaced by for-else), the off-by-one range (exactly n − m + 1 windows, never beyond the last full window) and any work when m = 0 or m > n (immediate return, zero comparisons)."));
c.push(B("**Kept (already minimal for brute force):** every window is abandoned at its first mismatching character, so no character is compared after a mismatch."));
c.push(B("**Optional compiled variant:** `find_signature_native` repeats `str.find` from index + 1 (overlapping hits kept). Same output, executed in compiled code: 0.6 ms versus 213 ms for a 1,000,000-character log."));
c.push(B("Brute force still has an O(n·m) worst case; the course technique is retained and this limit is reported honestly in Section 6."));

c.push(H2("5.4 closest_logins – fewer pairs, cheaper pairs"));
c.push(B("**No self or repeated pairs:** j runs from i + 1. This halves the work and removes the self-pair defect class (n² → n(n − 1)/2)."));
c.push(B("**No unnecessary square roots:** distances are compared as squared values because √ is monotonic; one `math.sqrt` is taken at the very end instead of one per pair."));
c.push(B("**Pruning:** points are sorted along one axis (the one with the larger spread; this also handles the case where all x are equal). In the inner loop, once the axis gap squared exceeds the best squared distance found so far, every later point is even farther away, so the loop breaks. Strict `>` (not `>=`) is used so that tied pairs are still examined."));
c.push(B("**Output preserved:** the original indices are kept and the tie-break (smallest (i, j) among equally close pairs) is applied explicitly, so the answer is identical to the brute-force version, including duplicates and ties."));
c.push(B("**Correctness argument:** if (aq − ap)² > best, then for all q' ≥ q the axis gap is at least as large, so d² ≥ (aq' − ap)² > best, and no pair that is skipped can be closer or equal."));

// ---------------------------------------------------------------- Part (d)
c.push(H1n("6. Part (d) – Before and After Analysis"));
c.push(H2("6.1 Operation counts and time complexity"));
c.push(P("n = number of items, m = blocklist size or pattern length (stated per row), q = number of queries, I = inversions. ‘Basic operation’ is the one counted in the experiments."));
c.push(tabCap("Complexity before and after optimisation"));
c.push(table(["Function", "Version", "Basic operation", "Best", "Worst", "Typical / derivation"], [
  ["sort_alerts", "Original / corrected (insertion)", "severity comparison", "n − 1\n(sorted)", "n(n−1)/2\n(reverse sorted)", "n − 1 + I. Random, k severity levels: I ≈ n²(1 − 1/k)/4 → Θ(n²)"],
  ["", "Optimised (Timsort)", "comparison", "n − 1", "≈ n·log₂n", "O(n) nearly sorted, O(n log n) always; stable"],
  ["is_blocked", "Corrected (linear)", "string comparison per query", "1", "m", "≈ 0.75·m for 50 % hits → q queries ≈ 0.75·q·m"],
  ["", "Optimised (hash set)", "hash lookup", "1", "O(m) rare collisions", "build m inserts once + q lookups → O(m + q)"],
  ["find_signature", "Original (buggy)", "char comparison + one extra j == m−1 test per window", "(n−m)·1", "(n−m)·(m+1)", "Scans n − m windows – misses one"],
  ["", "Corrected / optimised", "char comparison", "n − m + 1", "m·(n − m + 1) = Θ(nm)", "≈ (n−m+1)/(1 − 1/σ) on random text; σ = 26 → 1.04 per window. No extra test"],
  ["closest_logins", "Original (buggy)", "distance (with √)", "n²", "n²", "n² distances, n² square roots"],
  ["", "Corrected (brute force)", "distance (with √)", "n(n−1)/2", "n(n−1)/2", "Θ(n²); n = 8,000 → 31,996,000"],
  ["", "Optimised (sorted sweep)", "squared distance (no √)", "n − 1 pairs (+ sort)", "n(n−1)/2 + n log n", "~1.3n–1.6n pairs on spread points; worst case n²/8 on the L-shaped input; 1 √ in total"],
], [1250, 1550, 1700, 1000, 1400, 2126], { size: 16 }));

c.push(H2("6.2 Experimental set-up"));
c.push(B("Python 3.13 on a Linux cloud VM, single thread. **Operation counts are deterministic** (fixed seeds); run times are single runs and will differ on another machine."));
c.push(B("Closest pair: uniform random (x, y) in a 1,000 km × 1,000 km square, n = 1,000; 2,000; 4,000; 6,000; 8,000 (the brief asks for at least three sizes between 1,000 and 8,000). Brute force was an instrumented copy of the corrected function; both versions returned the identical pair at every size (asserted)."));
c.push(B("Insertion sort: severity uniformly random in 1…10. ‘Nearly sorted’ = a correctly ordered list in which 1 % (or only 10) of the alerts were re-scored with a new random severity, as for late-arriving or re-classified alerts. Comparisons were counted in `insertion_sort_alerts`."));
c.push(B("Blocklist: m = 2,000 addresses, q = 50,000 queries, about half of them blocked. Signature: random 26-letter logs of 100,000 / 500,000 / 1,000,000 characters, 8-character pattern with planted hits (including one at the very end)."));

c.push(H2("6.3 Results"));
c.push(H3("closest_logins – distance computations"));
c.push(tabCap("Distance computations of the brute-force and optimised closest_logins (single seeded run)"));
c.push(table(["n", "Original n²", "Brute force n(n−1)/2", "Optimised", "Reduction", "Brute time (s)", "Optimised time (s)", "Speed-up"],
  closest.map((r) => [N(r[0]), N(r[1]), N(r[2]), N(r[3]), "×" + N(r[4]), F(r[5], 2), F(r[6], 4), "×" + N(r[7])]),
  [800, 1250, 1500, 1000, 1000, 1000, 1226, 1250], { size: 16, align: Array(8).fill(AlignmentType.RIGHT) }));
c.push(image("fig_closest_pair.png", 480, 300));
c.push(figCap("Distance computations versus batch size (log scale): brute force grows quadratically, the pruned sweep almost linearly."));
c.push(P("Because the optimised count depends on how quickly a small best distance is found, one random sample is noisy (it is 375 at n = 1,000 and 3,214 at n = 2,000). The measurement was therefore repeated over 20 random data sets per size:"));
c.push(tabCap("Optimised distance computations over 20 random data sets per batch size"));
c.push(table(["n", "Brute force", "Optimised min", "Optimised mean", "Optimised max", "Mean reduction"],
  seeds.map((r) => [N(r[0]), N(r[1]), N(r[2]), N(r[3]), N(r[4]), "×" + N(r[5])]),
  [1000, 1800, 1500, 1600, 1500, 1626], { size: 17, align: Array(6).fill(AlignmentType.RIGHT) }));
c.push(P("Stress data sets (n = 4,000) show where the pruning helps and where it does not:", { before: 120 }));
c.push(tabCap("Behaviour of the optimised closest_logins on different data shapes (n = 4,000)"));
c.push(table(["Data set", "Brute force", "Optimised", "Reduction"],
  stress.map((r) => [r[0], N(r[1]), N(r[2]), "×" + N(Math.round(Number(r[3])))]),
  [4100, 1700, 1700, 1526], { size: 17, align: [AlignmentType.LEFT, AlignmentType.RIGHT, AlignmentType.RIGHT, AlignmentType.RIGHT] }));
c.push(P("The adversarial ‘L-shape’ (half of the points on the line x = 0 and half on y = 0) keeps the axis gap at zero for n/2 points, so (n/2)²/2 = 2,000,000 pairs are still examined (measured 2,002,999): the sweep is only four times better than brute force there. The guaranteed worst case therefore remains O(n²); for ordinary geographic data the pruning removes more than 99.9 % of the work.", { before: 80 }));

c.push(H3("sort_alerts – insertion-sort comparisons"));
c.push(tabCap("Insertion-sort comparisons: random versus nearly sorted alerts"));
c.push(table(["n", "Random", "Theory n²(1−1/k)/4", "1 % re-scored", "Inversions I", "10 re-scored", "Inversions I"],
  ins.map((r) => [N(r[0]), N(r[1]), N(r[7]), N(r[3]), N(r[4]), N(r[5]), N(r[6])]),
  [800, 1400, 1700, 1300, 1300, 1300, 1226], { size: 16, align: Array(7).fill(AlignmentType.RIGHT) }));
c.push(P("At n = 1,000, 1 % equals 10 alerts, so the two nearly-sorted columns coincide.", { size: 18, color: GREY }));
c.push(image("fig_insertion_sort.png", 480, 300));
c.push(figCap("Insertion-sort comparisons versus alerts (log scale)."));
c.push(tabCap("Run time of insertion sort and the optimised stable sort"));
c.push(table(["n", "Insertion – random (s)", "Optimised – random (s)", "Insertion – 1 % re-scored (s)", "Optimised – 1 % re-scored (s)"],
  stime.map((r) => [N(r[0]), r[1] === "nan" ? "74.62 *" : F(r[1], 3), F(r[2], 4), F(r[3], 4), F(r[4], 5)]),
  [1100, 1900, 1900, 2126, 2000], { size: 16, align: Array(5).fill(AlignmentType.RIGHT) }));
c.push(P("* measured separately in `Supporting_Files/sort_50000_random.py`: 557,436,864 comparisons, 74.62 s, against 0.0056 s for the optimised sort (×13,275).", { size: 18, color: GREY }));
c.push(image("fig_sort_time.png", 480, 300));
c.push(figCap("Run time on random alerts (log scale)."));

c.push(H3("is_blocked and find_signature"));
c.push(tabCap("Blocklist lookups: 50,000 queries against a 2,000-entry blocklist"));
c.push(table(["Method", "Operations", "Time (s)"], [
  ["Sequential search (corrected)", `${N(blk[3])} comparisons (q·m = ${N(Number(blk[1]) * Number(blk[0]))}; predicted 0.75·q·m = ${N(0.75 * Number(blk[1]) * Number(blk[0]))})`, F(blk[4], 3)],
  ["Hash index (optimised)", `${N(blk[0])} inserts (index build ${F(Number(blk[5]) * 1000, 2)} ms) + ${N(blk[7])} lookups`, F(blk[6], 4)],
], [2800, 4826, 1400], { size: 17, align: [AlignmentType.LEFT, AlignmentType.LEFT, AlignmentType.RIGHT] }));
c.push(tabCap("Signature scan on random logs (pattern length 8, alphabet 26)"));
c.push(table(["Log length n", "Windows n−m+1", "Char comparisons", "Per window", "Extra tests removed", "Brute force (s)", "str.find variant (s)"],
  sig.map((r) => [N(r[0]), N(r[2]), N(r[3]), F(Number(r[3]) / Number(r[2]), 3), N(r[4]), F(r[6], 3), F(r[7], 5)]),
  [1300, 1400, 1450, 1000, 1500, 1200, 1176], { size: 16, align: Array(7).fill(AlignmentType.RIGHT) }));
c.push(P("Controlled extremes (n = 100,000, m = 8): when every window fails at its first character the scan makes 99,993 comparisons (= n − m + 1); when every window fails at its last character it makes 799,944 (= m·(n − m + 1)). These are exactly the best and worst cases in Table 9.", { before: 80 }));
c.push(image("out_exp_1.png", 560, 300));
c.push(figCap("experiments.py – closest_logins output (rendered capture of the execution log)."));
c.push(image("out_exp_2.png", 560, 420));
c.push(figCap("experiments.py – insertion-sort run times."));
c.push(image("out_exp_3.png", 590, 260));
c.push(figCap("experiments.py – blocklist and signature results."));

c.push(H2("6.4 Do the measurements agree with the analysis?"));
c.push(tabCap("Predicted versus measured"));
c.push(table(["Quantity", "Analysis predicts", "Measured", "Agreement"], [
  ["Brute-force pair evaluations, n = 8,000", "n(n−1)/2 = 31,996,000", "31,996,000", okc(true, "exact")],
  ["Insertion comparisons, random, n = 8,000", "n²(1−1/k)/4 = 14,400,000", "14,609,276", okc(true, "+1.5 % (random variation)")],
  ["Insertion comparisons, random, n = 50,000", "n²(1−1/k)/4 = 562,500,000", "557,436,864", okc(true, "−0.9 %")],
  ["Insertion comparisons, nearly sorted", "(n − 1) + I", "equal to n − 1 + I within 3 (n = 8,000: 159,702 = 7,999 + 151,703)", okc(true, "exact (≤ 3 less)")],
  ["Insertion run time, random", "×4 per doubling of n", "0.60 s → 3.01 s → 11.37 s → 74.6 s (n = 5k, 10k, 20k, 50k)", okc(true, "quadratic")],
  ["Sequential blocklist comparisons", "0.75·q·m = 75,000,000", "74,864,582", okc(true, "−0.2 %")],
  ["Signature comparisons per window", "1/(1 − 1/26) = 1.0417", "1.040 (all three sizes)", okc(true, "agrees")],
  ["Pairs examined by pruned sweep (uniform data)", "Roughly linear in n (≈ 2n estimated from the shrinking best distance)", "mean 1.3n – 1.6n for n = 1,000…8,000", okc(true, "agrees; noisy per sample")],
  ["Pairs examined, L-shaped worst case", "(n/2)²/2 = 2,000,000", "2,002,999", okc(true, "exact within 0.2 %")],
  ["Wall-clock speed-up of closest_logins, n = 8,000", "Equal to the operation reduction?", "Operation reduction ×3,689; time ×1,029", okc(false, "smaller – see below")],
], [2700, 2300, 2700, 1326], { size: 16 }));
c.push(P("**Where they differ, and why.** The brute-force counts and the insertion-sort, blocklist and signature predictions agree to within random variation (≤ 1.5 %). Two things deserve comment:", { before: 100 }));
c.push(B("The wall-clock speed-up of the optimised closest-pair function (×1,029) is smaller than the reduction in distance computations (×3,689) because the optimised version also pays for sorting, building the coordinate arrays and the axis choice, which are not distance computations. The count measures the dominant brute-force cost; time includes this fixed O(n log n) overhead."));
c.push(B("A single random data set gives a noisy optimised count (the first row of the single-run table is 375 for n = 1,000 but 3,214 for n = 2,000). The 20-seed table removes this noise and shows the expected slow, near-linear growth. The analysis cannot promise this for every input: the L-shaped data show the O(n²) worst case, which is why the complexity table lists it."));
c.push(P("**Conclusion.** For the production workload the optimised module needs about 12,700 distance computations (mean) for an 8,000-event batch instead of 31,996,000, sorts 50,000 alerts in milliseconds instead of more than a minute, and answers each blocklist query in constant time – while returning byte-for-byte the same outputs as the corrected module."));

// ---------------------------------------------------------------- Part (e)
c.push(H1("7. Part (e) – Production-Quality Code and Repository"));
c.push(H2("7.1 What the final module provides"));
c.push(B("`optimised_module.py` (Appendix A): module docstring, function docstrings stating input, output, complexity and edge-case behaviour, inline comments on every optimisation, and an optional `stats` dictionary through which functions report operation counts without a separate instrumented copy."));
c.push(B("Behaviour at the edges is defined and tested: empty list, single element, equal severities, empty blocklist, empty or over-long pattern, fewer than two login events → `(None, None)`, duplicate and tied locations."));
c.push(B("`test_harness.py` checks every function on the issued data, every boundary case of Part (b), 1,000+ random differential cases and the operation counters. Run: `python3 test_harness.py` (exit status 0 means success)."));

c.push(H2("7.2 How to run everything"));
c.push(...codeBlock([
  "cd CO2_Debugging_Optimisation/Source_Code",
  "python3 run_original.py          # Part (a): reproduce the failures",
  "python3 debug_steps.py           # Part (b): one fix at a time + traces",
  "python3 test_corrected.py        # Part (b): boundary tests, corrected module",
  "python3 test_harness.py          # Part (e): full test harness (67 checks)",
  "python3 experiments.py           # Part (d): counts, timings, charts (about 2 min)",
  "python3 experiments_seeds.py     # Part (d): 20-seed closest-pair table",
], 17));

c.push(H2("7.3 Publishing to GitHub"));
c.push(P("The repository folder is ready to publish (no credentials were available to upload it from here). From the folder `CO2_Debugging_Optimisation/`:"));
c.push(...codeBlock([
  "git init",
  "git add .",
  'git commit -m "CO2 debugging and optimisation task: SentinelOps module"',
  "git branch -M main",
  "git remote add origin https://github.com/<your-username>/CO2_Debugging_Optimisation.git",
  "git push -u origin main",
], 17));
c.push(P("Then paste the repository link on the cover page of this report and share it through Google Classroom.", { before: 80 }));

c.push(H2("7.4 Rubric coverage"));
c.push(tabCap("Where each assessment criterion is addressed"));
c.push(table(["Criterion (weight)", "Evidence in this report"], [
  ["Problem identification (20 %)", "Section 2: expected/actual outputs, defect register D1–D9 with faulty line and nature of error; Section 4.1 root causes"],
  ["Debugging (25 %)", "Section 4: one-line-at-a-time versions, traces (insertion trace, alignment table), re-tests after every fix, 29 boundary cases against original and corrected code"],
  ["Optimisation (20 %)", "Section 5: sort / hash index / no-redundancy scan / pruned closest pair, each with a correctness argument and differential tests"],
  ["Analysis (20 %)", "Section 6: operation counts and complexity per function before/after, five batch sizes, 20-seed statistics, stress data, predicted-versus-measured table"],
  ["Code quality (15 %)", "Section 7 and Appendix A: docstrings, comments, harness with 67 checks, organised repository, README"],
], [2600, 6426], { size: 18 }));

c.push(H2("7.5 Test-harness execution output"));
c.push(image("out_harness_1.png", 520, 720));
c.push(figCap("test_harness.py output, part 1 (issued data and boundary cases)."));
c.push(image("out_harness_2.png", 520, 720));
c.push(figCap("test_harness.py output, part 2 – RESULT: 67 passed, 0 failed."));

c.push(H2("7.6 Declaration"));
c.push(P("The Code of Conduct certification must be completed and signed by the student personally:"));
c.push(P("I ______________________________ (Name / Reg. No.) certify that this submission is my original work and that I have adhered to the guidelines specified for this assessment. I understand that any violation of academic integrity rules will result in disciplinary action."));
c.push(P("Signature of the Student: ____________________          Date: ______________", { before: 200 }));

// ---------------------------------------------------------------- Appendix
c.push(H1("Appendix A – optimised_module.py (final code)"));
c.push(...codeBlock(optSource.slice(0, optSource.length - (optSource[optSource.length - 1] === "" ? 1 : 0)), 15));

// ================================================================= DOCUMENT
const doc = new Document({
  creator: "Student", title: "CSA06 CO2 – SentinelOps Debugging and Optimisation", description: "CO2 Debugging and Optimisation Task report",
  styles: {
    default: { document: { run: { font: FONT, size: 21 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, font: FONT, color: BLUE },
        paragraph: { spacing: { before: 120, after: 200 }, outlineLevel: 0, border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: "2A78D6", space: 4 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 25, bold: true, font: FONT, color: BLUE },
        paragraph: { spacing: { before: 260, after: 100 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 22, bold: true, font: FONT, color: "333333" },
        paragraph: { spacing: { before: 180, after: 80 }, outlineLevel: 2 } },
    ],
  },
  numbering: { config: [{ reference: "bullets", levels: [
    { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 500, hanging: 260 } } } },
    { level: 1, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 900, hanging: 260 } } } } ] }] },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1300, bottom: 1200, left: 1440, right: 1440 } } },
    headers: { default: new Header({ children: [new Paragraph({ spacing: { after: 0 }, border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "C9CDD3", space: 4 } },
      children: [run("CSA06 – Design and Analysis of Algorithms  |  CO2 Debugging and Optimisation Task  |  SentinelOps", { size: 16, color: GREY })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
      new TextRun({ text: "Page ", font: FONT, size: 16, color: GREY }), new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 16, color: GREY }),
      new TextRun({ text: " of ", font: FONT, size: 16, color: GREY }), new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FONT, size: 16, color: GREY })] })] }) },
    children: c,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  const out = path.join(__dirname, "CO2_Debugging_Optimisation_Report.docx");
  fs.writeFileSync(out, buf);
  console.log("wrote", out, (buf.length / 1024).toFixed(0) + " KB");
});
