"""
SentinelOps SOC alert-triage module - FINAL, OPTIMISED version.

Every function returns exactly the same output as corrected_module.py (this is
checked by differential tests in test_harness.py) but is faster for the
production workload (~50,000 alerts/day, batches of ~8,000 login events).

Functions
---------
sort_alerts(alerts)                  stable, highest-severity-first, adaptive sort
insertion_sort_alerts(alerts, stats) corrected insertion sort (kept for analysis)
build_blocklist(blocklist)           one-off hash index of the blocklist
is_blocked(index, ip)                O(1) average membership test
is_blocked_sequential(blocklist, ip) corrected linear search (baseline)
find_signature(log, pattern, stats)  brute-force scan, no redundant comparisons
find_signature_native(log, pattern)  same result via the runtime's substring search
closest_logins(events, stats)        pruned closest pair, squared distances, 1 sqrt

`stats` is an optional dict; when supplied the function stores operation counts
in it (used by experiments.py).  Passing None costs nothing noticeable.
"""
import math
from operator import itemgetter


# --------------------------------------------------------------------- sorting
def sort_alerts(alerts):
    """Sort (id, severity) alerts by severity, highest first; STABLE.

    Uses the runtime's Timsort: O(n) on nearly sorted input (it detects the
    existing runs), O(n log n) in the worst case, and stable, so alerts of
    equal severity keep their arrival order.  Sorts in place and returns the
    same list, like the original function.
    """
    # reverse=True still preserves the original order of equal elements.
    alerts.sort(key=itemgetter(1), reverse=True)
    return alerts


def insertion_sort_alerts(alerts, stats=None):
    """Corrected insertion sort (baseline for the Part (d) measurements).

    stats["comparisons"] = number of severity comparisons performed.
    Adaptive: costs about n - 1 + I comparisons, I = number of inversions.
    """
    comparisons = 0
    for i in range(1, len(alerts)):
        key = alerts[i]
        key_sev = key[1]
        j = i - 1
        while j >= 0:
            comparisons += 1
            if alerts[j][1] < key_sev:       # strict '<' keeps the sort stable
                alerts[j + 1] = alerts[j]
                j -= 1
            else:
                break
        alerts[j + 1] = key
    if stats is not None:
        stats["comparisons"] = comparisons
    return alerts


# -------------------------------------------------------------------- blocklist
def build_blocklist(blocklist):
    """Build the lookup index ONCE per blocklist version: O(m) time and space."""
    return frozenset(blocklist)


def is_blocked(index, ip):
    """Return True if `ip` is in the blocklist index from build_blocklist().

    O(1) average per query instead of O(m).  (If a plain list is passed it
    still works, falling back to a linear scan.)
    """
    return ip in index


def is_blocked_sequential(blocklist, ip, stats=None):
    """Corrected sequential search (baseline).  Counts comparisons in stats."""
    comparisons = 0
    for entry in blocklist:
        comparisons += 1
        if entry == ip:
            if stats is not None:
                stats["comparisons"] = stats.get("comparisons", 0) + comparisons
            return True
    if stats is not None:
        stats["comparisons"] = stats.get("comparisons", 0) + comparisons
    return False


# ------------------------------------------------------------ signature search
def find_signature(log, pattern, stats=None):
    """Brute-force search: every start index of `pattern` in `log` (overlaps included).

    No redundant work:
      * only the n-m+1 alignments that fit inside the log are tried;
      * an alignment is abandoned at its FIRST mismatching character;
      * a hit is recorded through for-else, so there is no extra "was that the
        last character?" test per alignment;
      * m == 0 or m > n returns immediately with zero comparisons.
    stats["comparisons"] = character comparisons performed.
    """
    n, m = len(log), len(pattern)
    comparisons = 0
    hits = []
    if 0 < m <= n:
        for i in range(n - m + 1):
            for j in range(m):
                comparisons += 1
                if log[i + j] != pattern[j]:
                    break
            else:                            # no mismatch -> full match at i
                hits.append(i)
    if stats is not None:
        stats["comparisons"] = comparisons
    return hits


def find_signature_native(log, pattern):
    """Same output as find_signature, using str.find (compiled substring search)."""
    if not pattern or len(pattern) > len(log):
        return []
    hits = []
    i = log.find(pattern)
    while i != -1:
        hits.append(i)
        i = log.find(pattern, i + 1)         # i + 1 => overlapping hits kept
    return hits


# --------------------------------------------------------------- closest pair
def closest_logins(events, stats=None):
    """Closest pair of (x, y) login locations -> ((i, j), distance), i < j.

    Returns (None, None) for fewer than two events.  Same answer as the
    brute-force version, including the tie-break (lexicographically smallest
    (i, j) among equally close pairs), but:
      * each unordered pair is considered at most once (no self / mirrored pairs);
      * comparisons use SQUARED distances - one math.sqrt at the very end;
      * points are sorted along the axis with the larger spread and the inner
        loop stops as soon as the axis gap alone exceeds the best distance
        found so far (those pairs cannot be closer).  '>' rather than '>=' is
        used so that tied pairs are still examined.
    stats["distance_computations"] = pairs whose distance was actually computed.
    """
    n = len(events)
    if n < 2:
        if stats is not None:
            stats["distance_computations"] = 0
        return None, None

    xs_all = [e[0] for e in events]
    ys_all = [e[1] for e in events]
    # sweep along the axis with the larger spread (robust when all x are equal)
    if (max(ys_all) - min(ys_all)) > (max(xs_all) - min(xs_all)):
        a_all, b_all = ys_all, xs_all
    else:
        a_all, b_all = xs_all, ys_all

    order = sorted(range(n), key=a_all.__getitem__)       # indices by sweep axis
    a = [a_all[k] for k in order]
    b = [b_all[k] for k in order]

    best2 = math.inf                                      # best SQUARED distance
    best_pair = None
    count = 0
    for p in range(n - 1):
        ap, bp, ip_ = a[p], b[p], order[p]
        for q in range(p + 1, n):
            da = a[q] - ap
            da2 = da * da
            if da2 > best2:                               # prune: cannot be closest
                break
            db = b[q] - bp
            d2 = da2 + db * db
            count += 1
            iq = order[q]
            pair = (ip_, iq) if ip_ < iq else (iq, ip_)
            if d2 < best2 or (d2 == best2 and pair < best_pair):
                best2 = d2
                best_pair = pair
    if stats is not None:
        stats["distance_computations"] = count
    return best_pair, math.sqrt(best2)
