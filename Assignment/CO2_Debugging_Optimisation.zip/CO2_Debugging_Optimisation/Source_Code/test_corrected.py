"""Part (b): boundary + regression tests for corrected_module.py."""
import math
from corrected_module import sort_alerts, is_blocked, find_signature, closest_logins

passed = failed = 0
def check(name, actual, expected):
    global passed, failed
    ok = actual == expected
    passed += ok; failed += (not ok)
    print(f"[{'PASS' if ok else 'FAIL'}] {name}\n        actual={actual!r}\n      expected={expected!r}")

print("--- issued test data ---")
check("sort_alerts issued data",
      sort_alerts([("A1", 3), ("A2", 9), ("A3", 5), ("A4", 9), ("A5", 1)]),
      [("A2", 9), ("A4", 9), ("A3", 5), ("A1", 3), ("A5", 1)])
bl = ["10.0.0.5", "10.0.0.9", "172.16.4.2"]
check("is_blocked 10.0.0.9", is_blocked(bl, "10.0.0.9"), True)
check("is_blocked 10.0.0.5", is_blocked(bl, "10.0.0.5"), True)
check("is_blocked 8.8.8.8",  is_blocked(bl, "8.8.8.8"), False)
check("find_signature issued", find_signature("FAILFAIXFAIL", "FAIL"), [0, 8])
ev = [(2, 3), (12, 30), (40, 50), (5, 1), (12, 10), (3, 4)]
check("closest_logins issued", closest_logins(ev), ((0, 5), math.sqrt(2)))

print("--- boundary: sort_alerts ---")
check("empty list", sort_alerts([]), [])
check("single alert", sort_alerts([("A", 4)]), [("A", 4)])
check("all equal severity keeps arrival order",
      sort_alerts([("A", 5), ("B", 5), ("C", 5)]), [("A", 5), ("B", 5), ("C", 5)])
check("already sorted (desc)", sort_alerts([("A", 9), ("B", 5), ("C", 1)]), [("A", 9), ("B", 5), ("C", 1)])
check("reverse sorted (asc)", sort_alerts([("A", 1), ("B", 5), ("C", 9)]), [("C", 9), ("B", 5), ("A", 1)])
check("new max at the end moves to index 0 (D1/D2 case)",
      sort_alerts([("A", 1), ("B", 2), ("C", 3), ("D", 10)])[0], ("D", 10))
check("stability with ties mixed",
      sort_alerts([("a", 2), ("b", 7), ("c", 2), ("d", 7), ("e", 2)]),
      [("b", 7), ("d", 7), ("a", 2), ("c", 2), ("e", 2)])

print("--- boundary: is_blocked ---")
check("empty blocklist", is_blocked([], "1.1.1.1"), False)
check("match is first element", is_blocked(bl, "10.0.0.5"), True)
check("match is last element", is_blocked(bl, "172.16.4.2"), True)
check("single-element list, match", is_blocked(["9.9.9.9"], "9.9.9.9"), True)
check("single-element list, miss", is_blocked(["9.9.9.9"], "9.9.9.8"), False)
check("partial string is not a match", is_blocked(bl, "10.0.0"), False)

print("--- boundary: find_signature ---")
check("pattern at very end of log", find_signature("xxxxFAIL", "FAIL"), [4])
check("pattern at very start", find_signature("FAILxxxx", "FAIL"), [0])
check("pattern longer than log", find_signature("FAI", "FAIL"), [])
check("pattern one longer than log", find_signature("FAIL", "FAILX"), [])
check("pattern == log", find_signature("FAIL", "FAIL"), [0])
check("empty log", find_signature("", "FAIL"), [])
check("empty pattern", find_signature("abc", ""), [])
check("overlapping hits", find_signature("AAAA", "AA"), [0, 1, 2])
check("near-miss on last char only (D6)", find_signature("FAIX", "FAIL"), [])
check("single-char pattern", find_signature("abcab", "a"), [0, 3])
check("no occurrence", find_signature("abcdef", "xyz"), [])

print("--- boundary: closest_logins ---")
check("zero events", closest_logins([]), (None, None))
check("one event", closest_logins([(1, 1)]), (None, None))
check("two events", closest_logins([(0, 0), (3, 4)]), ((0, 1), 5.0))
check("duplicate locations -> distance 0", closest_logins([(1, 1), (9, 9), (1, 1)]), ((0, 2), 0.0))
check("tie: first pair in (i, j) order wins",
      closest_logins([(0, 0), (1, 0), (2, 0)]), ((0, 1), 1.0))
check("negative coordinates", closest_logins([(-5, -5), (-4, -5), (10, 10)]), ((0, 1), 1.0))

print(f"\nRESULT: {passed} passed, {failed} failed")
raise SystemExit(1 if failed else 0)
