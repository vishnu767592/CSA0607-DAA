"""
Part (d): experimental measurements (operation counts and wall-clock time).

Writes CSV/JSON/text results to ../Supporting_Files and PNG charts to ../Report/figures.
Deterministic: every random generator is seeded.
"""
import csv, json, math, os, random, time
import corrected_module as ref
import optimised_module as opt

HERE = os.path.dirname(os.path.abspath(__file__))
SUP = os.path.join(HERE, "..", "Supporting_Files")
FIG = os.path.join(HERE, "..", "Report", "figures")
results = {}


def write_csv(name, header, rows):
    with open(os.path.join(SUP, name), "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)


def timed(fn, *a):
    t = time.perf_counter(); r = fn(*a); return r, time.perf_counter() - t


# ---------------------------------------------------------------- 1. closest pair
def brute_counted(ev):
    """Instrumented copy of corrected_module.closest_logins (counts distances / sqrt)."""
    best = math.inf; pair = None; cnt = 0
    for i in range(len(ev)):
        for j in range(i + 1, len(ev)):
            d = math.sqrt((ev[i][0] - ev[j][0]) ** 2 + (ev[i][1] - ev[j][1]) ** 2)
            cnt += 1
            if d < best:
                best = d; pair = (i, j)
    return (pair, best), cnt


print("== 1. closest_logins: distance computations ==")
rows = []
for n in (1000, 2000, 4000, 6000, 8000):
    rng = random.Random(n)
    ev = [(rng.uniform(0, 1000), rng.uniform(0, 1000)) for _ in range(n)]   # km
    (bres, bcnt), tb = timed(brute_counted, ev)
    st = {}
    ores, to = timed(opt.closest_logins, ev, st)
    assert bres == ores, "output changed!"
    assert bres == ref.closest_logins(ev) if n <= 2000 else True
    rows.append([n, n * n, bcnt, st["distance_computations"], round(bcnt / st["distance_computations"], 1),
                 round(tb, 3), round(to, 4), round(tb / to, 1)])
    print(f"n={n:>5}  original n^2={n*n:>10}  brute n(n-1)/2={bcnt:>10}  optimised={st['distance_computations']:>8}"
          f"  reduction x{bcnt/st['distance_computations']:.0f}  t_brute={tb:.2f}s t_opt={to:.4f}s")
write_csv("closest_pair_results.csv",
          ["n", "original_n2", "brute_force_n(n-1)/2", "optimised_distance_computations",
           "reduction_factor", "brute_time_s", "optimised_time_s", "speedup"], rows)
results["closest"] = rows

print("\n-- stress datasets (n = 4000) --")
n = 4000
rng = random.Random(7)
stress = {}
stress["uniform random"] = [(rng.uniform(0, 1000), rng.uniform(0, 1000)) for _ in range(n)]
stress["all same x (sweep switches to y)"] = [(500.0, rng.uniform(0, 1000)) for _ in range(n)]
stress["10 tight clusters"] = [(c[0] + rng.gauss(0, 3), c[1] + rng.gauss(0, 3))
                               for c in [(rng.uniform(0, 1000), rng.uniform(0, 1000)) for _ in range(10)]
                               for _ in range(n // 10)]
h = n // 2   # adversarial "L-shape": half the points on x=0, half on y=0
stress["adversarial L-shape (worst case)"] = ([(0.0, 1000.0 * k / h) for k in range(h)] +
                                              [(1000.0 * k / h, 0.0) for k in range(1, h + 1)])
srows = []
for name, ev in stress.items():
    st = {}
    ores, to = timed(opt.closest_logins, ev, st)
    assert ores == ref.closest_logins(ev), name
    srows.append([name, n * (n - 1) // 2, st["distance_computations"],
                  round(n * (n - 1) / 2 / st["distance_computations"], 1), round(to, 4)])
    print(f"{name:<36} brute={n*(n-1)//2:>9} optimised={st['distance_computations']:>9} "
          f"reduction x{n*(n-1)/2/st['distance_computations']:.1f}")
write_csv("closest_pair_stress.csv", ["dataset(n=4000)", "brute_force", "optimised", "reduction_factor", "optimised_time_s"], srows)
results["stress"] = srows

# ---------------------------------------------------------------- 2. insertion sort
K = 10          # severity levels 1..10


def make_alerts(n, mode, seed):
    """random | stray10 (10 re-scored alerts) | stray1pct (1% re-scored alerts).

    'Nearly sorted' = a list that was in correct order (severity descending) and
    then a few alerts were re-scored with a new random severity, leaving them
    out of place (late-arriving or re-classified alerts).
    """
    rng = random.Random(seed)
    base = [(f"A{i}", rng.randint(1, K)) for i in range(n)]
    if mode == "random":
        return base
    data = sorted(base, key=lambda a: -a[1])
    k = 10 if mode == "stray10" else n // 100
    for p in rng.sample(range(n), k):
        data[p] = (data[p][0], rng.randint(1, K))
    return data


def inversions(data):
    """Exact number of pairs i<j with severity_i < severity_j (= insertion-sort shifts)."""
    cnt = [0] * (K + 2); inv = 0
    for _, s_ in data:
        inv += sum(cnt[1:s_]); cnt[s_] += 1
    return inv


print("== 2. insertion-sort comparisons (severity 1-10) ==")
rows = []
for n in (1000, 2000, 4000, 8000):
    row = [n]
    line = f"n={n:>5} "
    for mode in ("random", "stray1pct", "stray10"):
        data = make_alerts(n, mode, 100 + n)
        st = {}
        out = opt.insertion_sort_alerts(list(data), st)
        assert out == sorted(data, key=lambda a: -a[1])
        inv = inversions(data)
        row += [st["comparisons"], inv]
        line += f"| {mode}: comps={st['comparisons']:>9} (n-1+I={n-1+inv:>9}, I={inv:>8}) "
    theory = round(n * n * (1 - 1 / K) / 4)
    row.append(theory)
    rows.append(row)
    print(line + f"| random theory n^2(1-1/k)/4={theory}")
write_csv("insertion_sort_comparisons.csv",
          ["n", "random_comparisons", "random_inversions", "stray_1pct_comparisons", "stray_1pct_inversions",
           "stray_10_comparisons", "stray_10_inversions", "random_theory_n2(1-1/k)/4"], rows)
results["insertion"] = rows

print("\n-- wall-clock: insertion sort vs Timsort (severity 1-10) --")
trows = []
for n, do_ins_rand in ((5000, True), (10000, True), (20000, True), (50000, False)):
    rand = make_alerts(n, "random", n)
    near = make_alerts(n, "stray1pct", n)
    _, t_ins_n = timed(opt.insertion_sort_alerts, list(near))
    _, t_tim_n = timed(opt.sort_alerts, list(near))
    _, t_tim_r = timed(opt.sort_alerts, list(rand))
    t_ins_r = timed(opt.insertion_sort_alerts, list(rand))[1] if do_ins_rand else float("nan")
    trows.append([n, t_ins_r, t_tim_r, t_ins_n, t_tim_n])
    print(f"n={n:>6} random: insertion={t_ins_r:8.3f}s timsort={t_tim_r:.4f}s | 1%-stray: insertion={t_ins_n:.4f}s timsort={t_tim_n:.5f}s")
write_csv("sort_timing.csv", ["n", "insertion_random_s", "timsort_random_s", "insertion_1pct_stray_s", "timsort_1pct_stray_s"],
          [[r[0]] + [round(x, 5) for x in r[1:]] for r in trows])
results["sort_timing"] = trows

# ---------------------------------------------------------------- 3. blocklist
print("\n== 3. blocklist lookups (m=2000 entries, q=50000 queries, 50% blocked) ==")
rng = random.Random(5)
m, q = 2000, 50000
pool = [f"{rng.randint(1,223)}.{rng.randint(0,255)}.{rng.randint(0,255)}.{rng.randint(1,254)}" for _ in range(m)]
pool = list(dict.fromkeys(pool)); m = len(pool)
qs = [rng.choice(pool) if rng.random() < 0.5 else f"203.0.{rng.randint(0,255)}.{rng.randint(0,255)}" for _ in range(q)]
st = {"comparisons": 0}
t = time.perf_counter(); res_seq = [opt.is_blocked_sequential(pool, x, st) for x in qs]; t_seq = time.perf_counter() - t
t = time.perf_counter(); index = opt.build_blocklist(pool); t_build = time.perf_counter() - t
t = time.perf_counter(); res_set = [opt.is_blocked(index, x) for x in qs]; t_set = time.perf_counter() - t
assert res_seq == res_set == [ref.is_blocked(pool, x) for x in qs[:2000]] + res_seq[2000:]
blk = sum(res_seq)
print(f"m={m} q={q} blocked={blk}  sequential comparisons={st['comparisons']}  (q*m={q*m})")
print(f"sequential time={t_seq:.3f}s  index build={t_build*1000:.2f}ms  hash lookup time={t_set:.4f}s  speedup x{t_seq/t_set:.0f}")
write_csv("blocklist_results.csv", ["m", "queries", "blocked_hits", "sequential_comparisons", "sequential_time_s",
                                    "index_build_s", "hash_lookup_time_s", "hash_lookups"],
          [[m, q, blk, st["comparisons"], round(t_seq, 4), round(t_build, 6), round(t_set, 4), q]])
results["blocklist"] = dict(m=m, q=q, comps=st["comparisons"], t_seq=t_seq, t_set=t_set, t_build=t_build, blocked=blk)

# ---------------------------------------------------------------- 4. signature scan
print("\n== 4. find_signature ==")
rows = []
for n in (100_000, 500_000, 1_000_000):
    rng = random.Random(n)
    log = "".join(rng.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ") for _ in range(n))
    pat = "FAILEDLO"; m_ = len(pat)
    L = list(log)
    for pos in (10, n // 2, n - m_):                    # plant hits incl. one at the very end
        L[pos:pos + m_] = pat
    log = "".join(L)
    st = {}
    hits, t_b = timed(opt.find_signature, log, pat, st)
    nat, t_n = timed(opt.find_signature_native, log, pat)
    assert hits == nat == ref.find_signature(log, pat)
    windows = n - m_ + 1
    rows.append([n, m_, windows, st["comparisons"], windows, len(hits), round(t_b, 4), round(t_n, 5)])
    print(f"n={n:>8} m={m_} windows={windows:>8} char comparisons={st['comparisons']:>8} "
          f"(per window {st['comparisons']/windows:.3f})  hits={hits[:3]}..{hits[-1]}  brute={t_b:.3f}s native={t_n:.5f}s")
write_csv("signature_results.csv", ["n", "m", "windows", "char_comparisons", "removed_j==m-1_tests",
                                    "hits", "brute_time_s", "native_time_s"], rows)
results["signature"] = rows
n, m_ = 100_000, 8
for label, log, pat in (("best case  (every window fails at 1st char)", "A" * n, "B" + "A" * (m_ - 1)),
                        ("worst case (every window fails at last char)", "A" * n, "A" * (m_ - 1) + "B")):
    st = {}; opt.find_signature(log, pat, st)
    print(f"{label}: comparisons={st['comparisons']}  windows={n-m_+1}  m*(windows)={m_*(n-m_+1)}")
    results[label[:4]] = st["comparisons"]

json.dump({k: v for k, v in results.items()}, open(os.path.join(SUP, "experiment_results.json"), "w"), indent=1, default=str)

# ---------------------------------------------------------------- charts
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
BLUE, ORANGE, INK, GRID = "#2a78d6", "#eb6834", "#0b0b0b", "#d9d8d4"
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.edgecolor": GRID, "axes.labelcolor": "#52514e",
                     "xtick.color": "#52514e", "ytick.color": "#52514e", "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
                     "axes.axisbelow": True})


def finish(ax, title, xl, yl, name):
    ax.set_title(title, loc="left", color=INK, fontsize=11, fontweight="bold")
    ax.set_xlabel(xl); ax.set_ylabel(yl)
    ax.figure.tight_layout()
    ax.figure.savefig(os.path.join(FIG, name), dpi=200, facecolor="white")
    plt.close(ax.figure)


c = results["closest"]
fig, ax = plt.subplots(figsize=(6.4, 3.8))
ns = [r[0] for r in c]
ax.plot(ns, [r[2] for r in c], color=BLUE, lw=2, marker="o", ms=6, mec="white", mew=1.5)
ax.plot(ns, [r[3] for r in c], color=ORANGE, lw=2, marker="o", ms=6, mec="white", mew=1.5)
ax.set_yscale("log"); ax.set_xticks(ns)
ax.annotate("Brute force  n(n-1)/2", (ns[-1], c[-1][2]), xytext=(-6, 8), textcoords="offset points", ha="right", color=INK, fontsize=9)
ax.annotate("Optimised (pruned)", (ns[-1], c[-1][3]), xytext=(-6, -16), textcoords="offset points", ha="right", color=INK, fontsize=9)
ax.legend(["Brute force", "Optimised"], frameon=False, loc="center left", fontsize=8)
finish(ax, "closest_logins: distance computations", "Login events in batch (n)", "Distance computations (log scale)", "fig_closest_pair.png")

r = results["insertion"]
GREEN = "#1baf7a"
fig, ax = plt.subplots(figsize=(6.4, 3.8))
ns = [x[0] for x in r]
for idx, col, lab in ((1, BLUE, "Random order"), (3, ORANGE, "1% re-scored"), (5, GREEN, "10 re-scored")):
    ax.plot(ns, [x[idx] for x in r], color=col, lw=2, marker="o", ms=6, mec="white", mew=1.5)
    ax.annotate(lab, (ns[-1], r[-1][idx]), xytext=(-6, 7), textcoords="offset points", ha="right", color=INK, fontsize=9)
ax.set_yscale("log"); ax.set_xticks(ns)
ax.legend(["Random order", "Nearly sorted (1% re-scored)", "Nearly sorted (10 re-scored)"], frameon=False, loc="center left", fontsize=8)
finish(ax, "Insertion sort: comparisons", "Alerts (n)", "Comparisons (log scale)", "fig_insertion_sort.png")

# runtime comparison, log scale bars (insertion vs timsort on random, per n)
t = [x for x in results["sort_timing"] if not math.isnan(x[1])]
fig, ax = plt.subplots(figsize=(6.4, 3.8))
xs = list(range(len(t))); w = 0.36
ax.bar([x - w / 2 for x in xs], [x[1] for x in t], w - 0.04, color=BLUE)
ax.bar([x + w / 2 for x in xs], [x[2] for x in t], w - 0.04, color=ORANGE)
ax.set_yscale("log"); ax.set_xticks(xs); ax.set_xticklabels([f"{x[0]:,}" for x in t])
ax.legend(["Insertion sort", "Timsort (optimised)"], frameon=False, fontsize=8, loc="upper left")
finish(ax, "sort_alerts on random alerts: run time", "Alerts (n)", "Seconds (log scale)", "fig_sort_time.png")
print("\ncharts written")
