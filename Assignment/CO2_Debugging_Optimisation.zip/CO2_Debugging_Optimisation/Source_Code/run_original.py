"""Part (a): run the ORIGINAL module on the issued test data."""
from original_module import sort_alerts, is_blocked, find_signature, closest_logins

alerts = [("A1", 3), ("A2", 9), ("A3", 5), ("A4", 9), ("A5", 1)]
blocklist = ["10.0.0.5", "10.0.0.9", "172.16.4.2"]
queries = ["10.0.0.9", "10.0.0.5", "8.8.8.8"]
log, pattern = "FAILFAIXFAIL", "FAIL"
events = [(2, 3), (12, 30), (40, 50), (5, 1), (12, 10), (3, 4)]

print("1) sort_alerts   input :", alerts)
print("   actual output       :", sort_alerts(list(alerts)))
print("   expected output     :", [("A2", 9), ("A4", 9), ("A3", 5), ("A1", 3), ("A5", 1)])
print()
print("2) is_blocked")
for q in queries:
    print(f"   {q:<11} actual={is_blocked(blocklist, q)}")
print("   expected: 10.0.0.9 -> True, 10.0.0.5 -> True, 8.8.8.8 -> False")
print()
print("3) find_signature(%r, %r)" % (log, pattern))
print("   actual output   :", find_signature(log, pattern))
print("   expected output :", [0, 8])
print()
print("4) closest_logins")
print("   actual output   :", closest_logins(events))
print("   expected output : ((0, 5), 1.4142135623730951)")
