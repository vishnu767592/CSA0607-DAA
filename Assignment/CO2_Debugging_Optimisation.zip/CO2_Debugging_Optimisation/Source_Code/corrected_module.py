"""
SentinelOps SOC alert-triage module - CORRECTED version (Part b).

This is the original code with ONLY the nine defects repaired (D1-D9, each
marked "FIX Dn").  The algorithms are deliberately unchanged (insertion sort,
sequential search, brute-force string match, brute-force closest pair) so the
effect of every fix can be seen in isolation.  The optimised version is in
optimised_module.py.
"""
import math


def sort_alerts(alerts):
    """Insertion sort of (id, severity) tuples, highest severity first.

    Stable: alerts of equal severity keep their arrival order (we only shift
    an element while its severity is STRICTLY smaller than the key's).
    """
    for i in range(1, len(alerts)):
        key = alerts[i]
        j = i - 1
        while j >= 0 and alerts[j][1] < key[1]:   # FIX D1: was  j > 0
            alerts[j + 1] = alerts[j]
            j -= 1
        alerts[j + 1] = key                        # FIX D2: was  alerts[j] = key
    return alerts


def is_blocked(blocklist, ip):
    """Sequential search: True if `ip` is on the blocklist, else False."""
    for i in range(len(blocklist)):
        if blocklist[i] == ip:
            return True                            # FIX D3: was  return False
    return False                                   # FIX D4: 'not found' only after the loop


def find_signature(log, pattern):
    """Brute-force string matching: every start index of `pattern` in `log`.

    Overlapping occurrences are reported.  An empty pattern returns [].
    """
    n, m = len(log), len(pattern)
    if m == 0:                                     # hardening (not one of D1-D9)
        return []
    hits = []
    for i in range(n - m + 1):                     # FIX D5: was  range(n - m)
        for j in range(m):
            if log[i + j] != pattern[j]:
                break
        else:                                      # FIX D6: was  if j == m - 1  (also true after a
            hits.append(i)                         #         mismatch on the LAST character)
    return hits


def closest_logins(events):
    """Brute-force closest pair of (x, y) login locations.

    Returns ((i, j), distance) with i < j, or (None, None) if fewer than 2 events.
    """
    min_dist = float("inf")                        # FIX D7: was  0
    pair = None
    for i in range(len(events)):
        for j in range(i + 1, len(events)):        # FIX D9: was  range(len(events))  (self + mirrored pairs)
            d = math.sqrt((events[i][0] - events[j][0]) ** 2 +
                          (events[i][1] - events[j][1]) ** 2)
            if d < min_dist:                       # FIX D8: was  d > min_dist
                min_dist = d
                pair = (i, j)
    if pair is None:
        return None, None
    return pair, min_dist
