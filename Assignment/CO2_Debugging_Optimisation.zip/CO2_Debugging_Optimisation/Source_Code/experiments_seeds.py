"""Supplementary: optimised closest_logins distance computations over 20 random seeds per batch size."""
import csv, os, random, statistics as stt
import optimised_module as opt
SUP = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "Supporting_Files")
rows = []
print(f"{'n':>6} {'brute n(n-1)/2':>15} {'min':>7} {'mean':>9} {'max':>8}  mean reduction")
for n in (1000, 2000, 4000, 6000, 8000):
    c = []
    for seed in range(20):
        rng = random.Random(1000 * n + seed)
        ev = [(rng.uniform(0, 1000), rng.uniform(0, 1000)) for _ in range(n)]
        st = {}; opt.closest_logins(ev, st); c.append(st["distance_computations"])
    b = n * (n - 1) // 2
    rows.append([n, b, min(c), round(stt.mean(c)), max(c), round(b / stt.mean(c))])
    print(f"{n:>6} {b:>15} {min(c):>7} {round(stt.mean(c)):>9} {max(c):>8}  x{round(b/stt.mean(c))}")
with open(os.path.join(SUP, "closest_pair_20_seeds.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(["n", "brute_force", "optimised_min", "optimised_mean", "optimised_max", "mean_reduction"]); w.writerows(rows)
