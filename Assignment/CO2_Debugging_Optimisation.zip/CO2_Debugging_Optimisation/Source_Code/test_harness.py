"""
Test harness for optimised_module.py (Parts b, c and e).

Runs (1) the issued test data, (2) every boundary case from Part (b),
(3) differential tests: random inputs checked against the CORRECTED module and
against independent reference implementations, proving the optimisations do not
change any output.   Exit status 0 = everything passed.
"""
import math
import random
import corrected_module as ref
import optimised_module as opt

passed = failed = 0


def check(name, actual, expected, verbose=True):
    global passed, failed
    ok = actual == expected
    passed += ok
    failed += (not ok)
    if verbose or not ok:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}")
        if not ok:
            print(f"        actual  : {actual!r}\n        expected: {expected!r}")


def section(t):
    print(f"\n--- {t} ---")


# ------------------------------------------------------------ issued test data
section("issued test data")
alerts = [("A1", 3), ("A2", 9), ("A3", 5), ("A4", 9), ("A5", 1)]
want = [("A2", 9), ("A4", 9), ("A3", 5), ("A1", 3), ("A5", 1)]
check("sort_alerts", opt.sort_alerts(list(alerts)), want)
check("insertion_sort_alerts", opt.insertion_sort_alerts(list(alerts)), want)
bl = ["10.0.0.5", "10.0.0.9", "172.16.4.2"]
idx = opt.build_blocklist(bl)
for q, w in (("10.0.0.9", True), ("10.0.0.5", True), ("8.8.8.8", False)):
    check(f"is_blocked({q})", opt.is_blocked(idx, q), w)
    check(f"is_blocked_sequential({q})", opt.is_blocked_sequential(bl, q), w)
check("find_signature", opt.find_signature("FAILFAIXFAIL", "FAIL"), [0, 8])
check("find_signature_native", opt.find_signature_native("FAILFAIXFAIL", "FAIL"), [0, 8])
ev = [(2, 3), (12, 30), (40, 50), (5, 1), (12, 10), (3, 4)]
check("closest_logins", opt.closest_logins(ev), ((0, 5), math.sqrt(2)))

# ------------------------------------------------------------------ boundaries
section("boundary: sort_alerts / insertion_sort_alerts")
for fn in (opt.sort_alerts, opt.insertion_sort_alerts):
    n = fn.__name__
    check(f"{n}: empty", fn([]), [])
    check(f"{n}: single", fn([("A", 4)]), [("A", 4)])
    check(f"{n}: all equal keeps arrival order",
          fn([("A", 5), ("B", 5), ("C", 5)]), [("A", 5), ("B", 5), ("C", 5)])
    check(f"{n}: already sorted", fn([("A", 9), ("B", 5), ("C", 1)]), [("A", 9), ("B", 5), ("C", 1)])
    check(f"{n}: reverse sorted", fn([("A", 1), ("B", 5), ("C", 9)]), [("C", 9), ("B", 5), ("A", 1)])
    check(f"{n}: stable with ties",
          fn([("a", 2), ("b", 7), ("c", 2), ("d", 7), ("e", 2)]),
          [("b", 7), ("d", 7), ("a", 2), ("c", 2), ("e", 2)])

section("boundary: is_blocked")
check("empty blocklist (index)", opt.is_blocked(opt.build_blocklist([]), "1.1.1.1"), False)
check("empty blocklist (sequential)", opt.is_blocked_sequential([], "1.1.1.1"), False)
check("first element", opt.is_blocked(idx, "10.0.0.5"), True)
check("last element", opt.is_blocked(idx, "172.16.4.2"), True)
check("partial string is not a match", opt.is_blocked(idx, "10.0.0"), False)
check("duplicate entries in blocklist", opt.is_blocked(opt.build_blocklist(["a", "a"]), "a"), True)

section("boundary: find_signature (both variants)")
for fn in (opt.find_signature, opt.find_signature_native):
    n = fn.__name__
    check(f"{n}: pattern at very end", fn("xxxxFAIL", "FAIL"), [4])
    check(f"{n}: pattern at start", fn("FAILxxxx", "FAIL"), [0])
    check(f"{n}: pattern longer than log", fn("FAI", "FAIL"), [])
    check(f"{n}: pattern one longer than log", fn("FAIL", "FAILX"), [])
    check(f"{n}: pattern == log", fn("FAIL", "FAIL"), [0])
    check(f"{n}: empty log", fn("", "FAIL"), [])
    check(f"{n}: empty pattern", fn("abc", ""), [])
    check(f"{n}: overlapping hits", fn("AAAA", "AA"), [0, 1, 2])
    check(f"{n}: near-miss on last char", fn("FAIX", "FAIL"), [])
    check(f"{n}: single char", fn("abcab", "a"), [0, 3])
    check(f"{n}: no occurrence", fn("abcdef", "xyz"), [])

section("boundary: closest_logins")
check("zero events", opt.closest_logins([]), (None, None))
check("one event", opt.closest_logins([(1, 1)]), (None, None))
check("two events", opt.closest_logins([(0, 0), (3, 4)]), ((0, 1), 5.0))
check("duplicate locations", opt.closest_logins([(1, 1), (9, 9), (1, 1)]), ((0, 2), 0.0))
check("tie -> first (i, j)", opt.closest_logins([(0, 0), (1, 0), (2, 0)]), ((0, 1), 1.0))
check("negative coordinates", opt.closest_logins([(-5, -5), (-4, -5), (10, 10)]), ((0, 1), 1.0))
check("all same x (sweep switches to y axis)",
      opt.closest_logins([(7, 0), (7, 50), (7, 53), (7, 100)]), ((1, 2), 3.0))
check("all points identical", opt.closest_logins([(4, 4)] * 5), ((0, 1), 0.0))
check("unsorted input keeps ORIGINAL indices",
      opt.closest_logins([(100, 100), (0, 0), (50, 50), (101, 100)]), ((0, 3), 1.0))

# ---------------------------------------------------------- differential tests
section("differential tests: optimised == corrected on random data")
rng = random.Random(2026)
N_CASES = 300

bad = 0
for _ in range(N_CASES):                                 # sort
    n = rng.randint(0, 60)
    data = [(f"A{i}", rng.randint(1, 5)) for i in range(n)]
    exp = ref.sort_alerts(list(data))
    ok = (opt.sort_alerts(list(data)) == exp and
          opt.insertion_sort_alerts(list(data)) == exp and
          exp == sorted(data, key=lambda a: -a[1]))       # independent oracle
    bad += not ok
check(f"sort_alerts x{N_CASES} random lists (many ties)", bad, 0)

bad = 0
for _ in range(N_CASES):                                 # blocklist
    pool = [f"10.0.{rng.randint(0, 3)}.{rng.randint(0, 9)}" for _ in range(rng.randint(0, 15))]
    index = opt.build_blocklist(pool)
    for _q in range(10):
        q = f"10.0.{rng.randint(0, 3)}.{rng.randint(0, 9)}"
        bad += not (opt.is_blocked(index, q) == ref.is_blocked(pool, q) == opt.is_blocked_sequential(pool, q))
check(f"is_blocked x{N_CASES * 10} random queries", bad, 0)

bad = 0
for _ in range(N_CASES):                                 # signature
    log = "".join(rng.choice("AB") for _ in range(rng.randint(0, 40)))
    pat = "".join(rng.choice("AB") for _ in range(rng.randint(0, 6)))
    exp = ref.find_signature(log, pat)
    oracle = [i for i in range(len(log) - len(pat) + 1) if pat and log.startswith(pat, i)]
    bad += not (opt.find_signature(log, pat) == exp == oracle == opt.find_signature_native(log, pat))
check(f"find_signature x{N_CASES} random logs (overlaps, ends)", bad, 0)

bad = 0
for _ in range(N_CASES):                                 # closest pair
    n = rng.randint(0, 40)
    span = rng.choice([3, 10, 1000])                     # small span => many ties/duplicates
    pts = [(rng.randint(0, span), rng.randint(0, span)) for _ in range(n)]
    bad += not (opt.closest_logins(pts) == ref.closest_logins(pts))
check(f"closest_logins x{N_CASES} random integer sets (ties incl.)", bad, 0)

bad = 0
for _ in range(100):                                     # float coordinates
    n = rng.randint(2, 60)
    pts = [(rng.uniform(0, 500), rng.uniform(0, 500)) for _ in range(n)]
    bad += not (opt.closest_logins(pts) == ref.closest_logins(pts))
check("closest_logins x100 random float sets", bad, 0)

section("operation counters")
st = {}
opt.closest_logins([(i, 0) for i in range(100)], st)
check("closest_logins counter present", "distance_computations" in st, True)
st = {}
opt.find_signature("FAILFAIXFAIL", "FAIL", st)
check("find_signature comparisons on issued data", st["comparisons"], 4 + 1 + 1 + 1 + 4 + 1 + 1 + 1 + 4)

print(f"\nRESULT: {passed} passed, {failed} failed")
raise SystemExit(1 if failed else 0)
