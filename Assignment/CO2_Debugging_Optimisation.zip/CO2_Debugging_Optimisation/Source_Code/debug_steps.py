"""
Part (b): systematic, one-defect-at-a-time debugging of the ORIGINAL code.

Each vN function below is the previous version with exactly ONE line changed
(marked  # FIX Dn).  After every fix the function is re-tested on the issued
test data, so the effect of each individual defect is visible.
"""
import math

alerts = [("A1", 3), ("A2", 9), ("A3", 5), ("A4", 9), ("A5", 1)]
blocklist = ["10.0.0.5", "10.0.0.9", "172.16.4.2"]
queries = ["10.0.0.9", "10.0.0.5", "8.8.8.8"]
log, pattern = "FAILFAIXFAIL", "FAIL"
events = [(2, 3), (12, 30), (40, 50), (5, 1), (12, 10), (3, 4)]


# ------------------------------------------------------------------ sort_alerts
def sort_v0(a):                      # original
    for i in range(1, len(a)):
        key = a[i]; j = i - 1
        while j > 0 and a[j][1] < key[1]:
            a[j + 1] = a[j]; j -= 1
        a[j] = key
    return a

def sort_v1(a):                      # D1: j > 0  ->  j >= 0
    for i in range(1, len(a)):
        key = a[i]; j = i - 1
        while j >= 0 and a[j][1] < key[1]:          # FIX D1
            a[j + 1] = a[j]; j -= 1
        a[j] = key
    return a

def sort_v2(a):                      # D2: a[j] = key  ->  a[j + 1] = key
    for i in range(1, len(a)):
        key = a[i]; j = i - 1
        while j >= 0 and a[j][1] < key[1]:
            a[j + 1] = a[j]; j -= 1
        a[j + 1] = key                              # FIX D2
    return a


def trace_insertion(fn_name, a, correct):
    """Print the step-by-step insertion trace (list state after each pass)."""
    a = list(a)
    print(f"  start            : {a}")
    for i in range(1, len(a)):
        key = a[i]; j = i - 1
        while (j >= 0 if correct else j > 0) and a[j][1] < key[1]:
            a[j + 1] = a[j]; j -= 1
        a[j + 1 if correct else j] = key
        print(f"  pass i={i} key={key}: {a}")
    return a


# ------------------------------------------------------------------ is_blocked
def blocked_v0(bl, ip):              # original
    for i in range(len(bl)):
        if bl[i] == ip:
            return False
        else:
            return False

def blocked_v1(bl, ip):              # D3: match must return True
    for i in range(len(bl)):
        if bl[i] == ip:
            return True                              # FIX D3
        else:
            return False

def blocked_v2(bl, ip):              # D4: 'not found' only AFTER the whole loop
    for i in range(len(bl)):
        if bl[i] == ip:
            return True
    return False                                     # FIX D4


# -------------------------------------------------------------- find_signature
def sig_v0(log, p):                  # original
    n, m = len(log), len(p); hits = []
    for i in range(n - m):
        for j in range(m):
            if log[i + j] != p[j]:
                break
        if j == m - 1:
            hits.append(i)
    return hits

def sig_v1(log, p):                  # D5: window count is n-m+1
    n, m = len(log), len(p); hits = []
    for i in range(n - m + 1):                       # FIX D5
        for j in range(m):
            if log[i + j] != p[j]:
                break
        if j == m - 1:
            hits.append(i)
    return hits

def sig_v2(log, p):                  # D6: record a hit only if inner loop did NOT break
    n, m = len(log), len(p); hits = []
    for i in range(n - m + 1):
        for j in range(m):
            if log[i + j] != p[j]:
                break
        else:                                        # FIX D6 (for-else)
            hits.append(i)
    return hits


# ------------------------------------------------------------- closest_logins
def closest_v0(ev):                  # original
    min_dist = 0; pair = None
    for i in range(len(ev)):
        for j in range(len(ev)):
            d = math.sqrt((ev[i][0]-ev[j][0])**2 + (ev[i][1]-ev[j][1])**2)
            if d > min_dist:
                min_dist = d; pair = (i, j)
    return pair, min_dist

def closest_v1(ev):                  # D7: start from +infinity (not 0)
    min_dist = float("inf"); pair = None             # FIX D7
    for i in range(len(ev)):
        for j in range(len(ev)):
            d = math.sqrt((ev[i][0]-ev[j][0])**2 + (ev[i][1]-ev[j][1])**2)
            if d > min_dist:
                min_dist = d; pair = (i, j)
    return pair, min_dist

def closest_v2(ev):                  # D8: keep the SMALLER distance
    min_dist = float("inf"); pair = None
    for i in range(len(ev)):
        for j in range(len(ev)):
            d = math.sqrt((ev[i][0]-ev[j][0])**2 + (ev[i][1]-ev[j][1])**2)
            if d < min_dist:                         # FIX D8
                min_dist = d; pair = (i, j)
    return pair, min_dist

def closest_v3(ev):                  # D9: j > i only (no self / mirrored pairs)
    min_dist = float("inf"); pair = None
    for i in range(len(ev)):
        for j in range(i + 1, len(ev)):              # FIX D9
            d = math.sqrt((ev[i][0]-ev[j][0])**2 + (ev[i][1]-ev[j][1])**2)
            if d < min_dist:
                min_dist = d; pair = (i, j)
    return pair, min_dist


def hdr(t):
    print("\n" + "=" * 74 + f"\n{t}\n" + "=" * 74)


if __name__ == "__main__":
    hdr("sort_alerts : trace of ORIGINAL insertion sort")
    trace_insertion("orig", alerts, correct=False)
    hdr("sort_alerts : re-test after each fix")
    print("  v0 original :", sort_v0(list(alerts)))
    print("  v1 +D1      :", sort_v1(list(alerts)))
    print("  v2 +D2      :", sort_v2(list(alerts)))
    hdr("sort_alerts : trace of CORRECTED insertion sort")
    trace_insertion("fixed", alerts, correct=True)

    hdr("is_blocked : re-test after each fix   (expected True, True, False)")
    for name, f in (("v0 original", blocked_v0), ("v1 +D3", blocked_v1), ("v2 +D4", blocked_v2)):
        print(f"  {name:<12}:", [f(blocklist, q) for q in queries])

    hdr("find_signature : re-test after each fix   (expected [0, 8])")
    for name, f in (("v0 original", sig_v0), ("v1 +D5", sig_v1), ("v2 +D6", sig_v2)):
        print(f"  {name:<12}:", f(log, pattern))
    print("\n  Alignment table for corrected scan (log='FAILFAIXFAIL', pattern='FAIL')")
    print("   i | window | compared (j: log char vs pattern char)      | result")
    print("  ---+--------+----------------------------------------------+--------")
    n, m = len(log), len(pattern)
    for i in range(n - m + 1):
        steps = []; ok = True
        for j in range(m):
            eq = log[i + j] == pattern[j]
            steps.append(f"{j}:{log[i+j]}{'=' if eq else '!'}{pattern[j]}")
            if not eq:
                ok = False; break
        print(f"  {i:>2} | {log[i:i+m]:<6} | {' '.join(steps):<44} | {'HIT' if ok else 'no'}")

    hdr("closest_logins : re-test after each fix   (expected ((0, 5), 1.4142135623730951))")
    for name, f in (("v0 original", closest_v0), ("v1 +D7", closest_v1),
                    ("v2 +D8", closest_v2), ("v3 +D9", closest_v3)):
        print(f"  {name:<12}:", f(events))
