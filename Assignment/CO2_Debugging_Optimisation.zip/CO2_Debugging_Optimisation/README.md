# CO2 – Debugging and Optimisation Task: SentinelOps SOC Alert-Triage Module

Course **CSA06 – Design and Analysis of Algorithms** · Assessment **CO2** (Brute Force: sorting, searching, closest pair)

The module sorts alerts by severity, checks IPs against a blocklist, finds attack signatures in log lines and
finds the closest pair of login locations. The issued code contained **nine defects**; this repository contains
the defect analysis, the step-by-step fixes, the optimised module, the test harness and the measurements.

## Repository layout

```
CO2_Debugging_Optimisation/
├── Pseudocode/            corrected + optimised pseudocode for the four functions
├── Source_Code/
│   ├── original_module.py     buggy module exactly as issued
│   ├── run_original.py        Part (a): reproduce the failures
│   ├── debug_steps.py         Part (b): one fix at a time, traces, re-tests
│   ├── corrected_module.py    the nine defects fixed (minimal edits, marked FIX D1..D9)
│   ├── test_corrected.py      boundary tests for the corrected module
│   ├── optimised_module.py    final optimised module (docstrings + comments)
│   ├── test_harness.py        67 checks incl. differential tests vs the corrected module
│   ├── experiments.py         Part (d): operation counts, timings, charts
│   └── experiments_seeds.py   20-seed closest-pair measurement
├── Report/
│   ├── CO2_Debugging_Optimisation_Report.docx   full report (Parts a–e)
│   ├── build_report.js        regenerates the report from the result files
│   └── figures/               charts and code / output captures
├── Supporting_Files/      CSV tables, JSON results, execution logs, helper scripts
└── README.md
```

## Defects found (original_module.py)

| ID | Function | Faulty line | Error |
|----|----------|-------------|-------|
| D1 | sort_alerts | `while j > 0 and ...` | bound should be `j >= 0` (index 0 never shifted) |
| D2 | sort_alerts | `alerts[j] = key` | must insert at `j + 1` (overwrites live alerts) |
| D3 | is_blocked | `return False` on a match | must return `True` |
| D4 | is_blocked | `else: return False` inside the loop | "not found" may only be returned after the loop |
| D5 | find_signature | `range(n - m)` | must be `range(n - m + 1)` (last window missed) |
| D6 | find_signature | `if j == m - 1` | true after a mismatch on the last character → false hits; use for-else |
| D7 | closest_logins | `min_dist = 0` | must start at +infinity |
| D8 | closest_logins | `if d > min_dist` | must be `<` (it found the farthest pair) |
| D9 | closest_logins | `for j in range(len(events))` | must be `range(i + 1, n)` (self and mirrored pairs) |

## Run

Python 3.9+ (3.13 used), standard library only; `matplotlib` is needed only for the charts in `experiments.py`.

```bash
cd Source_Code
python3 run_original.py        # reproduce failures (Part a)
python3 debug_steps.py         # debugging steps and traces (Part b)
python3 test_corrected.py      # boundary tests, corrected module
python3 test_harness.py        # full harness, exit status 0 = all 67 checks pass
python3 experiments.py         # measurements + charts (~2 minutes; writes ../Supporting_Files, ../Report/figures)
python3 experiments_seeds.py   # 20-seed closest-pair table
```

## Optimisations (outputs unchanged – verified by differential tests)

| Function | Technique | Effect |
|----------|-----------|--------|
| sort_alerts | stable adaptive sort (Timsort) instead of insertion sort | O(n log n) worst case, O(n) nearly sorted; 50,000 random alerts: 74.6 s → 0.0056 s |
| is_blocked | hash index built once | O(q·m) → O(m + q); 50,000 queries vs 2,000 entries: 2.75 s → 0.0047 s |
| find_signature | for-else, exact n−m+1 windows, early exit, no extra per-window test | no redundant comparisons; native `str.find` variant up to ~350× faster in wall-clock |
| closest_logins | j > i, squared distances (one sqrt), axis sort + pruning | n = 8,000: 31,996,000 → 8,674 distance computations (single run; mean 12,683 over 20 seeds) |

Worst case of the pruned closest pair is still O(n²) (e.g. half the points on one line); see the report, Section 6.

## Notes

* Operation counts are deterministic (seeded). Run times are single runs on one machine and will differ.
* The images of source code and terminal output in `Report/figures/` are rendered from the actual files and logs
  (`Supporting_Files/make_screens.py`); replace them with your own screenshots if your course requires literal screen captures.
