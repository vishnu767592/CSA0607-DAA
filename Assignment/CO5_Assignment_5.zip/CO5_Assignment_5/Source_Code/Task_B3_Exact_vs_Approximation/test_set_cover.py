import random, unittest
from set_cover import *


class T(unittest.TestCase):
    def test_exact_methods_agree_and_greedy_is_valid(self):
        for seed in range(400):
            n, m = 6 + seed % 6, 5 + seed % 5
            cs = random_instance(n, m, 0.3, seed)
            full = (1 << n) - 1
            ex, _ = exact_bruteforce(cs, n)
            bb, _ = exact_branch_and_bound(cs, n)
            gr, _ = greedy_cover(cs, n)
            self.assertEqual(len(ex), len(bb))
            self.assertLessEqual(len(ex), len(gr))                 # greedy can never beat the optimum
            u = 0
            for i in gr: u |= cs[i]
            self.assertEqual(u, full)                              # greedy cover is a feasible cover
            import math
            self.assertLessEqual(len(gr), len(ex) * (math.log(n) + 1) + 1e-9)   # H(n) guarantee

    def test_counterexample(self):
        cs = [make_mask([4,5,6,7,8,9,10,11]), make_mask(range(1,8)), make_mask(range(8,15))]
        self.assertEqual(len(greedy_cover(cs, 14)[0]), 3)
        self.assertEqual(len(exact_bruteforce(cs, 14)[0]), 2)

    def test_uncoverable(self):
        self.assertIsNone(greedy_cover([make_mask([1])], 2)[0])
        self.assertIsNone(exact_bruteforce([make_mask([1])], 2)[0])


if __name__ == "__main__":
    unittest.main(verbosity=2)
