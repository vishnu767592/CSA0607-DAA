"""
Task B3 - Emergency-service Set Cover: exact vs greedy approximation.
Zones Z1..Zn are bits 0..n-1; each candidate centre is an integer bitmask of the zones it can serve.
"""
from itertools import combinations
import random


def popcount(x):
    return bin(x).count("1")


def make_mask(zones):                      # zones given 1-based, e.g. [1,2,5]
    mask = 0
    for z in zones:
        mask |= 1 << (z - 1)
    return mask


def coverable(centres, n):
    full = (1 << n) - 1
    u = 0
    for c in centres:
        u |= c
    return u == full


# --------------------------------------------------------------------------------------------
# SOLUTION A (exact) : iterative-deepening exhaustive search over combinations of size k = 1,2,3,...
# effort = number of combinations whose union was tested ("search states")
# --------------------------------------------------------------------------------------------
def exact_bruteforce(centres, n):
    full = (1 << n) - 1
    examined = 0
    for k in range(1, len(centres) + 1):
        for combo in combinations(range(len(centres)), k):
            examined += 1
            u = 0
            for i in combo:
                u |= centres[i]
            if u == full:
                return list(combo), examined          # first size k that works is optimal
    return None, examined


# --------------------------------------------------------------------------------------------
# Exact branch-and-bound (independent second exact method, used only to cross-check the first one
# and to show that smarter exact search still grows exponentially). effort = search nodes.
# Branch on the uncovered zone with the fewest candidate centres; bound: |chosen| + 1 >= best.
# --------------------------------------------------------------------------------------------
def exact_branch_and_bound(centres, n, initial_best=None):
    full = (1 << n) - 1
    covering = [[i for i, c in enumerate(centres) if c >> z & 1] for z in range(n)]
    best = [initial_best[:] if initial_best else list(range(len(centres)))]
    nodes = [0]

    def rec(chosen, covered):
        nodes[0] += 1
        if covered == full:
            if len(chosen) < len(best[0]):
                best[0] = chosen[:]
            return
        if len(chosen) + 1 >= len(best[0]):
            return                                           # cannot beat current best -> prune
        unc = [z for z in range(n) if not covered >> z & 1]
        z = min(unc, key=lambda q: len(covering[q]))
        for i in covering[z]:
            chosen.append(i)
            rec(chosen, covered | centres[i])
            chosen.pop()

    rec([], 0)
    return best[0], nodes[0]


# --------------------------------------------------------------------------------------------
# SOLUTION B (approximate) : greedy - repeatedly take the centre covering most UNCOVERED zones.
# effort = number of (centre, uncovered-set) coverage evaluations
# --------------------------------------------------------------------------------------------
def greedy_cover(centres, n, trace=None):
    uncovered = (1 << n) - 1
    chosen, evals, used = [], 0, set()
    while uncovered:
        best_i, best_gain = -1, 0
        for i, c in enumerate(centres):
            if i in used:
                continue
            evals += 1
            gain = popcount(c & uncovered)
            if gain > best_gain:                              # strict '>' -> ties go to lowest index
                best_i, best_gain = i, gain
        if best_i < 0:
            return None, evals                                # some zone cannot be covered at all
        used.add(best_i)
        chosen.append(best_i)
        if trace is not None:
            trace.append((best_i, best_gain, uncovered))
        uncovered &= ~centres[best_i]
    return chosen, evals


def random_instance(n, m, p, seed):
    """n zones, m centres, each centre covers each zone with probability p; every zone forced coverable."""
    rng = random.Random(seed)
    centres = [sum(1 << z for z in range(n) if rng.random() < p) for _ in range(m)]
    for z in range(n):                                        # patch so the instance is feasible
        if not any(c >> z & 1 for c in centres):
            centres[rng.randrange(m)] |= 1 << z
    return centres
