import time
from set_cover import *


def zones_of(mask, n):
    return [f"Z{z+1}" for z in range(n) if mask >> z & 1]


def b31():
    print("=" * 100)
    print("B3.1  CORRECTNESS ON SMALL INSTANCES (instances fixed BEFORE running; none were filtered)")
    print("=" * 100)
    insts = []
    # Instance 1 : hand-made city, 8 zones, 5 centres
    insts.append(("1 (hand-made city, 8 zones, 5 centres)", 8, [make_mask(s) for s in
                  ([1, 2, 3], [3, 4, 5], [5, 6, 7], [7, 8, 1], [2, 4, 6, 8])]))
    # Instance 2/3 : random, seeds fixed in advance
    insts.append(("2 (random seed 11, 10 zones, 7 centres)", 10, random_instance(10, 7, 0.30, 11)))
    insts.append(("3 (random seed 22, 12 zones, 9 centres)", 12, random_instance(12, 9, 0.25, 22)))
    print(f"{'Instance':<42}{'Exact':>6}{'Greedy':>8}{'Same?':>7}   exact centres / greedy centres")
    for name, n, cs in insts:
        ex, combos = exact_bruteforce(cs, n)
        bb, nodes = exact_branch_and_bound(cs, n)
        gr, ev = greedy_cover(cs, n)
        assert len(ex) == len(bb), "two exact methods disagree"
        print(f"{name:<42}{len(ex):>6}{len(gr):>8}{('Yes' if len(ex)==len(gr) else 'NO'):>7}   "
              f"C{[i+1 for i in ex]} / C{[i+1 for i in gr]}   (exact combos={combos}, B&B nodes={nodes}, greedy evals={ev})")
    print()
    for name, n, cs in insts[:1]:
        for i, c in enumerate(cs):
            print(f"   instance 1: C{i+1} covers {zones_of(c, n)}")
    print()
    # bulk statistic
    diff, worst, total = 0, 1.0, 1500
    for seed in range(total):
        n = 8 + seed % 5
        m = 6 + seed % 5
        cs = random_instance(n, m, 0.3, 1000 + seed)
        ex, _ = exact_bruteforce(cs, n)
        gr, _ = greedy_cover(cs, n)
        if len(gr) != len(ex):
            diff += 1
        worst = max(worst, len(gr) / len(ex))
    print(f"Bulk check on {total} random small instances: greedy differed from optimum in {diff} ({100*diff/total:.1f}%), worst ratio {worst:.2f}")
    print()


def b32():
    print("=" * 100)
    print("B3.2  COUNTEREXAMPLE   (14 zones, 3 centres)")
    print("=" * 100)
    n = 14
    A = make_mask(range(1, 8))                    # optimal centre A : Z1..Z7
    B = make_mask(range(8, 15))                   # optimal centre B : Z8..Z14
    Cc = make_mask([4, 5, 6, 7, 8, 9, 10, 11])    # trap centre C : middle 4 of each half
    cs = [Cc, A, B]
    names = ["C (trap)", "A", "B"]
    # listed with the trap FIRST so the instance does not rely on tie-breaking at all (gain 8 > 7)
    for nm, c in zip(names, cs):
        print(f"   centre {nm:<9} covers {zones_of(c, n)}  ({popcount(c)} zones)")
    tr = []
    gr, ev = greedy_cover(cs, n, trace=tr)
    for step, (i, gain, unc) in enumerate(tr, 1):
        print(f"   greedy step {step}: uncovered={zones_of(unc, n)} -> picks {names[i]} (gain {gain})")
    ex, combos = exact_bruteforce(cs, n)
    print(f"   Greedy size = {len(gr)} {[names[i] for i in gr]}   Optimal size = {len(ex)} {[names[i] for i in ex]}   -> {len(gr)} > {len(ex)}")
    print()


def b33():
    print("=" * 100)
    print("B3.3  SCALABILITY (random instances, each centre covers a zone with prob 0.12, seeds fixed)")
    print("=" * 100)
    hdr = f"{'Zones':>6}{'Centres':>9}{'Exact: combos':>16}{'Exact B&B nodes':>17}{'Greedy evals':>14}{'Exact cover':>13}{'Greedy cover':>14}{'Exact ms':>10}{'Greedy ms':>11}"
    print(hdr)
    for n, m in [(10, 8), (14, 12), (18, 16), (22, 20), (26, 24), (30, 26), (34, 28)]:
        cs = random_instance(n, m, 0.12, 7 + n)
        t = time.perf_counter(); ex, combos = exact_bruteforce(cs, n); te = (time.perf_counter() - t) * 1000
        bb, nodes = exact_branch_and_bound(cs, n)
        t = time.perf_counter(); gr, ev = greedy_cover(cs, n); tg = (time.perf_counter() - t) * 1000
        assert len(ex) == len(bb)
        print(f"{n:>6}{m:>9}{combos:>16,}{nodes:>17,}{ev:>14,}{len(ex):>13}{len(gr):>14}{te:>10.1f}{tg:>11.3f}")
    print()
    print("Greedy only (exact brute force is impractical here); B&B shown for reference:")
    print(f"{'Zones':>6}{'Centres':>9}{'Greedy evals':>14}{'Greedy cover':>14}{'B&B optimum':>13}{'B&B nodes':>12}")
    for n, m in [(100, 60), (400, 200), (1000, 500), (2000, 1000)]:
        cs = random_instance(n, m, 0.05, 5 + n)
        gr, ev = greedy_cover(cs, n)
        if n <= 100:
            bb, nodes = exact_branch_and_bound(cs, n, initial_best=gr)
            print(f"{n:>6}{m:>9}{ev:>14,}{len(gr):>14}{len(bb):>13}{nodes:>12,}")
        else:
            print(f"{n:>6}{m:>9}{ev:>14,}{len(gr):>14}{'(not run)':>13}")
    print("Number of subsets brute force would have to inspect to reach size k = 10 among m centres:")
    from math import comb
    for m in (20, 50, 100, 200):
        print(f"   m={m:>3}: C(m,10) = {comb(m,10):,}")


if __name__ == "__main__":
    b31(); b32(); b33()
