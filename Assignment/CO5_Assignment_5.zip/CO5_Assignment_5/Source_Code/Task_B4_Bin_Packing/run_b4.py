import random, time, itertools
from bin_packing import *


def b41():
    print("=" * 100)
    print("B4.1  FIRST-FIT DECREASING on a 20-workload batch (C = 100)")
    print("=" * 100)
    rng = random.Random(42)
    demands = [rng.randint(8, 70) for _ in range(20)]
    print("Workload demands (input order):", demands)
    servers, _ = first_fit_decreasing(demands, 100)
    report(servers, demands, 100, "FFD result:")
    assert sorted(i for s in servers for i in s) == list(range(20))
    assert all(sum(demands[i] for i in s) <= 100 for s in servers)
    print("  [checked: every workload assigned exactly once, no server over capacity]")
    print()


def b42():
    print("=" * 100)
    print("B4.2  CHALLENGE INPUT  - FFD uses more servers than necessary")
    print("=" * 100)
    # Exhaustive search for the SMALLEST instance (fewest items, then smallest C) where FFD > optimum
    found = None
    for C in range(6, 31):
        for n in range(4, 8):
            for combo in itertools.combinations_with_replacement(range(1, C + 1), n):
                d = list(combo)
                if sum(d) > 3 * C + C:   # keep tiny
                    continue
                f = len(first_fit_decreasing(d, C)[0])
                if f > lower_bound(d, C):
                    o, _ = exact_min_bins(d, C)
                    if f > o:
                        found = (C, d, f, o)
                        break
            if found:
                break
        if found:
            break
    C, d, f, o = found
    print(f"Smallest instance found by exhaustive search:  C = {C}, workloads = {sorted(d, reverse=True)}")
    sv, _ = first_fit_decreasing(d, C)
    report(sv, d, C, f"  FFD uses {f} servers:")
    print(f"  Exact optimum = {o} servers")
    # reconstruct an optimal packing by brute force for display
    def find_opt(items, C, k):
        items = sorted(items, reverse=True)
        bins = [[] for _ in range(k)]
        def rec(i):
            if i == len(items):
                return True
            seen = set()
            for b in bins:
                r = C - sum(b)
                if r >= items[i] and r not in seen:
                    seen.add(r); b.append(items[i])
                    if rec(i + 1): return True
                    b.pop()
            return False
        return bins if rec(0) else None
    opt = find_opt(d, C, o)
    print("  An optimal packing:", [(b, sum(b)) for b in opt])
    print("  Scaled to a realistic capacity: multiply every number by 14 -> C = 98, workloads [42, 42, 28, 28, 28, 28]:")
    sc = [x * 14 for x in d]
    print(f"     FFD servers = {len(first_fit_decreasing(sc, C*14)[0])}, exact optimum = {exact_min_bins(sc, C*14)[0]}")
    print(f"  FFD: {f} > OPT: {o}  -> heuristic is NOT optimal (still within the 11/9*OPT + 6/9 guarantee)")
    print()
    # statistics on random small instances
    rng = random.Random(5)
    worse = 0; tot = 2000; worst = 1.0
    for _ in range(tot):
        C = 100
        d = [rng.randint(10, 60) for _ in range(rng.randint(8, 14))]
        f = len(first_fit_decreasing(d, C)[0]); o, _ = exact_min_bins(d, C)
        if f > o: worse += 1
        worst = max(worst, f / o)
    print(f"  Random check ({tot} instances, 8-14 workloads, C=100): FFD > OPT in {worse} ({100*worse/tot:.1f}%), worst ratio FFD/OPT = {worst:.2f}")
    print()


def b43():
    print("=" * 100)
    print("B4.3  EVIDENCE FOR THE DECISION NOTE")
    print("=" * 100)
    print("(a) Exact search effort grows explosively (branch & bound nodes), FFD effort stays tiny")
    print(f"{'n':>4}{'Exact nodes':>14}{'Exact OPT':>19}{'FFD bins':>10}{'FFD tree visits':>17}{'LB':>8}")
    rng = random.Random(9)
    for n in (8, 12, 16, 20, 24, 28):
        d = [rng.randint(25, 48) for _ in range(n)]
        o, nodes = exact_min_bins(d, 100, node_limit=3_000_000)
        s, v = first_fit_decreasing(d, 100)
        ostr = str(o) if o is not None else f">={lower_bound(d,100)} (gave up)"
        print(f"{n:>4}{nodes:>14,}{ostr:>19}{len(s):>10}{v:>17,}{lower_bound(d,100):>8}")
    print()
    print("(b) Production scale (C = 1000, demands uniform 50..600)  -  no exact solver is run here")
    print(f"{'Workloads':>10}{'LowerBound':>12}{'FFD bins':>10}{'FFD/LB':>8}{'FF bins':>9}{'FF/LB':>8}{'FFD ms':>9}{'FF ms':>8}{'tree visits':>13}")
    rng = random.Random(2026)
    for n in (1_000, 5_000, 20_000, 100_000):
        d = [rng.randint(50, 600) for _ in range(n)]
        lb = lower_bound(d, 1000)
        t = time.perf_counter(); s1, v1 = first_fit_decreasing(d, 1000); t1 = (time.perf_counter() - t) * 1000
        t = time.perf_counter(); s2, v2 = first_fit(d, 1000); t2 = (time.perf_counter() - t) * 1000
        print(f"{n:>10,}{lb:>12,}{len(s1):>10,}{len(s1)/lb:>8.4f}{len(s2):>9,}{len(s2)/lb:>8.4f}{t1:>9.1f}{t2:>8.1f}{v1:>13,}")
    print()
    print("(c) Harder mix: many items just above/below C/3 and C/2 (C = 1000, 5,000 workloads)")
    rng = random.Random(77)
    d = [rng.choice([rng.randint(330, 345), rng.randint(500, 520), rng.randint(150, 250)]) for _ in range(5000)]
    lb = lower_bound(d, 1000); s, _ = first_fit_decreasing(d, 1000); s2, _ = first_fit(d, 1000)
    print(f"   lower bound={lb}  FFD={len(s)} ({len(s)/lb:.4f} x LB)  FF={len(s2)} ({len(s2)/lb:.4f} x LB)")


if __name__ == "__main__":
    b41(); b42(); b43()
