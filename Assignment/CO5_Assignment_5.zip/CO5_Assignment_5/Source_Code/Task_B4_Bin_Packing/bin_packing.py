"""
Task B4 - Bin packing (cloud workloads -> identical servers of capacity C).

Strategy chosen : FIRST-FIT DECREASING (FFD)
   Placement rule : sort workloads by demand, largest first; put each workload on the LOWEST-numbered
                    server that still has enough remaining capacity; open a new server only if none fits.
   Also provided  : FIRST-FIT (FF, no sorting) - the ONLINE variant for workloads that arrive one at a time.
Both use a segment tree (max remaining capacity per server) so each placement costs O(log n),
giving O(n log n) overall instead of O(n * servers).
"""
import itertools
from math import ceil


class FirstFitTree:
    """Segment tree over server slots storing max remaining capacity; finds leftmost slot with room."""
    def __init__(self, max_bins, capacity):
        self.size = 1
        while self.size < max_bins:
            self.size *= 2
        self.tree = [0] * (2 * self.size)
        self.cap = capacity
        self.used = 0                       # number of opened servers
        self.visits = 0                     # operation counter: tree nodes inspected

    def _update(self, i, val):
        i += self.size
        self.tree[i] = val
        i //= 2
        while i:
            self.tree[i] = max(self.tree[2 * i], self.tree[2 * i + 1])
            i //= 2

    def place(self, demand):
        """Return index of server used (opening a new one if needed)."""
        if self.tree[1] >= demand and self.used > 0:
            i = 1
            while i < self.size:
                self.visits += 1
                i = 2 * i if self.tree[2 * i] >= demand else 2 * i + 1
            slot = i - self.size
        else:
            slot = self.used
            self.used += 1
            self._update(slot, self.cap)
        self._update(slot, self.tree[slot + self.size] - demand)
        return slot


def validate_inputs(demands, C):
    if C <= 0:
        raise ValueError("capacity must be positive")
    for d in demands:
        if not (0 < d <= C):
            raise ValueError(f"workload demand {d} must satisfy 0 < d <= C={C}")


def _pack(order, demands, C):
    tree = FirstFitTree(max(1, len(demands)), C)
    servers = []
    for idx in order:
        s = tree.place(demands[idx])
        if s == len(servers):
            servers.append([])
        servers[s].append(idx)
    return servers, tree.visits


def first_fit_decreasing(demands, C):
    validate_inputs(demands, C)
    order = sorted(range(len(demands)), key=lambda i: (-demands[i], i))
    return _pack(order, demands, C)


def first_fit(demands, C):
    validate_inputs(demands, C)
    return _pack(range(len(demands)), demands, C)


def lower_bound(demands, C):
    return ceil(sum(demands) / C) if demands else 0


def exact_min_bins(demands, C, node_limit=5_000_000):
    """Exact optimum by depth-first branch & bound (small n only). Returns (opt, nodes) or (None, nodes) if limit hit."""
    items = sorted(demands, reverse=True)
    n = len(items)
    best = [len(first_fit_decreasing(demands, C)[0])]      # FFD gives the initial upper bound
    lb = lower_bound(demands, C)
    nodes = [0]
    bins = []

    def rec(i):
        nodes[0] += 1
        if nodes[0] > node_limit or best[0] == lb:
            return
        if i == n:
            best[0] = min(best[0], len(bins))
            return
        seen = set()
        for b in range(len(bins)):
            if bins[b] >= items[i] and bins[b] not in seen:     # symmetry: equal residuals are equivalent
                seen.add(bins[b])
                bins[b] -= items[i]
                rec(i + 1)
                bins[b] += items[i]
        if len(bins) + 1 < best[0]:
            bins.append(C - items[i])
            rec(i + 1)
            bins.pop()

    rec(0)
    return (best[0] if nodes[0] <= node_limit else None), nodes[0]


def report(servers, demands, C, title):
    print(title)
    print(f"  Servers used: {len(servers)}   (capacity C = {C}, total demand = {sum(demands)}, lower bound = {lower_bound(demands, C)})")
    for k, s in enumerate(servers, 1):
        load = sum(demands[i] for i in s)
        print(f"  Server {k:>2}: workloads {[demands[i] for i in s]}  load={load:>4}  remaining={C-load:>4}")
