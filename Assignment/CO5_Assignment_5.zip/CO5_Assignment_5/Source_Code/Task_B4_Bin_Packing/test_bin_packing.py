import random, unittest
from bin_packing import *


class T(unittest.TestCase):
    def check(self, d, C, servers):
        self.assertEqual(sorted(i for s in servers for i in s), list(range(len(d))))
        for s in servers:
            self.assertLessEqual(sum(d[i] for i in s), C)

    def test_feasible_and_bounded(self):
        rng = random.Random(1)
        for _ in range(300):
            C = rng.randint(10, 100)
            d = [rng.randint(1, C) for _ in range(rng.randint(1, 40))]
            for f in (first_fit_decreasing, first_fit):
                s, _ = f(d, C)
                self.check(d, C, s)
                self.assertGreaterEqual(len(s), lower_bound(d, C))

    def test_ffd_guarantee_vs_exact(self):
        rng = random.Random(3)
        for _ in range(300):
            d = [rng.randint(10, 60) for _ in range(rng.randint(3, 11))]
            o, _ = exact_min_bins(d, 100)
            f = len(first_fit_decreasing(d, 100)[0])
            self.assertGreaterEqual(f, o)
            self.assertLessEqual(f, 11 / 9 * o + 6 / 9 + 1e-9)

    def test_edge_cases(self):
        self.assertEqual(first_fit_decreasing([], 10)[0], [])
        self.assertEqual(len(first_fit_decreasing([10, 10], 10)[0]), 2)     # exact fits, no overflow
        with self.assertRaises(ValueError): first_fit_decreasing([11], 10)
        with self.assertRaises(ValueError): first_fit_decreasing([0], 10)

    def test_known_gap(self):
        self.assertEqual(len(first_fit_decreasing([3, 3, 2, 2, 2, 2], 7)[0]), 3)
        self.assertEqual(exact_min_bins([3, 3, 2, 2, 2, 2], 7)[0], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
