"""
Task B2 - Same size, very different search.  Re-uses the B1 solver unchanged.

Both graphs: n = 12 services, m = 3 server groups, exactly 8 conflict edges.

Graph A (easy, 3-colourable): 4 disjoint conflict pairs + one conflict triangle at the end.
Graph B (hard, NOT 3-colourable): the SAME number of edges, but 6 of them form a K4 hidden in the LAST 4
         input positions; the first 8 services are almost unconstrained (only 2 conflicts).
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "Task_B1_Graph_Colouring"))
from graph_colouring import colour_graph, is_valid_colouring


def graph_A(p=8):
    """p-vertex prefix of independent conflict pairs, then a triangle on the last 3 vertices (+1 pendant) -> n = p + 4"""
    n = p + 4
    edges = [(0, 1), (2, 3), (4, 5), (6, 7)][: max(0, min(4, p // 2))]
    edges += [(p, p + 1), (p + 1, p + 2), (p, p + 2), (p - 1, p + 3)] if p >= 1 else []
    # triangle (p,p+1,p+2) + pendant edge: 3 + 1 = 4 edges ; plus 4 pairs = 8 edges when p = 8
    return n, edges


def graph_B(p=8):
    """p-vertex nearly-free prefix (2 conflicts) followed by a K4 on the last 4 vertices -> n = p + 4"""
    n = p + 4
    edges = [(0, 1), (2, 3)]
    k4 = range(p, p + 4)
    edges += [(a, b) for a in k4 for b in k4 if a < b]
    return n, edges


def show(name, n, e, m):
    print(f"{name}: n={n}, edges={len(e)}, m={m}")
    print(f"   edges = {e}")


def main():
    m = 3
    nA, eA = graph_A(8)
    nB, eB = graph_B(8)
    assert nA == nB == 12 and len(eA) == len(eB) == 8
    print("=" * 100)
    print("B2  GRAPH A vs GRAPH B   (same n = 12, same m = 3, same number of edges = 8)")
    print("=" * 100)
    show("Graph A", nA, eA, m)
    show("Graph B", nB, eB, m)
    print()
    print(f"{'Graph':<10}{'Version':<10}{'Result':<8}{'Nodes':>9}{'Candidates':>12}{'Rejected':>10}{'Backtracks':>12}{'MaxDepth':>10}")
    for name, n, e in (("A", nA, eA), ("B", nB, eB)):
        for order, v in (("input", "V1"), ("mrv", "V2")):
            ok, col, st = colour_graph(n, e, m, order)
            if ok:
                assert is_valid_colouring(n, e, m, col)
            print(f"{name:<10}{v:<10}{('SAT' if ok else 'UNSAT'):<8}{st.nodes:>9}{st.candidates:>12}{st.rejected:>10}{st.backtracks:>12}{st.max_depth:>10}")
    okA, colA, _ = colour_graph(nA, eA, m, "input")
    print("\nGraph A colouring found:", colA)

    # Where do the failures occur in Graph B (input order)? histogram of depth at which dead ends happen
    from collections import Counter
    dead = Counter()
    lines = []
    colour_graph(nB, eB, m, "input", trace=lines.append)
    for ln in lines:
        if "dead end" in ln:
            depth = (len(ln) - len(ln.lstrip(" "))) // 2 - 1   # trace: 2 spaces per level, dead-end line is indented one extra level
            dead[depth] += 1
    print("\nGraph B (V1): failed search nodes per depth (depth = services already assigned). The real contradiction (a service with 0 legal groups) first appears only at depth 11:")
    for d in sorted(dead):
        print(f"   depth {d:>2}: {dead[d]:>6} failed nodes")

    print("\nGROWTH STUDY  (m = 3 ; prefix p free vertices + 4 hard/easy vertices ; n = p + 4)")
    print(f"{'n':>4}{'A nodes':>12}{'A backtracks':>14}{'B nodes (V1)':>16}{'B backtracks':>14}{'B nodes (V2)':>14}")
    for p in (4, 6, 8, 10, 12):
        n1, a = graph_A(p) if p <= 8 else graph_A_big(p)
        n2, b = graph_B(p)
        sa = colour_graph(n1, a, m, "input")[2]
        sb = colour_graph(n2, b, m, "input")[2]
        sv2 = colour_graph(n2, b, m, "mrv")[2]
        print(f"{n2:>4}{sa.nodes:>12}{sa.backtracks:>14}{sb.nodes:>16}{sb.backtracks:>14}{sv2.nodes:>14}")


def graph_A_big(p):
    """Easy family for p > 8: same recipe (disjoint pairs prefix + triangle at the end)."""
    n = p + 4
    edges = [(i, i + 1) for i in range(0, p - 1, 2)][:4]
    edges += [(p, p + 1), (p + 1, p + 2), (p, p + 2), (p - 1, p + 3)]
    return n, edges


if __name__ == "__main__":
    main()
