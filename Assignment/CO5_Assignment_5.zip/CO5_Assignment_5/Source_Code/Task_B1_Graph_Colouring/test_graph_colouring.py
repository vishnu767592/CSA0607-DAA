"""Task B1.1 - validation suite. Run:  python3 test_graph_colouring.py"""
import itertools, random, unittest
from graph_colouring import colour_graph, is_valid_colouring
from graphs import complete, cycle, path, petersen, grotzsch, random_graph


def brute_force_colourable(n, edges, m):
    """Reference oracle: try every one of m^n assignments (only used for n <= 9)."""
    if n == 0:
        return True
    if m <= 0:
        return False
    for assign in itertools.product(range(m), repeat=n):
        if all(assign[u] != assign[v] for u, v in edges):
            return True
    return False


class TestColouring(unittest.TestCase):
    # ---- T1: colourable graph -> verifies a correct, valid colouring is produced
    def test_T1_colourable(self):
        for order in ("input", "mrv"):
            for (n, e), m in [(cycle(5), 3), (petersen(), 3), (path(6), 2)]:
                ok, col, st = colour_graph(n, e, m, order)
                self.assertTrue(ok)
                self.assertTrue(is_valid_colouring(n, e, m, col))

    # ---- T2: not colourable with m -> verifies the search is exhaustive and returns failure
    def test_T2_not_colourable(self):
        for order in ("input", "mrv"):
            for (n, e), m in [(complete(4), 3), (cycle(5), 2), (grotzsch(), 3), (petersen(), 2)]:
                ok, col, st = colour_graph(n, e, m, order)
                self.assertFalse(ok)
                self.assertIsNone(col)

    # ---- T3: boundary cases
    def test_T3_boundary(self):
        for order in ("input", "mrv"):
            self.assertEqual(colour_graph(0, [], 3, order)[:2], (True, []))        # no services
            self.assertTrue(colour_graph(1, [], 1, order)[0])                       # one service, one group
            self.assertFalse(colour_graph(1, [], 0, order)[0])                      # service but zero groups
            ok, col, st = colour_graph(5, [], 1, order)                             # no conflicts, m = 1
            self.assertTrue(ok and col == [0] * 5)
            ok, col, st = colour_graph(4, complete(4)[1], 4, order)                 # K4 with m = 4 (tight)
            self.assertTrue(ok and len(set(col)) == 4)
            self.assertFalse(colour_graph(2, [(0, 1)], 1, order)[0])                # single edge, m = 1
            with self.assertRaises(ValueError):
                colour_graph(3, [(1, 1)], 3, order)                                 # self-loop is invalid input

    # ---- T4: cross-check against brute force on random graphs (both orders)
    def test_T4_random_vs_bruteforce(self):
        rng = random.Random(2026)
        for _ in range(300):
            n = rng.randint(1, 8)
            p = rng.choice([0.2, 0.4, 0.6, 0.8])
            m = rng.randint(1, 4)
            n, e = random_graph(n, p, rng.randint(0, 10**6))
            expect = brute_force_colourable(n, e, m)
            for order in ("input", "mrv"):
                ok, col, st = colour_graph(n, e, m, order)
                self.assertEqual(ok, expect)
                if ok:
                    self.assertTrue(is_valid_colouring(n, e, m, col))

    # ---- T5: instrumentation invariants
    def test_T5_counter_invariants(self):
        rng = random.Random(7)
        for _ in range(200):
            n, e = random_graph(rng.randint(2, 10), rng.choice([0.3, 0.5]), rng.randint(0, 10**6))
            m = rng.randint(2, 4)
            for order in ("input", "mrv"):
                ok, col, st = colour_graph(n, e, m, order)
                self.assertEqual(st.nodes, st.candidates - st.rejected + 1)   # every accepted candidate = 1 child node
                self.assertLessEqual(st.max_depth, n)
                if ok:
                    self.assertEqual(st.max_depth, n)
                    self.assertEqual(st.backtracks, st.nodes - 1 - n)           # only the final path is not undone
                else:
                    self.assertEqual(st.backtracks, st.nodes - 1)               # every accepted assignment is undone


if __name__ == "__main__":
    unittest.main(verbosity=2)
