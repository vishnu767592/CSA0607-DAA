"""Standard test graphs shared by B1 and B2. Every graph is (n, edges)."""
import itertools, random


def complete(k):
    return k, [(i, j) for i in range(k) for j in range(i + 1, k)]


def cycle(k):
    return k, [(i, (i + 1) % k) for i in range(k)]


def path(k):
    return k, [(i, i + 1) for i in range(k - 1)]


def petersen():
    outer = [(i, (i + 1) % 5) for i in range(5)]
    spoke = [(i, i + 5) for i in range(5)]
    inner = [(5 + i, 5 + (i + 2) % 5) for i in range(5)]
    return 10, outer + spoke + inner


def grotzsch():                                      # Mycielskian of C5: triangle-free, chi = 4
    n, e = cycle(5)
    edges = list(e)
    for (u, v) in e:
        edges += [(u, 5 + v), (v, 5 + u)]
    edges += [(5 + i, 10) for i in range(5)]
    return 11, edges


def queen_graph(k):
    cells = [(r, c) for r in range(k) for c in range(k)]
    idx = {x: i for i, x in enumerate(cells)}
    edges = []
    for a, b in itertools.combinations(cells, 2):
        if a[0] == b[0] or a[1] == b[1] or abs(a[0]-b[0]) == abs(a[1]-b[1]):
            edges.append((idx[a], idx[b]))
    return k * k, edges


def random_graph(n, p, seed):
    rng = random.Random(seed)
    return n, [(i, j) for i in range(n) for j in range(i + 1, n) if rng.random() < p]
