"""Task B1 driver: validation cases (B1.1), A1.5 trace, and Version 1 vs Version 2 comparison (B1.3/B1.4)."""
import time
from graph_colouring import colour_graph, is_valid_colouring
from graphs import complete, cycle, path, petersen, grotzsch, queen_graph, random_graph


def fmt(st):
    return f"nodes={st.nodes:>7} cand={st.candidates:>7} rej={st.rejected:>7} bt={st.backtracks:>7} depth={st.max_depth}"


def validation():
    print("=" * 100)
    print("B1.1  VALIDATION CASES")
    print("=" * 100)
    cases = [
        ("T1a colourable: C5, m=3",            cycle(5), 3, True,  "valid colouring is found"),
        ("T1b colourable: Petersen, m=3",      petersen(), 3, True, "valid colouring on a harder graph"),
        ("T2a NOT colourable: K4, m=3",        complete(4), 3, False, "failure only after exhausting search"),
        ("T2b NOT colourable: C5, m=2",        cycle(5), 2, False, "odd cycle needs 3 colours"),
        ("T2c NOT colourable: Groetzsch, m=3", grotzsch(), 3, False, "triangle-free yet chi=4"),
        ("T3a boundary: empty graph (n=0)",    (0, []), 3, True,  "no services -> trivially TRUE, empty colouring"),
        ("T3b boundary: n=1, m=1",             (1, []), 1, True,  "smallest non-empty instance"),
        ("T3c boundary: n=1, m=0",             (1, []), 0, False, "service but no server group"),
        ("T3d boundary: 5 isolated, m=1",      (5, []), 1, True,  "no conflicts -> one group suffices"),
        ("T3e boundary: K4, m=4 (tight)",      complete(4), 4, True, "m equals chromatic number"),
        ("T3f boundary: one edge, m=1",        (2, [(0, 1)]), 1, False, "two conflicting services, one group"),
    ]
    for name, (n, e), m, expect, purpose in cases:
        for order in ("input", "mrv"):
            ok, col, st = colour_graph(n, e, m, order)
            good = (ok == expect) and (not ok or is_valid_colouring(n, e, m, col))
            print(f"{name:<38} V{'1' if order=='input' else '2'} expected={str(expect):<5} got={str(ok):<5} "
                  f"{'PASS' if good else 'FAIL'}  colouring={col}")
        print(f"{'':<38} purpose: {purpose}")
    print()


def a15_trace():
    print("=" * 100)
    print("A1.5  TRACE  (5 services S1..S5, conflicts S1-S3, S3-S4, S2-S4, S4-S5, m = 2 groups, input order)")
    print("=" * 100)
    names = ["S1", "S2", "S3", "S4", "S5"]
    edges = [(0, 2), (2, 3), (1, 3), (3, 4)]
    lines = []
    ok, col, st = colour_graph(5, edges, 2, "input", trace=lines.append, names=names)
    print("\n".join(lines))
    print("RESULT:", ok, {names[i]: f"G{c+1}" for i, c in enumerate(col)}, "|", fmt(st))
    print()


def suite():
    s = []
    s.append(("Trace graph, m=2", 5, [(0, 2), (2, 3), (1, 3), (3, 4)], 2))
    s.append(("C5, m=3", *cycle(5), 3))
    s.append(("Petersen, m=3", *petersen(), 3))
    s.append(("Petersen, m=2", *petersen(), 2))
    s.append(("K6, m=5", *complete(6), 5))
    s.append(("Groetzsch, m=3", *grotzsch(), 3))
    s.append(("Groetzsch, m=4", *grotzsch(), 4))
    s.append(("Queen 5x5, m=5", *queen_graph(5), 5))
    s.append(("Queen 5x5, m=4", *queen_graph(5), 4))
    for seed in (1, 2, 3):
        s.append((f"Random n=14 p=.30 s{seed}, m=3", *random_graph(14, 0.30, seed), 3))
    return s


def comparison():
    print("=" * 100)
    print("B1.3 / B1.4  VERSION 1 (input order)  vs  VERSION 2 (most-constrained-first)")
    print("=" * 100)
    hdr = f"{'Graph':<32}{'Res':<6}{'Ver':<4}{'Nodes':>9}{'Cand.':>9}{'Rejected':>10}{'Backtracks':>12}{'Depth':>6}"
    print(hdr)
    print("-" * len(hdr))
    tot = {"input": [0, 0, 0, 0], "mrv": [0, 0, 0, 0]}
    for name, n, e, m in suite():
        for order, v in (("input", "V1"), ("mrv", "V2")):
            ok, col, st = colour_graph(n, e, m, order)
            print(f"{name:<32}{('SAT' if ok else 'UNSAT'):<6}{v:<4}{st.nodes:>9}{st.candidates:>9}{st.rejected:>10}{st.backtracks:>12}{st.max_depth:>6}")
            for i, x in enumerate((st.nodes, st.candidates, st.rejected, st.backtracks)):
                tot[order][i] += x
    print("-" * len(hdr))
    print("TOTAL (all graphs above)")
    for order, v in (("input", "V1"), ("mrv", "V2")):
        t = tot[order]
        print(f"{'':<32}{'':<6}{v:<4}{t[0]:>9}{t[1]:>9}{t[2]:>10}{t[3]:>12}")
    r = [round(tot['mrv'][i] / tot['input'][i], 3) for i in range(4)]
    print("V2/V1 ratio:", r)

    # aggregate over 40 random graphs, n=16, p=0.3, m=3 : how often does each version win?
    wins = {"V1": 0, "V2": 0, "tie": 0}
    s1 = s2 = 0
    for seed in range(100, 140):
        n, e = random_graph(16, 0.3, seed)
        a = colour_graph(n, e, 3, "input")[2].nodes
        b = colour_graph(n, e, 3, "mrv")[2].nodes
        s1 += a; s2 += b
        wins["V1" if a < b else "V2" if b < a else "tie"] += 1
    print(f"\n40 random graphs (n=16, p=0.30, m=3): total nodes V1={s1}  V2={s2}  (V2/V1={s2/s1:.3f});  fewer-nodes wins {wins}")
    print()


if __name__ == "__main__":
    validation()
    a15_trace()
    comparison()
