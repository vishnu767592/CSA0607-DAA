"""
Task B1 - Instrumented backtracking for Graph Colouring (m-colouring decision problem).

Services = vertices, conflicts = edges, server groups = colours 0..m-1.
Two search-order strategies share the SAME search procedure; only SELECT-NEXT differs:

  order="input"  -> Version 1 : vertices taken in the original (input) order
  order="mrv"    -> Version 2 : dynamic 'most-constrained-first' (DSATUR-style):
                    pick the uncoloured vertex with the FEWEST still-legal colours;
                    ties -> most uncoloured neighbours; ties -> lowest index.

Counters (all defined precisely so they can be cross-checked):
  nodes       number of calls to BACKTRACK (root + every child + success leaf)
  candidates  number of (vertex, colour) pairs submitted to the feasibility test
  rejected    candidates that FAILED the feasibility test (pruned, never expanded)
  backtracks  number of assignments that were UNDONE after their subtree failed
  max_depth   deepest number of vertices simultaneously coloured
Invariant:   nodes = (candidates - rejected) + 1
"""
import sys
from dataclasses import dataclass

sys.setrecursionlimit(10000)


@dataclass
class Stats:
    nodes: int = 0
    candidates: int = 0
    rejected: int = 0
    backtracks: int = 0
    max_depth: int = 0

    def as_tuple(self):
        return (self.nodes, self.candidates, self.rejected, self.backtracks, self.max_depth)


def build_adjacency(n, edges):
    adj = [[] for _ in range(n)]
    for u, v in edges:
        if u == v:
            raise ValueError("self-loop: a service cannot conflict with itself")
        if v not in adj[u]:
            adj[u].append(v)
            adj[v].append(u)
    return adj


def colour_graph(n, edges, m, order="input", trace=None, names=None):
    """Return (found, colouring, stats). colouring[v] in 0..m-1 or None if no m-colouring exists.
    trace: optional callable(str) receiving a line per search event (used for the A1.5 trace)."""
    stats = Stats()
    # ---- trivial / boundary cases handled before the search starts ----
    if n == 0:
        return True, [], stats                       # nothing to assign
    if m <= 0:
        return False, None, stats                    # vertices exist but no server group
    adj = build_adjacency(n, edges)
    colour = [-1] * n
    nm = (lambda v: names[v]) if names else (lambda v: f"v{v}")
    log = trace if trace else (lambda s: None)

    def feasible(v, c):                              # FEASIBLE(v,c): no neighbour already has c
        for w in adj[v]:
            if colour[w] == c:
                return False
        return True

    def legal_count(v):
        return sum(1 for c in range(m) if feasible(v, c))

    def select_next(depth):                          # SELECT-NEXT-SERVICE
        if order == "input":
            return depth                             # vertex number 'depth' (input order)
        best, best_key = None, None
        for v in range(n):
            if colour[v] == -1:
                key = (legal_count(v), -sum(1 for w in adj[v] if colour[w] == -1), v)
                if best_key is None or key < best_key:
                    best, best_key = v, key
        return best

    def backtrack(depth):
        stats.nodes += 1
        stats.max_depth = max(stats.max_depth, depth)
        if depth == n:                               # every service has a group -> SUCCESS
            log(f"{'  '*depth}GOAL: all {n} services assigned")
            return True
        v = select_next(depth)
        log(f"{'  '*depth}CHOOSE  {nm(v)}  (depth {depth})")
        for c in range(m):                           # candidate server groups
            stats.candidates += 1
            if not feasible(v, c):                   # CHECK  -> prune without expanding
                stats.rejected += 1
                log(f"{'  '*depth}  CHECK  {nm(v)}=G{c+1}: REJECT (neighbour already in G{c+1})")
                continue
            colour[v] = c                            # ASSIGN
            log(f"{'  '*depth}  CHECK  {nm(v)}=G{c+1}: ACCEPT -> EXPLORE next level")
            if backtrack(depth + 1):                 # EXPLORE
                return True
            colour[v] = -1                           # UNDO
            stats.backtracks += 1
            log(f"{'  '*depth}  BACKTRACK: undo {nm(v)}=G{c+1}")
        log(f"{'  '*depth}  dead end at {nm(v)}: all {m} groups exhausted -> return FALSE")
        return False

    found = backtrack(0)
    return found, (colour[:] if found else None), stats


def is_valid_colouring(n, edges, m, colouring):
    """Independent verifier used by the tests (does not share code with the solver)."""
    if colouring is None or len(colouring) != n:
        return False
    if any((c is None or c < 0 or c >= m) for c in colouring):
        return False
    return all(colouring[u] != colouring[v] for u, v in edges)
