# CO5 Assignment 5 – Search, Complexity and Approximation Engineering

Author: Vishnuvardhan Reddy L

| Task | Folder | Run |
|---|---|---|
| B1 Instrumented graph colouring (input order vs most-constrained-first) | `Source_Code/Task_B1_Graph_Colouring` | `python3 test_graph_colouring.py && python3 run_b1.py` |
| B2 Adversarial input (same n, m, edges; very different search) | `Source_Code/Task_B2_Adversarial_Search` | `python3 adversarial.py` |
| B3 Set cover: exact vs greedy approximation | `Source_Code/Task_B3_Exact_vs_Approximation` | `python3 -m unittest -v && python3 run_b3.py` |
| B4 Bin packing: First-Fit Decreasing | `Source_Code/Task_B4_Bin_Packing` | `python3 -m unittest -v && python3 run_b4.py` |

Python 3.9+, standard library only. All random instances use fixed seeds; operation counts are reproducible (timings vary by machine).
Each task folder contains an `output_*.txt` with the logged results quoted in the report.
The full report (Part A pseudocode/analysis + Part B results, all nine tasks) is in `Report/CO5_Assignment_5_Report.pdf`.
