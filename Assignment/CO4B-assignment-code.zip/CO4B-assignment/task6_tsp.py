"""Task 6 - Last-mile delivery routing: Travelling Salesperson Problem with the Held-Karp Dynamic Programme.

Location 0 is the distribution hub; locations 1..n are delivery points.
Subsets S are bit-masks over the n delivery points only (bit k-1 <-> location k), so the hub is
implicit as the start and the end of every tour.

    DP[S][j] = minimum cost of a path that starts at the hub, visits exactly the locations in S
               (once each) and ends at location j in S.
    Base     : DP[{j}][j]  = cost[0][j]
    Recur    : DP[S][j]    = min over i in S\\{j} of DP[S\\{j}][i] + cost[i][j]
    Answer   : min over j of DP[ALL][j] + cost[j][0]
"""

import itertools
import time
import random
import tracemalloc

INF = float("inf")
NAMES = ["Hub", "A", "B", "C", "D", "E", "F"]
COST = [  # asymmetric travel costs (one-way streets) between Hub, A..F
    [0, 12, 29, 22, 13, 24, 19],
    [12, 0, 19, 3, 25, 6, 17],
    [29, 19, 0, 21, 23, 28, 8],
    [22, 3, 21, 0, 4, 26, 15],
    [13, 25, 23, 4, 0, 9, 27],
    [24, 6, 28, 26, 9, 0, 11],
    [19, 17, 8, 15, 27, 11, 0],
]


def validate_matrix(cost):
    n = len(cost)
    if n < 2:
        raise ValueError("need a hub and at least one delivery location")
    if any(len(r) != n for r in cost):
        raise ValueError("cost matrix must be square")
    if any(cost[i][j] < 0 for i in range(n) for j in range(n)):
        raise ValueError("travel costs must be non-negative")


def held_karp(cost, record_log=False):
    """Returns (best_cost, tour as list of location indices incl. hub at both ends, stats)."""
    validate_matrix(cost)
    n = len(cost) - 1  # number of delivery locations
    full = (1 << n) - 1
    dp = [[INF] * n for _ in range(1 << n)]  # dp[mask][j-1]
    parent = [
        [-1] * n for _ in range(1 << n)
    ]  # previous location (0-based among deliveries, -1 = hub)
    states = transitions = 0
    log = []
    for j in range(n):  # base states |S| = 1
        dp[1 << j][j] = cost[0][j + 1]
        states += 1
    for mask in range(1, 1 << n):  # increasing mask => all subsets of mask are done first
        for j in range(n):
            if not mask & (1 << j) or mask == (1 << j):
                continue
            states += 1
            prev_mask = mask ^ (1 << j)
            for i in range(n):
                if prev_mask & (1 << i):
                    transitions += 1
                    cand = dp[prev_mask][i] + cost[i + 1][j + 1]
                    if cand < dp[mask][j]:
                        dp[mask][j], parent[mask][j] = cand, i
            if record_log and bin(mask).count("1") <= 3:
                log.append((mask, j, dp[mask][j], parent[mask][j]))
    best, last = INF, -1
    for j in range(n):  # close the tour: return to the hub
        total = dp[full][j] + cost[j + 1][0]
        if total < best:
            best, last = total, j
    tour, mask, j = [], full, last  # backtrack
    while j != -1:
        tour.append(j + 1)
        pj = parent[mask][j]
        mask ^= 1 << j
        j = pj
    tour = [0] + tour[::-1] + [0]
    return (
        best,
        tour,
        {"states": states, "transitions": transitions, "table_cells": (1 << n) * n, "log": log},
    )


def brute_force_tsp(cost):
    n = len(cost) - 1
    best, best_tour = INF, None
    for perm in itertools.permutations(range(1, n + 1)):
        t = (0,) + perm + (0,)
        c = sum(cost[a][b] for a, b in zip(t, t[1:]))
        if c < best:
            best, best_tour = c, list(t)
    return best, best_tour, len(list(itertools.permutations(range(n))))


def route_text(tour, names):
    return " -> ".join(names[i] for i in tour)


def mask_text(mask, names):
    return "{" + ",".join(names[k + 1] for k in range(len(names) - 1) if mask >> k & 1) + "}"


def random_matrix(n_deliveries, seed=0):
    rnd = random.Random(seed)
    size = n_deliveries + 1
    return [[0 if i == j else rnd.randint(5, 60) for j in range(size)] for i in range(size)]


if __name__ == "__main__":
    print("=== 6.3 ROUTE OPTIMISATION ENGINE : hub + 6 delivery locations ===")
    print("Cost matrix (row = from, column = to):")
    print("        " + "".join(f"{n:>6}" for n in NAMES))
    for i, row in enumerate(COST):
        print(f"{NAMES[i]:>6}  " + "".join(f"{c:>6}" for c in row))
    best, tour, st = held_karp(COST, record_log=True)
    print(f"\nOptimal route : {route_text(tour, NAMES)}")
    print(f"Visit order   : {' , '.join(NAMES[i] for i in tour[1:-1])}")
    legs = [f"{NAMES[a]}->{NAMES[b]}={COST[a][b]}" for a, b in zip(tour, tour[1:])]
    print("Legs          : " + ", ".join(legs))
    print(
        f"MINIMUM TRAVEL COST = {best}  (sum of legs = {sum(COST[a][b] for a, b in zip(tour, tour[1:]))})"
    )
    print(f"DP states evaluated = {st['states']}, transitions = {st['transitions']}")
    print("\nSample DP states (|S| <= 3, first 14): DP[S][j] = cost, previous location")
    for mask, j, val, par in st["log"][:14]:
        prev_name = "Hub" if par == -1 else NAMES[par + 1]
        print(
            f"  DP[{mask_text(mask, NAMES):<10}][{NAMES[j+1]}] = {val:>3}   (came from {prev_name})"
        )

    print("\n=== 6.4 VALIDATION : hub + 4 delivery locations ===")
    small = [row[:5] for row in COST[:5]]
    dpv, dpt, _ = held_karp(small)
    bfv, bft, count = brute_force_tsp(small)
    print("Sub-matrix uses Hub, A, B, C, D")
    print(
        f"Exhaustive enumeration of {count} permutations -> optimum {bfv}, route {route_text(bft, NAMES)}"
    )
    print(
        f"Held-Karp DP                                  -> optimum {dpv}, route {route_text(dpt, NAMES)}"
    )
    print(f"Costs equal: {dpv == bfv}")
    allperm = {}
    for perm in itertools.permutations(range(1, 5)):
        t = (0,) + perm + (0,)
        allperm[route_text(t, NAMES)] = sum(small[a][b] for a, b in zip(t, t[1:]))
    print("All 24 route costs (sorted):", sorted(allperm.values()))
    bf6, _, c6 = brute_force_tsp(COST)
    print(
        f"Extra check, full 6-location instance: brute force ({c6} perms) = {bf6}, DP = {best}, equal = {bf6 == best}"
    )
    rnd_bad = 0
    for s in range(200):
        n = random.Random(s).randint(1, 7)
        m = random_matrix(n, s)
        rnd_bad += held_karp(m)[0] != brute_force_tsp(m)[0]
    print(f"Random asymmetric instances (1..7 locations): 200 compared, mismatches = {rnd_bad}")

    print("\n=== BOUNDARY / FAILURE TESTS ===")
    one = [[0, 7], [9, 0]]
    v, t, _ = held_karp(one)
    print(
        f"  1 delivery location: cost {v}, route {route_text(t, ['Hub', 'X'])}   (expected 7+9=16)"
    )
    zero = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    v, t, _ = held_karp(zero)
    print(f"  all-zero costs: cost {v}")
    for bad in ([[0]], [[0, 1], [2]], [[0, -1], [1, 0]]):
        try:
            held_karp(bad)
        except ValueError as e:
            print(f"  invalid matrix {bad} -> ValueError: {e}")

    print("\n=== 6.5 STATE-SPACE GROWTH (random asymmetric costs, seed 0) ===")
    print(
        f"{'n':>3}{'|subsets| 2^n':>14}{'DP states':>11}{'transitions':>13}{'table cells':>12}{'peak mem (KiB)':>15}{'time (s)':>10}"
    )
    for n in range(4, 15):
        m = random_matrix(n, 0)
        tracemalloc.start()
        t0 = time.perf_counter()
        v, t, st = held_karp(m)
        el = time.perf_counter() - t0
        peak = tracemalloc.get_traced_memory()[1] / 1024
        tracemalloc.stop()
        print(
            f"{n:>3}{2**n:>14,}{st['states']:>11,}{st['transitions']:>13,}{st['table_cells']:>12,}{peak:>15,.0f}{el:>10.3f}"
        )
    print("states = n*2^(n-1) ; transitions = n(n-1)*2^(n-2) ; n! tours for brute force:")
    for n in (10, 14, 20, 25):
        import math

        print(
            f"  n={n:>2}: brute force n! = {math.factorial(n):.3e}, DP states n*2^(n-1) = {n*2**(n-1):.3e}, DP table cells n*2^n = {n*2**n:.3e}"
        )
    print(
        "  n=200: DP states = 200*2^199 ~ 1.6e62, table cells = 200*2^200 ~ 3.2e62, tours = 200! ~ 7.9e374"
    )
