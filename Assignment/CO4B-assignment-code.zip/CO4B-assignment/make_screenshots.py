"""Render captured program output (outputs/*.txt) as terminal-style PNG screenshots."""
import json, re, textwrap
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
SIZE, WRAP, MAXLINES = 15, 112, 46
f, fb = ImageFont.truetype(FONT, SIZE), ImageFont.truetype(BOLD, SIZE)
cw = f.getlength("M"); lh = SIZE + 6
manifest = {}


def wrap(lines):
    out = []
    for ln in lines:
        if len(ln) <= WRAP:
            out.append(ln)
        else:
            ind = len(ln) - len(ln.lstrip()) + 4
            out += textwrap.wrap(ln, WRAP, subsequent_indent=" " * ind, break_long_words=True)[:]
    return out


def chunks(lines):
    lines = wrap(lines)
    parts, cur = [], []
    for ln in lines:
        cur.append(ln)
        if len(cur) >= MAXLINES and (ln.strip() == "" or len(cur) >= MAXLINES + 8):
            parts.append(cur); cur = []
    if cur:
        parts.append(cur)
    return parts


def draw(cmd, lines, path):
    w = int(cw * (WRAP + 4)) + 32
    h = 44 + lh * (len(lines) + 2) + 16
    im = Image.new("RGB", (w, h), "#1e1f26")
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, w, 34], fill="#2d2f3a")
    for k, c in enumerate(("#ff5f56", "#ffbd2e", "#27c93f")):
        d.ellipse([14 + 22 * k, 10, 26 + 22 * k, 22], fill=c)
    d.text((100, 9), "Terminal - CO4B", font=f, fill="#9aa0b4")
    y = 46
    d.text((16, y), "$ " + cmd, font=fb, fill="#7ee787"); y += lh + 4
    for ln in lines:
        col = "#e6e6e6"
        if ln.startswith("===") or "MINIMUM" in ln or "OPTIMAL" in ln.upper()[:12] or "DETECTED" in ln:
            col = "#ffd866"
        elif "WRONG" in ln or "!!" in ln or "ValueError" in ln:
            col = "#ff7b72"
        elif "<== chosen" in ln:
            col = "#a5d6ff"
        d.text((16, y), ln, font=f, fill=col); y += lh
    im.save(path)


def shot(key, cmd, lines):
    paths = []
    for i, part in enumerate(chunks(lines), 1):
        p = f"screenshots/{key}_{i}.png"
        draw(cmd, part, p); paths.append(p)
    manifest[key] = paths


def sections(fn):
    txt = open(fn).read().split("\n")
    secs, cur, name = {}, [], "head"
    for ln in txt:
        if ln.startswith("=== "):
            secs[name] = cur; name, cur = ln, []
        cur.append(ln)
    secs[name] = cur
    return {k: [l for l in v] for k, v in secs.items()}


def between(lines, start, end=None):
    s = next(i for i, l in enumerate(lines) if start in l)
    e = next((i for i, l in enumerate(lines) if i > s and end in l), len(lines)) if end else len(lines)
    return lines[s:e]


def strip_trailing(lines):
    while lines and not lines[-1].strip(): lines = lines[:-1]
    return lines

# ---- Task 1
L = open("outputs/task1_base_states.txt").read().split("\n")
shot("t1_layout", "python3 task1_word_wrap.py 28", strip_trailing(L[:10]))
shot("t1_dptable", "python3 task1_word_wrap.py 28 --states   # DP table", strip_trailing(between(L, "DP table", "Candidates examined")))
shot("t1_cands", "python3 task1_word_wrap.py 28 --states   # candidate transitions", strip_trailing(L[next(i for i,l in enumerate(L) if "Candidates examined" in l):]))
S = open("outputs/task1_experiments.txt").read().split("\n")
shot("t1_changes", "python3 task1_experiments.py   # 1.3 width changes", strip_trailing(between(S, "=== 1.3", "=== 1.4")))
shot("t1_boundary", "python3 task1_experiments.py   # 1.4 boundary tests", strip_trailing(S[next(i for i,l in enumerate(S) if "=== 1.4" in l):]))
# ---- Task 2
s = sections("outputs/task2.txt")
for k, key in (("2.1", "t2_21"), ("2.2", "t2_22"), ("2.3", "t2_23"), ("2.4", "t2_24")):
    name = next(n for n in s if n.startswith("=== " + k))
    shot(key, "python3 task2_knapsack.py   # " + name.strip("= "), strip_trailing(s[name]))
# ---- Task 3
s = sections("outputs/task3.txt")
for k, key in (("STAGE A", "t3_a"), ("STAGE B", "t3_b"), ("STAGE C", "t3_c"), ("STAGE D", "t3_d")):
    name = next(n for n in s if k in n)
    shot(key, "python3 task3_routing.py   # " + k.title(), strip_trailing(s[name]))
# ---- Task 4
T = open("outputs/task4.txt").read().split("\n")
i_route = next(i for i, l in enumerate(T) if l.startswith("Optimal route"))
i_43 = next(i for i, l in enumerate(T) if "=== 4.3" in l)
i_44 = next(i for i, l in enumerate(T) if "=== 4.4" in l)
i_bd = next(i for i, l in enumerate(T) if "BOUNDARY" in l)
shot("t4_trace", "python3 task4_assembly_line.py   # 4.1/4.2 inputs and DP trace", T[1:i_route])
shot("t4_route", "python3 task4_assembly_line.py   # 4.1 reconstructed route", T[i_route:i_43])
shot("t4_43", "python3 task4_assembly_line.py   # 4.3 prediction run", T[i_43:i_44])
shot("t4_44", "python3 task4_assembly_line.py   # 4.4 disruption run", T[i_44:i_bd])
bd = [l for l in T[i_bd:] if not re.match(r"^(a1=|a2=|t1=|entry=|Station \||   1    \||  +\||Line |Entry|Exit$|Optimal route|Transfer points)", l) and not l.startswith("  |")]
shot("t4_bound", "python3 task4_assembly_line.py   # boundary, failure and regression tests", strip_trailing(bd))
# ---- Task 5
s = sections("outputs/task5.txt")
def sec(key): return next(n for n in s if key in n)
shot("t5_graph", "python3 task5_mst.py   # graph + Kruskal", strip_trailing(s[sec("GRAPH")] + [""] + s[sec("KRUSKAL")]))
shot("t5_prim", "python3 task5_mst.py   # Prim", strip_trailing(s[sec("PRIM")]))
shot("t5_boruvka", "python3 task5_mst.py   # Boruvka + comparison", strip_trailing(s[sec("BORUVKA")]))
shot("t5_stress", "python3 task5_mst.py   # multiple-MST stress test", strip_trailing(s[sec("STRESS")] + [""] + s[sec("TIE HAZARD")]))
shot("t5_deploy", "python3 task5_mst.py   # failure tests + deployment measurements", strip_trailing(s[sec("FAILURE")] + [""] + s[sec("DEPLOYMENT")]))
# ---- Task 6
s = sections("outputs/task6.txt")
shot("t6_63", "python3 task6_tsp.py   # 6.3", strip_trailing(s[sec("6.3")]))
shot("t6_64", "python3 task6_tsp.py   # 6.4 + boundary tests", strip_trailing(s[sec("6.4")] + [""] + s[sec("BOUNDARY")]))
shot("t6_65", "python3 task6_tsp.py   # 6.5", strip_trailing(s[sec("6.5")]))
json.dump(manifest, open("screenshots/manifest.json", "w"), indent=1)
print({k: len(v) for k, v in manifest.items()})
