"""Diagrams used in the report (network, MST and assembly-line route)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import task3_routing as t3
import task5_mst as t5
import task4_assembly_line as t4

POS = {"A": (0, 2), "B": (2, 3.5), "C": (1.8, 0.4), "D": (4.2, 1.2), "E": (4.4, 3.5), "F": (6.4, 1.9), "G": (6.4, 0.1), "H": (8.8, 1.6)}


def node(ax, v, pos, fc="#DCE6F1", ec="#1F4E79"):
    x, y = pos[v]
    ax.scatter([x], [y], s=900, c=fc, edgecolors=ec, linewidths=1.8, zorder=3)
    ax.text(x, y, v, ha="center", va="center", fontsize=13, fontweight="bold", zorder=4)


def directed(ax, u, v, w, pos, color="#444", rad=0.0, label_off=(0, 0.0), t=0.5):
    (x1, y1), (x2, y2) = pos[u], pos[v]
    ar = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=16, lw=1.6, color=color,
                         connectionstyle=f"arc3,rad={rad}", shrinkA=19, shrinkB=19, zorder=2)
    ax.add_patch(ar)
    ax.text(x1 + (x2 - x1) * t + label_off[0], y1 + (y2 - y1) * t + label_off[1], str(w), fontsize=11, color=color,
            ha="center", va="center", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.9), zorder=5)


def fig_t3():
    fig, ax = plt.subplots(figsize=(8.4, 4.4))
    tpos = {("A", "G"): 0.8, ("C", "F"): 0.55, ("C", "D"): 0.4, ("E", "H"): 0.3, ("B", "F"): 0.78, ("A", "C"): 0.5, ("D", "E"): 0.62, ("D", "G"): 0.5}
    for u, v, w in t3.BASE_EDGES:
        rad = {("D", "E"): 0.2, ("C", "F"): -0.3}.get((u, v), 0.0)
        directed(ax, u, v, w, POS, rad=rad, t=tpos.get((u, v), 0.5), label_off={("D", "E"): (0.25, 0), ("C", "F"): (0.95, 0.85)}.get((u, v), (0, 0)))
    u, v, w = t3.NEG_EDGE
    directed(ax, u, v, w, POS, color="#C62828", rad=-0.05, t=0.5, label_off=(-0.22, 0.0))
    u, v, w = t3.CYCLE_EDGE
    directed(ax, u, v, w, POS, color="#E65100", rad=0.2, t=0.35, label_off=(-0.3, 0.0))
    for v in POS:
        node(ax, v, POS)
    ax.set_xlim(-0.8, 9.6); ax.set_ylim(-0.6, 4.1); ax.axis("off")
    ax.set_title("Task 3 network: black = Stage A (13 edges), red = Stage B negative edge D->B (-5), orange = Stage C edge E->D (0)", fontsize=9)
    fig.tight_layout(); fig.savefig("figures/t3_graph.png", dpi=170); plt.close(fig)


def fig_t5():
    pos = {"A": (0, 2), "B": (2, 3.2), "C": (2, 0.8), "D": (4, 3.2), "E": (4, 0.8), "F": (6, 3.2), "G": (6, 0.8), "H": (8, 2)}
    mst, tot, _ = t5.kruskal(t5.VERTS, t5.EDGES)
    chosen = t5.canon(mst)
    fig, ax = plt.subplots(figsize=(8.4, 4.0))
    for u, v, w in t5.EDGES:
        inmst = frozenset((u, v)) in chosen
        (x1, y1), (x2, y2) = pos[u], pos[v]
        ax.plot([x1, x2], [y1, y2], color="#2E7D32" if inmst else "#B0B7C3", lw=3.2 if inmst else 1.4, zorder=1,
                ls="-" if inmst else "--")
        ax.text((x1 + x2) / 2, (y1 + y2) / 2, str(w), fontsize=11, ha="center", va="center", fontweight="bold",
                color="#1B5E20" if inmst else "#555", bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none"), zorder=5)
    for v in pos:
        node(ax, v, pos)
    ax.set_xlim(-0.8, 8.8); ax.set_ylim(0, 4.0); ax.axis("off")
    ax.set_title(f"Task 5 graph (8 vertices, 13 edges). Green = unique MST, total cost {tot}", fontsize=10)
    fig.tight_layout(); fig.savefig("figures/t5_graph.png", dpi=170); plt.close(fig)


def fig_t4(route, a1, a2, t1, t2, title, path):
    n = len(a1)
    fig, ax = plt.subplots(figsize=(8.4, 3.2))
    for j in range(n):
        for line, a in ((0, a1), (1, a2)):
            on = route[j] == line
            y = 1.6 - line * 1.3
            ax.scatter([j * 1.4 + 1], [y], s=1300, marker="s", c="#C8E6C9" if on else "#ECEFF1",
                       edgecolors="#2E7D32" if on else "#90A4AE", linewidths=2 if on else 1, zorder=3)
            ax.text(j * 1.4 + 1, y, f"S{j+1}\n{a[j]}", ha="center", va="center", fontsize=9, zorder=4)
        for line in (0, 1):
            if j < n - 1 and route[j] == line and route[j + 1] == line:
                y = 1.6 - line * 1.3
                ax.annotate("", xy=((j + 1) * 1.4 + 0.65, y), xytext=(j * 1.4 + 1.35, y), arrowprops=dict(arrowstyle="-|>", color="#2E7D32", lw=2.2))
        if j < n - 1 and route[j] != route[j + 1]:
            y1, y2 = 1.6 - route[j] * 1.3, 1.6 - route[j + 1] * 1.3
            cost = (t1, t2)[route[j]][j]
            ax.annotate("", xy=((j + 1) * 1.4 + 0.65, y2), xytext=(j * 1.4 + 1.35, y1), arrowprops=dict(arrowstyle="-|>", color="#C62828", lw=2.2))
            ax.text((j * 1.4 + 1) + 0.7, 0.95, f"t={cost}", color="#C62828", fontsize=9, fontweight="bold", ha="center")
    ax.text(-0.15, 1.6, "Line 1", fontsize=10, fontweight="bold", va="center", ha="right")
    ax.text(-0.15, 0.3, "Line 2", fontsize=10, fontweight="bold", va="center", ha="right")
    ax.set_xlim(-1.2, n * 1.4 + 0.6); ax.set_ylim(-0.3, 2.3); ax.axis("off")
    ax.set_title(title, fontsize=10)
    fig.tight_layout(); fig.savefig(path, dpi=170); plt.close(fig)


def fig_t6():
    import math
    ns = list(range(4, 21))
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.semilogy(ns, [math.factorial(n) for n in ns], "o-", color="#C62828", label="Brute force: n! tours")
    ax.semilogy(ns, [n * 2 ** (n - 1) for n in ns], "s-", color="#1F4E79", label="Held-Karp DP: n*2^(n-1) states")
    ax.semilogy(ns, [2 ** n for n in ns], "^--", color="#2E7D32", label="Number of subsets: 2^n")
    ax.set_xlabel("number of delivery locations n"); ax.set_ylabel("count (log scale)")
    ax.set_title("DP removes the factorial but the exponential 2^n remains", fontsize=10)
    ax.grid(alpha=0.3); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig("figures/t6_growth.png", dpi=170); plt.close(fig)


if __name__ == "__main__":
    fig_t3(); fig_t5(); fig_t6()
    _, base, *_ = t4.assembly_dp(t4.A1, t4.A2, t4.T1, t4.T2, t4.E1, t4.E2, t4.X1, t4.X2)[:2], None
    r = t4.assembly_dp(t4.A1, t4.A2, t4.T1, t4.T2, t4.E1, t4.E2, t4.X1, t4.X2)
    fig_t4(r[1], t4.A1, t4.A2, t4.T1, t4.T2, f"Baseline optimal route - minimum time {r[0]} (green = chosen stations, red = transfers)", "figures/t4_base.png")
    t2m = t4.T2[:]; t2m[1] = 25
    r = t4.assembly_dp(t4.A1, t4.A2, t4.T1, t2m, t4.E1, t4.E2, t4.X1, t4.X2)
    fig_t4(r[1], t4.A1, t4.A2, t4.T1, t2m, f"After raising t2[2] to 25 - minimum time {r[0]}", "figures/t4_43.png")
    a1s = t4.A1[:]; a1s[2] = 14
    r = t4.assembly_dp(a1s, t4.A2, t4.T1, t4.T2, t4.E1, t4.E2, t4.X1, t4.X2)
    fig_t4(r[1], a1s, t4.A2, t4.T1, t4.T2, f"After slowing Line 1 / Station 3 to 14 - minimum time {r[0]}", "figures/t4_44.png")
    print("figures ok")
