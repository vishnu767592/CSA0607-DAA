"""Task 2 - Greedy vs Dynamic Programming: Fractional Knapsack (greedy) and 0/1 Knapsack (DP).

Every algorithm returns the chosen items AND an operation-counter dictionary so that
computational work and memory can be compared without relying on wall-clock time.
"""

import random
import time
from functools import cmp_to_key
from itertools import combinations
from fractions import Fraction


class Item:
    def __init__(self, item_id, weight, value):
        if weight <= 0 or value < 0:
            raise ValueError(f"invalid item {item_id}: weight must be >0 and value >=0")
        self.id, self.weight, self.value = item_id, weight, value
        self.ratio = Fraction(value, weight)

    def __repr__(self):
        return f"{self.id}(w={self.weight},v={self.value})"


def check_capacity(capacity):
    if capacity < 0:
        raise ValueError("capacity cannot be negative")


# ------------------------------------------------------------ Solution A (Greedy)
def fractional_greedy(items, capacity, log=None):
    """Sort by value/weight descending; take whole items; take a fraction of the first that does not fit."""
    check_capacity(capacity)
    ops = {"comparisons": 0, "steps": 0}
    counter = [0]

    def compare(a, b):  # counts every ratio comparison made by the sort
        counter[0] += 1
        return (b.ratio > a.ratio) - (b.ratio < a.ratio)

    order = sorted(items, key=cmp_to_key(compare))
    n = len(items)
    ops["comparisons"] = counter[0]
    remaining, total, taken = Fraction(capacity), Fraction(0), []
    for it in order:
        ops["steps"] += 1
        if remaining <= 0:
            if log is not None:
                log.append(f"  {it.id}: ratio {float(it.ratio):.3f} -> skip (knapsack full)")
            continue
        if it.weight <= remaining:
            frac = Fraction(1)
        else:
            frac = remaining / it.weight
        taken.append((it, frac))
        remaining -= frac * it.weight
        total += frac * it.value
        if log is not None:
            log.append(
                f"  {it.id}: ratio {float(it.ratio):.3f} -> take {float(frac):.3f} of it "
                f"(adds value {float(frac*it.value):.2f}), remaining capacity {float(remaining):.2f}"
            )
    ops["memory_cells"] = n  # sorted order list only
    return total, taken, ops


def zero_one_greedy(items, capacity, log=None):
    """The SAME ratio intuition applied to 0/1: take an item whole if it fits, otherwise skip it."""
    check_capacity(capacity)
    order = sorted(items, key=lambda it: it.ratio, reverse=True)
    remaining, total, taken = capacity, 0, []
    for it in order:
        if it.weight <= remaining:
            taken.append(it)
            remaining -= it.weight
            total += it.value
            if log is not None:
                log.append(
                    f"  commit {it.id} (ratio {float(it.ratio):.2f}), remaining capacity {remaining}"
                )
        elif log is not None:
            log.append(f"  skip   {it.id} (w={it.weight} > remaining {remaining})")
    return total, taken


# ------------------------------------------------------------ Solution B (DP)
def knapsack_dp(items, capacity, keep_table=False):
    """table[i][c] = best value using the first i items with capacity c.  Returns value, chosen items, ops."""
    check_capacity(capacity)
    n = len(items)
    table = [[0] * (capacity + 1) for _ in range(n + 1)]
    ops = {"cell_updates": 0, "comparisons": 0}
    for i in range(1, n + 1):
        it = items[i - 1]
        for c in range(capacity + 1):
            ops["cell_updates"] += 1
            best = table[i - 1][c]  # option 1: skip item i
            if it.weight <= c:
                ops["comparisons"] += 1
                take = table[i - 1][c - it.weight] + it.value  # option 2: take item i
                if take > best:
                    best = take
            table[i][c] = best
    chosen, c = [], capacity  # backtrack through the table
    for i in range(n, 0, -1):
        if table[i][c] != table[i - 1][c]:
            chosen.append(items[i - 1])
            c -= items[i - 1].weight
    chosen.reverse()
    ops["memory_cells"] = (n + 1) * (capacity + 1)
    return table[n][capacity], chosen, ops, (table if keep_table else None)


def brute_force_01(items, capacity):
    best = 0
    for k in range(len(items) + 1):
        for combo in combinations(items, k):
            if sum(i.weight for i in combo) <= capacity:
                best = max(best, sum(i.value for i in combo))
    return best


def make_items(rows):
    return [Item(*r) for r in rows]


def show_items(items):
    print(f"{'Item':<6}{'Weight':>7}{'Value':>7}{'Value/Weight':>14}")
    for it in items:
        print(f"{it.id:<6}{it.weight:>7}{it.value:>7}{float(it.ratio):>14.3f}")


def fmt_taken(taken):
    return ", ".join(f"{it.id}x{float(f):.3f}" if f != 1 else f"{it.id}" for it, f in taken)


def demo_21():
    print("=== 2.1 NORMAL CASE (value-to-weight greedy gives a strong / optimal result) ===")
    items = make_items(
        [("L1", 12, 96), ("L2", 8, 48), ("L3", 20, 100), ("L4", 10, 30), ("L5", 25, 50)]
    )
    show_items(items)
    for cap in (40, 45):
        print(f"\n--- Capacity = {cap} ---")
        log = []
        val, taken, ops = fractional_greedy(items, cap, log)
        print("Solution A - Fractional greedy decision sequence:")
        print("\n".join(log))
        print(
            f"Greedy (fractional) value = {float(val):.2f}; selected: {fmt_taken(taken)}; ops={ops}"
        )
        dpv, chosen, dops, _ = knapsack_dp(items, cap)
        print(
            f"Solution B - 0/1 DP optimum = {dpv}; selected: {[i.id for i in chosen]}; ops={dops}"
        )
        g01, t01 = zero_one_greedy(items, cap)
        print(f"Same ratio rule on 0/1 (whole items only) = {g01} {[i.id for i in t01]}")
    print(
        "\nInterpretation: for the FRACTIONAL formulation the ratio rule is provably optimal (259 at W=45 needs the 0.5 of L4).\n"
        "At W=40 the top-ratio items L1,L2,L3 fill the sack exactly, so no fraction is needed and the 0/1 DP optimum equals the\n"
        "greedy value. At W=45 the 0/1 optimum is lower than the fractional value because a half item is not allowed."
    )


def demo_22():
    print("\n=== 2.2 BREAK THE GREEDY INTUITION (student-designed 0/1 counter-example) ===")
    items = make_items([("A", 10, 60), ("B", 20, 100), ("C", 30, 120)])
    cap = 50
    show_items(items)
    print(f"Capacity = {cap}\n")
    log = []
    g, taken = zero_one_greedy(items, cap, log)
    print("0/1 greedy by value/weight:")
    print("\n".join(log))
    dpv, chosen, ops, table = knapsack_dp(items, cap, keep_table=True)
    print(f"\nGreedyResult = {g}   items {[i.id for i in taken]}")
    print(f"DPOptimum    = {dpv}   items {[i.id for i in chosen]}")
    assert g != dpv
    print(
        f"GreedyResult != DPOptimum  ->  {g} != {dpv}   (gap = {dpv-g}, greedy achieves {100*g/dpv:.1f}% of optimum)"
    )
    print(
        "First greedy commitment preventing the optimum: committing item A (highest ratio 6.0) first.\n"
        "  The optimum {B,C} contains no A; once A is in, only 40 units remain, so C(30) can never join B(20)."
    )
    print(
        "\nDP table row for each prefix of items at capacity 50: ",
        [table[i][50] for i in range(len(items) + 1)],
    )
    print("\nWorst-case style instance (greedy can be arbitrarily bad):")
    bad = make_items([("tiny", 1, 2), ("big", 100, 100)])
    g2, t2 = zero_one_greedy(bad, 100)
    d2, c2, _, _ = knapsack_dp(bad, 100)
    print(
        f"  capacity 100: greedy={g2} {[i.id for i in t2]} vs DP={d2} {[i.id for i in c2]}  (greedy = {100*g2/d2:.0f}% of optimum)"
    )


def demo_23():
    print("\n=== 2.3 ENGINEERING COMPARISON (operation / memory counters) ===")
    print(
        f"{'n':>5}{'W':>8} | {'greedy sort cmp':>16}{'greedy cells':>13} | {'DP cell updates':>16}{'DP memory cells':>16}"
        f" | {'greedy val':>10}{'DP opt':>8}{'quality':>9}{'optimal?':>9}"
    )
    random.seed(42)
    for n, W in [(10, 100), (20, 500), (50, 2000), (100, 5000), (200, 10000)]:
        items = [Item(f"i{k}", random.randint(5, 100), random.randint(10, 300)) for k in range(n)]
        gval, _, gops = fractional_greedy(items, W)
        g01, _ = zero_one_greedy(items, W)
        dv, _, dops, _ = knapsack_dp(items, W)
        print(
            f"{n:>5}{W:>8} | {gops['comparisons']:>16}{gops['memory_cells']:>13} | {dops['cell_updates']:>16}{dops['memory_cells']:>16}"
            f" | {g01:>10}{dv:>8}{100*g01/dv:>8.2f}%{'yes' if g01 == dv else 'no':>9}"
        )
    print(
        "(quality = 0/1 whole-item greedy value / DP optimum;  fractional greedy value is an upper bound on both)"
    )
    print("\nSolution quality over 2000 random small instances (n=8, W=60):")
    random.seed(1)
    opt = 0
    ratios = []
    for _ in range(2000):
        items = [Item(f"i{k}", random.randint(5, 40), random.randint(5, 100)) for k in range(8)]
        g, _ = zero_one_greedy(items, 60)
        d, _, _, _ = knapsack_dp(items, 60)
        assert d == brute_force_01(items, 60)
        opt += g == d
        ratios.append(g / d if d else 1)
    print(
        f"  greedy optimal in {opt}/2000 cases ({opt/20:.1f}%); mean quality {100*sum(ratios)/len(ratios):.2f}%;"
        f" worst {100*min(ratios):.2f}% of optimum  (DP matched brute force in all 2000)"
    )


def demo_24():
    print("\n=== 2.4 CHANGED REQUIREMENT: 'return extremely quickly, near-optimal acceptable' ===")
    print(
        f"{'n':>5}{'W':>8} | {'greedy cmps':>11}{'greedy ms':>10} | {'DP updates':>11}{'DP cells':>11}{'DP ms':>9} | {'greedy/DP value':>16}"
    )
    # measured runs (capacity kept moderate so pure-Python DP finishes)
    random.seed(5)
    rows = [(100, 5000), (200, 10000), (400, 10000), (400, 20000), (800, 20000)]
    for n, W in rows:
        items = [Item(f"i{k}", random.randint(5, 500), random.randint(10, 900)) for k in range(n)]
        t0 = time.perf_counter()
        gv, _, gops = fractional_greedy(items, W)
        g01, _ = zero_one_greedy(items, W)
        tg = (time.perf_counter() - t0) * 1000
        t0 = time.perf_counter()
        dv, _, dops, _ = knapsack_dp(items, W)
        td = (time.perf_counter() - t0) * 1000
        print(
            f"{n:>5}{W:>8} | {gops['comparisons']:>11}{tg:>10.2f} | {dops['cell_updates']:>11,}{dops['memory_cells']:>11,}{td:>9.1f} | "
            f"{100*g01/dv:>15.2f}%"
        )
    print(
        "Check: DP cell updates = n*(W+1) in every row, so work grows with the numeric VALUE of W (pseudo-polynomial);"
    )
    print("       greedy work depends only on n (sort) and is independent of W.")
    n, W = 500, 1_000_000
    gcmp = fractional_greedy(
        [Item(f"x{k}", random.randint(5, 500), random.randint(10, 900)) for k in range(n)], W
    )[2]["comparisons"]
    print(f"\nExtrapolation from the measured formulas for n={n}, W={W:,} (not executed):")
    print(
        f"  greedy (measured on a 500-item list) {gcmp} comparisons, {n} cells;  DP = {n*(W+1):,} updates and {(n+1)*(W+1):,} cells"
    )


if __name__ == "__main__":
    demo_21()
    demo_22()
    demo_23()
    demo_24()
