"""Task 1.3 (requirement change) and 1.4 (boundary / failure tests) + randomised validation."""

import random
from task1_word_wrap import *

words = TEXT.split()
BASE_W = 28
base_total, base_lines, _ = word_wrap_dp(words, BASE_W)

print("=== 1.3 REQUIREMENT CHANGE: same text, different line widths ===")
print(f"Baseline W={BASE_W}: penalty={base_total}, words/line={[j-i for i,j,_,_ in base_lines]}")
for W in (24, 32, 35):
    total, lines, _ = word_wrap_dp(words, W)
    print(f"\n--- W = {W} ---")
    print_layout(words, W, total, lines)
    first = next(
        (k for k, (a, b) in enumerate(zip(base_lines, lines), 1) if (a[0], a[1]) != (b[0], b[1])),
        None,
    )
    print(
        f"Arrangement changed: {[(a[0],a[1]) for a in base_lines] != [(b[0],b[1]) for b in lines]};"
        f" first differing line = {first}; penalty {base_total} -> {total}"
        f" ({'decrease' if total < base_total else 'increase' if total > base_total else 'same'})"
    )

print("\nPenalty for every width 14..39 (same text):")
scan = {W: word_wrap_dp(words, W)[0] for W in range(14, 40)}
print("  " + "  ".join(f"W{W}:{p}" for W, p in scan.items()))

print("\n=== 1.4 BOUNDARY / FAILURE TESTS ===")


def case(name, ws, W):
    try:
        t, l, _ = word_wrap_dp(ws, W)
        print(
            f"{name:<44} W={W:<3} -> penalty={t}, lines={[' '.join(ws[i:j]) for i,j,_,_ in l]}, "
            f"brute={brute_force(ws, W)}"
        )
    except ValueError as e:
        print(f"{name:<44} W={W:<3} -> ValueError: {e}")


case("B1 word exactly fills a line (len==W)", ["abcde", "fghij", "k"], 5)
case("B2 every word exactly W", ["aaaa", "bbbb", "cccc"], 4)
case("B3 single word", ["hello"], 5)
case("B4 whole text fits on ONE line (final line free)", ["a", "b", "c"], 20)
case("B5 empty input", [], 10)
case("B6 word longer than W (infeasible)", ["tiny", "extraordinary", "word"], 8)
case("B7 W=1, one-letter words", ["a", "b", "c"], 1)
case("B8 line pair that needs exactly W with spaces", ["aa", "bb", "cc"], 5)

print(
    "\nWhy B1/B2 were selected: they hit the off-by-one edge 'used == W'. A buggy test"
    "\n  'used >= width' would reject a valid line and find NO layout at all (INF)."
)


def buggy(words, width):  # deliberately defective copy: '>=' instead of '>'
    n = len(words)
    dp = [INF] * (n + 1)
    dp[0] = 0
    for j in range(1, n + 1):
        used = -1
        for i in range(j - 1, -1, -1):
            used += len(words[i]) + 1
            if used >= width:
                break  # <-- defect
            dp[j] = min(dp[j], dp[i] + line_penalty(width - used, j == n))
    return dp[n]


print(
    "Defective version on B1 (['abcde','fghij','k'], W=5):",
    buggy(["abcde", "fghij", "k"], 5),
    "(INF = no layout found)  | correct version:",
    word_wrap_dp(["abcde", "fghij", "k"], 5)[0],
)

print("\n=== Randomised validation against brute force ===")
random.seed(7)
bad = 0
for _ in range(500):
    n = random.randint(1, 10)
    W = random.randint(6, 20)
    ws = ["x" * random.randint(1, min(W, 8)) for _ in range(n)]
    if word_wrap_dp(ws, W)[0] != brute_force(ws, W):
        bad += 1
print(f"500 random instances, mismatches vs brute force = {bad}")
