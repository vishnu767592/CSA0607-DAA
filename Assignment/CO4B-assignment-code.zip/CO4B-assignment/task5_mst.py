"""Task 5 - Kruskal, Prim and Boruvka on the same connected, undirected, weighted graph."""

import heapq
import math
import random
import time
from itertools import combinations

VERTS = list("ABCDEFGH")
EDGES = [  # (u, v, weight)  - distinct weights => unique MST
    ("A", "B", 4),
    ("A", "C", 2),
    ("B", "C", 5),
    ("B", "D", 3),
    ("C", "E", 6),
    ("D", "E", 7),
    ("D", "F", 9),
    ("E", "G", 8),
    ("F", "G", 10),
    ("F", "H", 11),
    ("G", "H", 1),
    ("E", "F", 12),
    ("C", "D", 13),
]
# Modified weights: B-C 5->4 (ties with A-B in the triangle A,B,C) and F-G 10->9 (ties with D-F)
TIE_EDGES = [(u, v, {"BC": 4, "FG": 9}.get(u + v, w)) for u, v, w in EDGES]


class DisjointSet:
    """Union-Find with path compression and union by size; counts its own find() calls."""

    def __init__(self, items):
        self.parent = {x: x for x in items}
        self.size = {x: 1 for x in items}
        self.finds = 0

    def find(self, x):
        self.finds += 1
        root = x
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[x] != root:
            self.parent[x], x = root, self.parent[x]
        return root

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        if self.size[ra] < self.size[rb]:
            ra, rb = rb, ra
        self.parent[rb] = ra
        self.size[ra] += self.size[rb]
        return True


def check_connected(vertices, edges):
    ds = DisjointSet(vertices)
    for u, v, _ in edges:
        ds.union(u, v)
    if len({ds.find(v) for v in vertices}) != 1:
        raise ValueError("graph is not connected: no spanning tree exists")


# ------------------------------------------------------------------ Kruskal
def kruskal(vertices, edges, tie_order=None, trace=None):
    """Safe edge = lightest remaining edge whose ends lie in DIFFERENT components (cut property).
    tie_order: optional secondary sort key so that equal-weight edges can be ordered differently."""
    check_connected(vertices, edges)
    key = (lambda e: (e[2],)) if tie_order is None else (lambda e: (e[2], tie_order(e)))
    ordered = sorted(edges, key=key)
    ds, mst, total = DisjointSet(vertices), [], 0
    for u, v, w in ordered:
        if ds.union(u, v):
            mst.append((u, v, w))
            total += w
            if trace is not None:
                trace.append(
                    f"  ACCEPT {u}-{v} ({w})  components merged -> forest has {len(vertices)-len(mst)} trees"
                )
        elif trace is not None:
            trace.append(
                f"  reject {u}-{v} ({w})  both ends already in the same component (would form a cycle)"
            )
        if len(mst) == len(vertices) - 1:
            break
    return mst, total, {"find_calls": ds.finds, "edges_sorted": len(edges)}


# ------------------------------------------------------------------ Prim
def prim(vertices, edges, start, trace=None):
    """Safe edge = lightest edge leaving the single growing tree (cut property). Lazy-deletion binary heap."""
    check_connected(vertices, edges)
    adj = {v: [] for v in vertices}
    for u, v, w in edges:
        adj[u].append((w, v, u))
        adj[v].append((w, u, v))
    in_tree, mst, total = {start}, [], 0
    heap = list(adj[start])
    heapq.heapify(heap)
    pushes, pops = len(heap), 0
    while heap and len(in_tree) < len(vertices):
        w, v, u = heapq.heappop(heap)
        pops += 1
        if v in in_tree:
            continue
        in_tree.add(v)
        mst.append((u, v, w))
        total += w
        if trace is not None:
            trace.append(f"  ADD {u}-{v} ({w})  tree = {sorted(in_tree)}")
        for item in adj[v]:
            if item[1] not in in_tree:
                heapq.heappush(heap, item)
                pushes += 1
    return mst, total, {"heap_pushes": pushes, "heap_pops": pops}


def prim_array(vertices, edges, start):
    """Dense-graph variant: no heap, an array best[v] of the cheapest edge into the tree, scanned linearly."""
    check_connected(vertices, edges)
    w = {}
    for u, v, wt in edges:
        w[(u, v)] = w[(v, u)] = min(wt, w.get((u, v), wt))
    INF = float("inf")
    best = {v: (INF, None) for v in vertices}
    best[start] = (0, None)
    done, mst, total, scans = set(), [], 0, 0
    for _ in vertices:
        u = min((v for v in vertices if v not in done), key=lambda v: best[v][0])
        scans += len(vertices)
        done.add(u)
        if best[u][1] is not None:
            mst.append((best[u][1], u, best[u][0]))
            total += best[u][0]
        for v in vertices:
            if v not in done and (u, v) in w and w[(u, v)] < best[v][0]:
                best[v] = (w[(u, v)], u)
        scans += len(vertices)
    return mst, total, {"array_scans": scans}


# ------------------------------------------------------------------ Boruvka
def boruvka(vertices, edges, trace=None):
    """Each round every component picks its cheapest outgoing edge; all picks are safe and added together.
    Ties are broken by the total order (weight, u, v) - without a consistent rule two components could
    pick different equal edges of a cycle and create a cycle."""
    check_connected(vertices, edges)
    ds, mst, total, rounds, scans = DisjointSet(vertices), [], 0, 0, 0
    while len(mst) < len(vertices) - 1:
        rounds += 1
        cheapest = {}
        for u, v, w in edges:
            scans += 1
            cu, cv = ds.find(u), ds.find(v)
            if cu == cv:
                continue
            for comp in (cu, cv):
                if comp not in cheapest or (w, u, v) < (
                    cheapest[comp][2],
                    cheapest[comp][0],
                    cheapest[comp][1],
                ):
                    cheapest[comp] = (u, v, w)
        if trace is not None:
            comps = {}
            for x in vertices:
                comps.setdefault(ds.find(x), []).append(x)
            trace.append(
                f" Round {rounds}: components = {sorted(sorted(c) for c in comps.values())}"
            )
            for comp, (u, v, w) in sorted(cheapest.items()):
                trace.append(f"    component of {comp}: cheapest outgoing edge = {u}-{v} ({w})")
        added = []
        for u, v, w in sorted(set(cheapest.values())):
            if ds.union(u, v):
                mst.append((u, v, w))
                total += w
                added.append(f"{u}-{v}({w})")
        if trace is not None:
            trace.append(
                f"    added this round: {sorted(added)} -> {len(vertices)-len(mst)} component(s) remain"
            )
    return mst, total, {"rounds": rounds, "edge_scans": scans}


# ------------------------------------------------------------------ verification helpers
def canon(mst):
    return frozenset(frozenset((u, v)) for u, v, _ in mst)


def all_msts(vertices, edges):
    """Enumerate every spanning tree (feasible for 13 edges choose 7) and return the minimum-cost ones."""
    best, found = float("inf"), []
    for combo in combinations(edges, len(vertices) - 1):
        ds = DisjointSet(vertices)
        if all(ds.union(u, v) for u, v, _ in combo):
            c = sum(w for _, _, w in combo)
            if c < best:
                best, found = c, [combo]
            elif c == best:
                found.append(combo)
    return best, found


def show(name, mst, total, ops):
    print(f"{name}: edges = {sorted((u+'-'+v, w) for u, v, w in mst)}")
    print(f"{'':>{len(name)}}  total cost = {total};  work = {ops}")


def random_graph(n, m, seed):
    rnd = random.Random(seed)
    vs = [f"v{i}" for i in range(n)]
    edges = {(vs[rnd.randrange(i)], vs[i]) for i in range(1, n)}  # random spanning tree
    while len(edges) < m:
        a, b = rnd.sample(vs, 2)
        if (a, b) not in edges and (b, a) not in edges:
            edges.add((a, b))
    return vs, [(a, b, rnd.randint(1, 10 * m)) for a, b in sorted(edges)]


if __name__ == "__main__":
    print("=== GRAPH (8 vertices, 13 undirected edges, all weights distinct) ===")
    print(", ".join(f"{u}-{v}:{w}" for u, v, w in EDGES))

    print("\n=== KRUSKAL (sort edges, union-find) ===")
    tr = []
    k_mst, k_tot, k_ops = kruskal(VERTS, EDGES, trace=tr)
    print("\n".join(tr))
    show("Kruskal", k_mst, k_tot, k_ops)
    print("\n=== PRIM (start A, heap of crossing edges) ===")
    tr = []
    p_mst, p_tot, p_ops = prim(VERTS, EDGES, "A", trace=tr)
    print("\n".join(tr))
    show("Prim   ", p_mst, p_tot, p_ops)
    print("\n=== BORUVKA (parallel cheapest-edge rounds) ===")
    tr = []
    b_mst, b_tot, b_ops = boruvka(VERTS, EDGES, trace=tr)
    print("\n".join(tr))
    show("Boruvka", b_mst, b_tot, b_ops)
    print(
        f"\nSame cost: {k_tot == p_tot == b_tot}; same edge set: {canon(k_mst) == canon(p_mst) == canon(b_mst)}"
        f"  (distinct weights => the MST is unique)"
    )
    best, trees = all_msts(VERTS, EDGES)
    print(
        f"Brute force over all spanning trees: optimum = {best}, number of minimum spanning trees = {len(trees)}"
    )

    print("\n=== STRESS: modified weights  B-C 5->4 and F-G 10->9  (ties) ===")
    print(", ".join(f"{u}-{v}:{w}" for u, v, w in TIE_EDGES))
    best, trees = all_msts(VERTS, TIE_EDGES)
    print(
        f"Brute force: optimum = {best}, number of DISTINCT minimum spanning trees = {len(trees)}"
    )
    runs = {
        "Kruskal (ties: input order)": kruskal(VERTS, TIE_EDGES),
        "Kruskal (ties: reversed order)": kruskal(
            VERTS, TIE_EDGES, tie_order=lambda e: -TIE_EDGES.index(e)
        ),
        "Kruskal (custom: B-C and D-F first)": kruskal(
            VERTS, TIE_EDGES, tie_order=lambda e: 0 if (e[0] + e[1]) in ("BC", "DF") else 1
        ),
        "Prim from A": prim(VERTS, TIE_EDGES, "A"),
        "Prim from H": prim(VERTS, TIE_EDGES, "H"),
        "Boruvka (u,v tie-break)": boruvka(VERTS, TIE_EDGES),
    }
    sets = {}
    for name, (mst, tot, _) in runs.items():
        sets.setdefault(canon(mst), []).append(name)
        print(
            f"  {name:<32} cost={tot}  tie edges chosen: "
            + ", ".join(
                sorted(f"{u}-{v}" for u, v, w in mst if (u + v) in ("AB", "BC", "DF", "FG"))
            )
        )
    print(
        f"Number of different edge sets returned = {len(sets)}; all costs equal = {len({r[1] for r in runs.values()}) == 1};"
        f" every returned tree is one of the {len(trees)} brute-force MSTs = {all(s in {canon(t) for t in trees} for s in sets)}"
    )
    tr = []
    boruvka(VERTS, TIE_EDGES, trace=tr)

    print("\n=== BORUVKA TIE HAZARD: triangle X,Y,Z with three equal weights (1,1,1) ===")
    tri = [("X", "Y", 1), ("Y", "Z", 1), ("X", "Z", 1)]
    naive = {
        "X": ("X", "Y"),
        "Y": ("Y", "Z"),
        "Z": ("Z", "X"),
    }  # each vertex picks a DIFFERENT equal-weight edge
    picked = {frozenset(e) for e in naive.values()}
    print(
        f"  naive per-component choice picks {len(picked)} edges for 3 vertices (a tree needs 2) -> forms a cycle"
    )
    mst_t, tot_t, _ = boruvka(list("XYZ"), tri)
    print(
        f"  with the total order (weight,u,v) Boruvka returns {sorted((u + v) for u, v, _ in mst_t)}, cost {tot_t}: a tree"
    )

    print("\n=== FAILURE TESTS ===")
    for name, vs, es in [("disconnected graph", list("ABCD"), [("A", "B", 1), ("C", "D", 2)])]:
        try:
            kruskal(vs, es)
        except ValueError as e:
            print(f"  {name}: ValueError: {e}")
    print(
        "  single vertex:",
        kruskal(["A"], [])[:2],
        "| two vertices:",
        kruskal(list("AB"), [("A", "B", 7)])[:2],
    )
    print("  parallel edges A-B (5, 2):", kruskal(list("AB"), [("A", "B", 5), ("A", "B", 2)])[:2])

    print("\n=== DEPLOYMENT EVIDENCE: measured work on sparse vs dense random graphs ===")
    print(
        f"{'Environment':<28}{'V':>6}{'E':>8} | {'Kruskal finds':>14}{'Prim pushes':>12}{'Prim pops':>10}{'Prim O(V^2)':>12}{'Boruvka rounds':>15}{'Boruvka scans':>14} | agree"
    )
    for label, n, m in [
        ("A sparse  (E ~ 2V)", 2000, 4000),
        ("A sparse  (E ~ 3V)", 2000, 6000),
        ("B dense   (E ~ V^2/4)", 300, 22000),
        ("B dense   (E ~ V^2/2.2)", 300, 40000),
    ]:
        vs, es = random_graph(n, m, seed=3)
        km, kt, ko = kruskal(vs, es)
        pm, pt, po = prim(vs, es, vs[0])
        bm, bt, bo = boruvka(vs, es)
        print(
            f"{label:<28}{n:>6}{m:>8} | {ko['find_calls']:>14}{po['heap_pushes']:>12}{po['heap_pops']:>10}{prim_array(vs, es, vs[0])[2]['array_scans']:>12}{bo['rounds']:>15}{bo['edge_scans']:>14} | {kt == pt == bt == prim_array(vs, es, vs[0])[1]}"
        )
    n, m = 20000, 60000
    vs, es = random_graph(n, m, seed=9)
    bm, bt, bo = boruvka(vs, es)
    print(
        f"{'C large (rounds shrink)':<28}{n:>6}{m:>8} | Boruvka rounds = {bo['rounds']} (log2 V = {math.log2(n):.1f}), "
        f"edge scans per round are independent -> parallelisable"
    )
