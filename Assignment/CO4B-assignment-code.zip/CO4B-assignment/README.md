# CSA06 Design and Analysis of Algorithms - CO4 Assignment 4B

Python 3.9+ (standard library only). Run everything with `bash run_all.sh`.

| Task | File | What it contains |
|------|------|------------------|
| 1 | `task1_word_wrap.py`, `task1_experiments.py` | Word-wrap DP, DP-state trace, 3 modified widths, boundary tests, brute-force validation |
| 2 | `task2_knapsack.py` | Fractional greedy, 0/1 DP, counter-example, operation/memory counters |
| 3 | `task3_routing.py` | Dijkstra, Bellman-Ford (+ negative-cycle detection), Floyd, Warshall |
| 4 | `task4_assembly_line.py` | Two-line assembly DP, decision trace, predictions, disruption test, regression vs brute force |
| 5 | `task5_mst.py` | Kruskal, Prim (heap and array), Boruvka, multiple-MST stress test, deployment measurements |
| 6 | `task6_tsp.py` | Held-Karp TSP DP, brute-force validation, state-space growth table |

`outputs/` holds the text captured from each program; `screenshots/` holds the images used in the report.
