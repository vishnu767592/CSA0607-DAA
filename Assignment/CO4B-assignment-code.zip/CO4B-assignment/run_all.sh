#!/usr/bin/env bash
# Reproduce every output used in the report.  Usage: bash run_all.sh
set -e
mkdir -p outputs
python3 task1_word_wrap.py 28 --states        > outputs/task1_base_states.txt
python3 task1_experiments.py                  > outputs/task1_experiments.txt
python3 task2_knapsack.py                     > outputs/task2.txt
python3 task3_routing.py                      > outputs/task3.txt
python3 task4_assembly_line.py                > outputs/task4.txt
python3 task5_mst.py                          > outputs/task5.txt
python3 task6_tsp.py                          > outputs/task6.txt
echo "All outputs written to ./outputs"
