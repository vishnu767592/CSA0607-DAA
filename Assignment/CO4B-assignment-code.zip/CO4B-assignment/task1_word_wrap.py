"""Task 1 - Word Wrap as a Document-Layout Engine (Dynamic Programming).

Penalty rule : a non-final line with s unused spaces costs s*s, final line costs 0.
Assumptions  : words are separated by exactly one space; a word longer than the
               line width W cannot be placed, so the input is rejected (ValueError).
"""

import sys
from itertools import combinations

INF = float("inf")


def validate(words, width):
    """Reject inputs that make the problem infeasible."""
    if width <= 0:
        raise ValueError("line width must be positive")
    for w in words:
        if len(w) > width:
            raise ValueError(f"word '{w}' (len {len(w)}) is longer than width {width}")


def line_penalty(unused, is_last_line):
    """Penalty of one line: zero for the final line, otherwise unused^2."""
    return 0 if is_last_line else unused * unused


def word_wrap_dp(words, width, record_states=False):
    """dp[j] = minimum penalty for laying out the first j words (words[0..j-1]).
    prev[j] = index i such that the last line holds words[i..j-1].
    Returns (total_penalty, lines, states) where lines = list of (i, j, unused, penalty).
    """
    validate(words, width)
    n = len(words)
    dp = [INF] * (n + 1)
    prev = [-1] * (n + 1)
    dp[0] = 0
    states = []  # instrumentation: every candidate examined
    for j in range(1, n + 1):
        used = -1  # characters used by words[i..j-1] incl. single spaces
        for i in range(j - 1, -1, -1):  # grow the last line leftwards
            used += len(words[i]) + 1
            if used > width:
                break
            unused = width - used
            pen = line_penalty(unused, j == n)
            cand = dp[i] + pen
            if record_states:
                states.append((j, i, unused, pen, dp[i], cand))
            if cand < dp[j]:  # strict '<': on a tie the candidate found first (shorter last line) is kept
                dp[j] = cand
                prev[j] = i
    lines, j = [], n  # reconstruct by walking prev[] backwards
    while j > 0:
        i = prev[j]
        used = sum(len(w) for w in words[i:j]) + (j - i - 1)
        unused = width - used
        lines.append((i, j, unused, line_penalty(unused, j == n)))
        j = i
    lines.reverse()
    return dp[n], lines, (dp, prev, states)


def greedy_wrap(words, width):
    """First-fit greedy used only as a comparison baseline."""
    validate(words, width)
    lines, i = [], 0
    while i < len(words):
        j, used = i, len(words[i])
        while j + 1 < len(words) and used + 1 + len(words[j + 1]) <= width:
            j += 1
            used += 1 + len(words[j])
        j += 1
        lines.append((i, j, width - used, 0 if j == len(words) else (width - used) ** 2))
        i = j
    return sum(l[3] for l in lines), lines


def brute_force(words, width):
    """Reference: try every way of cutting the word list into lines (2^(n-1))."""
    validate(words, width)
    n, best = len(words), INF
    if n == 0:  # defect found in testing: empty input gave inf
        return 0
    for k in range(n):
        for cuts in combinations(range(1, n), k):
            bounds = (0,) + cuts + (n,)
            total, ok = 0, True
            for a, b in zip(bounds, bounds[1:]):
                used = sum(len(w) for w in words[a:b]) + (b - a - 1)
                if used > width:
                    ok = False
                    break
                total += line_penalty(width - used, b == n)
            if ok:
                best = min(best, total)
    return best


# ------------------------------------------------------------------ output layer
def print_layout(words, width, total, lines):
    print(f"Line width W = {width}")
    print(f"MINIMUM TOTAL PENALTY = {total}\n")
    print(f"{'Line':<5}{'Text (| marks width W)':<{width + 2}}{'Unused':>7}{'Penalty':>9}")
    for k, (i, j, unused, pen) in enumerate(lines, 1):
        text = " ".join(words[i:j])
        print(f"{k:<5}{text:<{width}}|{unused:>7}{pen:>9}")
    print(f"{'':<5}{'Words per line: ' + str([j - i for i, j, _, _ in lines])}")


def print_dp_states(words, dp, prev, states, width):
    print("\nDP table  dp[j] = min penalty to lay out the first j words")
    print(f"{'j':>3} {'last word':<12}{'dp[j]':>7}{'prev[j]':>9}   meaning")
    print(f"{0:>3} {'-':<12}{0:>7}{'-':>9}   empty layout (base case)")
    for j in range(1, len(words) + 1):
        i = prev[j]
        print(
            f"{j:>3} {words[j-1]:<12}{dp[j]:>7}{i:>9}   last line = words[{i}..{j-1}] = '{' '.join(words[i:j])}'"
        )
    print("\nCandidates examined (j = words placed, i = first word on last line)")
    print(f"{'j':>3}{'i':>4}{'unused':>8}{'penalty':>9}{'dp[i]':>7}{'dp[i]+pen':>11}")
    for j, i, unused, pen, dpi, cand in states:
        mark = "  <== chosen" if prev[j] == i and dp[j] == cand else ""
        print(f"{j:>3}{i:>4}{unused:>8}{pen:>9}{dpi:>7}{cand:>11}{mark}")
    print(f"\nStates dp[0..n] = {len(words)+1}, candidate transitions examined = {len(states)}")


TEXT = (
    "Dynamic programming solves a layout problem by remembering the best way "
    "to arrange every prefix of the text"
)

if __name__ == "__main__":
    width = int(sys.argv[1]) if len(sys.argv) > 1 else 24
    show = "--states" in sys.argv
    words = TEXT.split()
    total, lines, (dp, prev, states) = word_wrap_dp(words, width, record_states=show)
    print_layout(words, width, total, lines)
    gtotal, _ = greedy_wrap(words, width)
    print(
        f"(first-fit greedy baseline penalty = {gtotal}; brute-force optimum = {brute_force(words, width)})"
    )
    if show:
        print_dp_states(words, dp, prev, states, width)
