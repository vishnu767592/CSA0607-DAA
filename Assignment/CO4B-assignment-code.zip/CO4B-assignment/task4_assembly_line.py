"""Task 4 - Assembly-line scheduling (two lines) with Dynamic Programming.

Input  : a1[j], a2[j]  processing time of station j on line 1 / line 2   (j = 0..n-1)
         t1[j], t2[j]  transfer time paid when leaving line 1 / 2 AFTER station j (j = 0..n-2)
         e1, e2        entry times;   x1, x2  exit times
State  : f[line][j] = fastest time to finish station j on `line`.
"""

from itertools import product


def validate(a1, a2, t1, t2):
    n = len(a1)
    if n == 0 or len(a2) != n:
        raise ValueError("both lines need the same, non-zero number of stations")
    if len(t1) != n - 1 or len(t2) != n - 1:
        raise ValueError("transfer lists must have n-1 entries")
    if min(a1 + a2 + t1 + t2) < 0:
        raise ValueError("times must be non-negative")


def assembly_dp(a1, a2, t1, t2, e1, e2, x1, x2):
    """Returns (best_time, route, f, came_from, trace).
    came_from[line][j] = line used at station j-1 for the best way to reach (line, j)."""
    validate(a1, a2, t1, t2)
    n = len(a1)
    a = (a1, a2)
    t = (t1, t2)
    f = [[0] * n for _ in range(2)]
    came = [[None] * n for _ in range(2)]
    f[0][0], f[1][0] = e1 + a1[0], e2 + a2[0]  # base case: entry + first station
    trace = []
    for j in range(1, n):
        row = {"station": j + 1}
        for line in (0, 1):
            other = 1 - line
            stay = f[line][j - 1] + a[line][j]  # keep going on the same line
            move = (
                f[other][j - 1] + t[other][j - 1] + a[line][j]
            )  # come from the other line + transfer
            if stay <= move:  # tie -> prefer staying (no transfer)
                f[line][j], came[line][j], pick = stay, line, "stay"
            else:
                f[line][j], came[line][j], pick = move, other, "transfer"
            row[line] = (stay, move, pick)
        trace.append(row)
    finish = (f[0][n - 1] + x1, f[1][n - 1] + x2)  # add exit time
    last_line = 0 if finish[0] <= finish[1] else 1
    best = finish[last_line]
    route, line = [], last_line  # backtrack
    for j in range(n - 1, -1, -1):
        route.append(line)
        line = came[line][j] if j > 0 else line
    route.reverse()
    return best, route, f, came, trace, finish


def brute_force(a1, a2, t1, t2, e1, e2, x1, x2):
    """Try all 2^n line assignments; independent reference."""
    n = len(a1)
    a, t, e, x = (a1, a2), (t1, t2), (e1, e2), (x1, x2)
    best, best_route = float("inf"), None
    for route in product((0, 1), repeat=n):
        cost = e[route[0]] + a[route[0]][0]
        for j in range(1, n):
            cost += a[route[j]][j]
            if route[j] != route[j - 1]:
                cost += t[route[j - 1]][j - 1]
        cost += x[route[-1]]
        if cost < best:
            best, best_route = cost, list(route)
    return best, best_route


def print_trace(trace, finish, x1, x2, f, n):
    print(
        "Station | L1 by STAY | L1 by TRANSFER | selected | L2 by STAY | L2 by TRANSFER | selected | f1   f2"
    )
    print(
        "   1    |  (base: entry + a)                                                       |"
        f"  {f[0][0]:>3}  {f[1][0]:>3}"
    )
    for r in trace:
        (s1, m1, p1), (s2, m2, p2) = r[0], r[1]
        j = r["station"] - 1
        print(
            f"  {r['station']:>2}    | {s1:>9}  | {m1:>13}  | {p1:<8} | {s2:>9}  | {m2:>13}  | {p2:<8} | {f[0][j]:>3}  {f[1][j]:>3}"
        )
    print(f"Exit: line1 {f[0][n-1]}+{x1}={finish[0]}   line2 {f[1][n-1]}+{x2}={finish[1]}")


def print_route(route, t1, t2):
    print("\nOptimal route:")
    print("Entry")
    transfers = []
    for j, line in enumerate(route):
        if j > 0 and route[j] != route[j - 1]:
            cost = (t1, t2)[route[j - 1]][j - 1]
            print(f"  | Transfer Line {route[j-1]+1} -> Line {line+1} (cost {cost})")
            transfers.append((j, route[j - 1] + 1, line + 1, cost))
        else:
            print("  |")
        print(f"Line {line+1} - Station {j+1}")
    print("  |\nExit")
    print("Line chosen per station :", ["L" + str(l + 1) for l in route])
    print(
        "Transfer points         :",
        [f"after station {j} (L{a}->L{b}, cost {c})" for j, a, b, c in transfers] or "none",
    )


def run(title, a1, a2, t1, t2, e1, e2, x1, x2, quiet=False):
    best, route, f, came, trace, finish = assembly_dp(a1, a2, t1, t2, e1, e2, x1, x2)
    ref, _ = brute_force(a1, a2, t1, t2, e1, e2, x1, x2)
    print(f"--- {title} ---")
    if not quiet:
        print(f"a1={a1}\na2={a2}\nt1={t1}  t2={t2}\nentry=({e1},{e2}) exit=({x1},{x2})")
        print_trace(trace, finish, x1, x2, f, len(a1))
        print_route(route, t1, t2)
    print(
        f"MINIMUM PRODUCTION TIME = {best}   (brute-force reference = {ref}, match = {best == ref})"
    )
    return best, route


A1 = [7, 9, 3, 4, 8, 4]
A2 = [8, 5, 6, 4, 5, 7]
T1 = [2, 3, 1, 3, 4]
T2 = [2, 1, 2, 2, 1]
E1, E2, X1, X2 = 2, 4, 3, 2

if __name__ == "__main__":
    print("=== 4.1 / 4.2 BASELINE: engine + decision trace ===")
    base, base_route = run("Baseline", A1, A2, T1, T2, E1, E2, X1, X2)

    print("\n=== 4.3 PREDICT BEFORE YOU EXECUTE ===")
    print(
        "Change: transfer time t2[2] (leave Line 2 after station 2 -> Line 1) is raised from 1 to 25."
    )
    print("PREDICTION (recorded before the run):")
    print(
        "  * The baseline route L1,L2,L1,L2,L2,L1 uses exactly that transfer, so the route WILL change."
    )
    print("  * Most affected decision: the transfer between station 2 and station 3 (L2 -> L1).")
    print(
        "  * Total production time will INCREASE (the old optimum is no longer reachable), by at most 24."
    )
    t2_mod = T2[:]
    t2_mod[1] = 25
    mod, mod_route = run("Modified (t2[2]=25)", A1, A2, T1, t2_mod, E1, E2, X1, X2)
    print(
        f"Observed: route changed = {mod_route != base_route}; time {base} -> {mod} (delta {mod-base:+d});"
        f" new route {['L'+str(l+1) for l in mod_route]}"
    )

    print("\n=== 4.4 PRODUCTION DISRUPTION: Line-1 Station 3 slows from 3 to 14 ===")
    a1_slow = A1[:]
    a1_slow[2] = 14
    slow, slow_route = run(
        "Disruption (a1[3]=14)", A1[:2] + [14] + A1[3:], A2, T1, T2, E1, E2, X1, X2
    )
    changed = [j + 1 for j in range(6) if slow_route[j] != base_route[j]]
    print(
        f"Observed: route changed = {slow_route != base_route}; stations whose line changed = {changed};"
        f" time {base} -> {slow} (delta {slow-base:+d})"
    )
    print(
        "Penalty if the OLD route were kept: ",
        base + 11,
        "-> DP found",
        slow,
        "(the re-route saves",
        base + 11 - slow,
        ")",
    )

    print("\n=== BOUNDARY / FAILURE TESTS ===")
    run("n=1 (single station)", [5], [3], [], [], 2, 1, 1, 4)
    run("tie: both lines identical", [4, 4, 4], [4, 4, 4], [1, 1], [1, 1], 1, 1, 1, 1)
    run(
        "transfer cost huge -> never transfer",
        [5, 9, 5],
        [9, 1, 9],
        [999, 999],
        [999, 999],
        0,
        0,
        0,
        0,
    )
    run(
        "transfer cost zero -> pick cheapest station each time",
        [5, 9, 5],
        [9, 1, 9],
        [0, 0],
        [0, 0],
        0,
        0,
        0,
        0,
    )
    for bad in (([], [], [], []), ([1, 2], [1], [1], [1]), ([1, 2], [1, 2], [1], [])):
        try:
            assembly_dp(*bad, 0, 0, 0, 0)
        except ValueError as e:
            print(f"invalid input {bad} -> ValueError: {e}")

    import random

    random.seed(11)
    mism = 0
    for _ in range(1000):
        n = random.randint(1, 9)
        args = (
            [random.randint(1, 20) for _ in range(n)],
            [random.randint(1, 20) for _ in range(n)],
            [random.randint(0, 10) for _ in range(n - 1)],
            [random.randint(0, 10) for _ in range(n - 1)],
            random.randint(0, 9),
            random.randint(0, 9),
            random.randint(0, 9),
            random.randint(0, 9),
        )
        mism += assembly_dp(*args)[0] != brute_force(*args)[0]
    print(f"\nRegression: 1000 random instances (n<=9) DP vs brute force -> mismatches = {mism}")
