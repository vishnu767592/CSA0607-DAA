"""Task 3 - Routing engine: Dijkstra, Bellman-Ford, Floyd and Warshall on a directed weighted network.

Vertices are named A..H.  A graph is a dict {u: [(v, weight), ...]}.
Algorithm logic (functions) is kept separate from the printing code (bottom of file).
"""

import heapq

INF = float("inf")
VERTICES = list("ABCDEFGH")

# Stage A network : 8 vertices, 13 directed edges, all weights positive
BASE_EDGES = [
    ("A", "B", 8),
    ("A", "C", 6),
    ("A", "G", 15),
    ("C", "D", 3),
    ("C", "F", 9),
    ("B", "E", 4),
    ("B", "F", 6),
    ("D", "E", 11),
    ("D", "G", 7),
    ("E", "H", 3),
    ("F", "H", 5),
    ("G", "F", 2),
    ("G", "H", 10),
]
NEG_EDGE = ("D", "B", -5)  # Stage B : carefully chosen negative edge
CYCLE_EDGE = ("E", "D", 0)  # Stage C : closes the cycle D->B->E->D of weight -5+4+0 = -1


def build_graph(edges, vertices=VERTICES):
    g = {v: [] for v in vertices}
    for u, v, w in edges:
        if u not in g or v not in g:
            raise ValueError(f"edge {u}->{v} uses an unknown vertex")
        g[u].append((v, w))
    return g


def get_path(pred, source, target):
    if target == source:
        return [source]
    if pred.get(target) is None:
        return None  # unreachable
    path, v = [], target
    while v is not None:
        path.append(v)
        v = pred[v]
    return path[::-1]


# ----------------------------------------------------------------- Dijkstra
def dijkstra(graph, source):
    """Textbook Dijkstra: once a vertex is finalised its distance is never changed again."""
    dist = {v: INF for v in graph}
    pred = {v: None for v in graph}
    dist[source] = 0
    finalised, order, heap, trace = set(), [], [(0, source)], []
    while heap:
        d, u = heapq.heappop(heap)
        if u in finalised:
            continue  # stale heap entry
        finalised.add(u)
        order.append((u, d))
        for v, w in graph[u]:
            if v in finalised:  # assumption of Dijkstra: cannot be improved
                if d + w < dist[v]:
                    trace.append(
                        f"   !! {u}->{v} ({w}) would give {d + w} < finalised dist[{v}]={dist[v]} : IGNORED"
                    )
                continue
            if d + w < dist[v]:
                dist[v], pred[v] = d + w, u
                heapq.heappush(heap, (dist[v], v))
                trace.append(f"   relax {u}->{v}: dist[{v}] = {d + w}")
    return dist, pred, order, trace


# ----------------------------------------------------------------- Bellman-Ford
def bellman_ford(graph, source):
    """Returns (dist, pred, negative_cycle_or_None, passes_used)."""
    dist = {v: INF for v in graph}
    pred = {v: None for v in graph}
    dist[source] = 0
    edges = [(u, v, w) for u in graph for v, w in graph[u]]
    n = len(graph)
    for p in range(1, n):  # V-1 passes
        changed = False
        for u, v, w in edges:
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v], pred[v] = dist[u] + w, u
                changed = True
        if not changed:
            return dist, pred, None, p  # early exit: converged
    # V-th pass: any further relaxation of an edge out of a REACHABLE vertex proves a reachable negative cycle
    for u, v, w in edges:
        if dist[u] != INF and dist[u] + w < dist[v]:
            pred[v] = u
            return dist, pred, extract_cycle(pred, v, n), n
    return dist, pred, None, n


def extract_cycle(pred, start, n):
    v = start
    for _ in range(n):  # walk back n steps: guaranteed to land inside the cycle
        v = pred[v]
    cycle, u = [v], pred[v]
    while u != v:
        cycle.append(u)
        u = pred[u]
    cycle.reverse()  # predecessor order -> forward order
    return cycle + [cycle[0]]


# ----------------------------------------------------------------- Floyd / Warshall
def floyd(graph):
    """All-pairs shortest distances. Returns (dist, nxt, per_k_updates). A negative diagonal => negative cycle."""
    vs = list(graph)
    idx = {v: i for i, v in enumerate(vs)}
    n = len(vs)
    dist = [[0 if i == j else INF for j in range(n)] for i in range(n)]
    nxt = [[None] * n for _ in range(n)]
    for u in graph:
        for v, w in graph[u]:
            if w < dist[idx[u]][idx[v]]:
                dist[idx[u]][idx[v]] = w
                nxt[idx[u]][idx[v]] = idx[v]
    updates = []
    for k in range(n):
        count = 0
        for i in range(n):
            if dist[i][k] == INF:
                continue
            for j in range(n):
                if dist[k][j] != INF and dist[i][k] + dist[k][j] < dist[i][j]:
                    dist[i][j] = dist[i][k] + dist[k][j]
                    nxt[i][j] = nxt[i][k]
                    count += 1
        updates.append((vs[k], count))
    return vs, dist, nxt, updates


def floyd_path(vs, nxt, s, t):
    i, j = vs.index(s), vs.index(t)
    if nxt[i][j] is None:
        return [s] if i == j else None
    path = [s]
    while i != j:
        i = nxt[i][j]
        path.append(vs[i])
    return path


def warshall(graph):
    """Transitive closure: reach[i][j] is True when j can be reached from i."""
    vs = list(graph)
    idx = {v: i for i, v in enumerate(vs)}
    n = len(vs)
    reach = [[i == j for j in range(n)] for i in range(n)]
    for u in graph:
        for v, _ in graph[u]:
            reach[idx[u]][idx[v]] = True
    for k in range(n):
        for i in range(n):
            if reach[i][k]:
                for j in range(n):
                    if reach[k][j]:
                        reach[i][j] = True
    return vs, reach


# ----------------------------------------------------------------- presentation
def fmt(x):
    return "INF" if x == INF else str(x)


def report_sssp(title, dist, pred, source):
    print(f"{'Vertex':<8}{'Distance':>9}  {'Pred':<5} Path")
    for v in dist:
        p = get_path(pred, source, v)
        print(
            f"{v:<8}{fmt(dist[v]):>9}  {str(pred[v] or '-'):<5} {' -> '.join(p) if p else 'unreachable'}"
        )


def print_matrix(vs, m, as_bool=False):
    print("      " + "".join(f"{v:>5}" for v in vs))
    for i, v in enumerate(vs):
        cells = "".join(
            f"{('1' if m[i][j] else '0') if as_bool else fmt(m[i][j]):>5}" for j in range(len(vs))
        )
        print(f"  {v:<4}{cells}")


def stage_a():
    print("=== STAGE A : NORMAL ROUTING (Dijkstra, source = A) ===")
    print("Edges (u->v:w): " + ", ".join(f"{u}->{v}:{w}" for u, v, w in BASE_EDGES))
    print(f"Vertices = {len(VERTICES)}, edges = {len(BASE_EDGES)}\n")
    g = build_graph(BASE_EDGES)
    dist, pred, order, trace = dijkstra(g, "A")
    print("Order in which vertices become FINALISED (vertex, distance):")
    print("  " + "  ".join(f"{i+1}.{v}({d})" for i, (v, d) in enumerate(order)))
    print("\nRelaxation trace:")
    print("\n".join(trace))
    print()
    report_sssp("", dist, pred, "A")
    return dist, pred, order


def stage_b():
    print("\n=== STAGE B : NEGATIVE EDGE D->B (-5) ===")
    print("PREDICTION (written before running):")
    print(
        "  Dijkstra finalises B at 8 (via A->B) BEFORE it finalises D at 9 (A->C->D). The new edge D->B=-5 gives"
    )
    print(
        "  B = 9-5 = 4 but B is already finalised, so Dijkstra stays INVALID. Decision affected: the route to B"
    )
    print("  (A->B direct instead of A->C->D->B) and everything downstream of B: E, F, H.")
    print("  Expected correct values: B=4, E=8, F=10, H=11.\n")
    g = build_graph(BASE_EDGES + [NEG_EDGE])
    d_dist, d_pred, order, trace = dijkstra(g, "A")
    print(
        "Dijkstra on modified graph  (finalised order: "
        + " ".join(f"{v}({d})" for v, d in order)
        + ")"
    )
    print("\n".join(t for t in trace if "!!" in t))
    report_sssp("", d_dist, d_pred, "A")
    b_dist, b_pred, cyc, passes = bellman_ford(g, "A")
    print(f"\nBellman-Ford on the same graph (negative cycle: {cyc}, passes used: {passes})")
    report_sssp("", b_dist, b_pred, "A")
    print("\nComparison (Dijkstra vs Bellman-Ford):")
    for v in VERTICES:
        flag = "   <-- WRONG in Dijkstra" if d_dist[v] != b_dist[v] else ""
        print(f"  {v}: Dijkstra={fmt(d_dist[v]):>3}  Bellman-Ford={fmt(b_dist[v]):>3}{flag}")
    return d_dist, b_dist


def stage_c():
    print(
        "\n=== STAGE C : REACHABLE NEGATIVE CYCLE (edge E->D = 0 closes D->B->E->D = -5+4+0 = -1) ==="
    )
    g = build_graph(BASE_EDGES + [NEG_EDGE, CYCLE_EDGE])
    dist, pred, cyc, passes = bellman_ford(g, "A")
    if cyc:
        print(f"NEGATIVE CYCLE DETECTED after pass {passes} (pass V={len(g)}): " + " -> ".join(cyc))
        w = {(u, v): wt for u in g for v, wt in g[u]}
        print("  cycle weight = " + str(sum(w[(a, b)] for a, b in zip(cyc, cyc[1:]))))
        print("  Shortest paths are undefined; no distance table is reported.")
    d_dist, _, _, _ = dijkstra(g, "A")
    print(
        "(For contrast, Dijkstra would silently return: "
        + ", ".join(f"{v}={fmt(d_dist[v])}" for v in VERTICES)
        + ")"
    )
    print("\nTest C2 - negative cycle NOT reachable from the source (must not be reported):")
    g2 = build_graph([("A", "B", 2), ("C", "D", -3), ("D", "C", 1)], list("ABCD"))
    d2, _, cyc2, _ = bellman_ford(g2, "A")
    print(
        f"  source A, cycle C<->D unreachable -> cycle reported: {cyc2}; dist = {{{', '.join(f'{v}:{fmt(x)}' for v, x in d2.items())}}}"
    )
    print("Test C3 - source with no outgoing edges:")
    g3 = build_graph([("B", "C", 1)], list("ABC"))
    d3, _, cyc3, _ = bellman_ford(g3, "A")
    print(f"  dist = {{{', '.join(f'{v}:{fmt(x)}' for v, x in d3.items())}}}, cycle = {cyc3}")
    print("Test C4 - negative self loop A->A (-1):")
    g4 = build_graph([("A", "A", -1)], ["A"])
    print(f"  cycle = {bellman_ford(g4, 'A')[2]}")


def stage_d():
    print(
        "\n=== STAGE D : ALL PAIRS (Floyd) AND REACHABILITY (Warshall) on the Stage-A network ==="
    )
    g = build_graph(BASE_EDGES)
    vs, dist, nxt, updates = floyd(g)
    print("Floyd distance matrix (INF = no path):")
    print_matrix(vs, dist)
    print(
        "\nImprovements made while allowing each intermediate vertex k: "
        + ", ".join(f"k={k}:{c}" for k, c in updates)
    )
    print(
        "Sample route reconstruction: A->H = "
        + " -> ".join(floyd_path(vs, nxt, "A", "H"))
        + f" (cost {dist[0][7]});  D->H = "
        + " -> ".join(floyd_path(vs, nxt, "D", "H"))
        + f" (cost {dist[3][7]})"
    )
    print(
        "Check: Floyd row A equals Dijkstra from A:",
        all(dist[0][i] == dijkstra(g, "A")[0][v] for i, v in enumerate(vs)),
    )
    vs, reach = warshall(g)
    print("\nWarshall reachability matrix (1 = reachable):")
    print_matrix(vs, reach, as_bool=True)
    print(
        "Consistency: reach[i][j] == (Floyd dist < INF) for all pairs:",
        all(reach[i][j] == (dist[i][j] != INF) for i in range(8) for j in range(8)),
    )
    gn = build_graph(BASE_EDGES + [NEG_EDGE])
    vs, dn, _, _ = floyd(gn)
    print(
        "\nFloyd with negative edge D->B (no cycle): shortest D->B distance:",
        fmt(dn[3][1]),
        "(= -5 direct), A->B =",
        dn[0][1],
    )
    gc = build_graph(BASE_EDGES + [NEG_EDGE, CYCLE_EDGE])
    vs, dc, _, _ = floyd(gc)
    neg = [vs[i] for i in range(8) if dc[i][i] < 0]
    print(
        "Floyd on the negative-cycle graph: vertices with negative diagonal =",
        neg,
        "-> negative cycle detected",
    )


if __name__ == "__main__":
    stage_a()
    stage_b()
    stage_c()
    stage_d()
