"""Q1 - Selection, Bubble (with early-exit flag) and Insertion sort with operation counters."""
import random, time, json, os, sys
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def selection_sort(a):
    a = a[:]; c = s = 0
    n = len(a)
    for i in range(n - 1):
        m = i
        for j in range(i + 1, n):
            c += 1
            if a[j] < a[m]: m = j
        if m != i:
            a[i], a[m] = a[m], a[i]; s += 1
    return a, c, s

def bubble_sort(a):
    a = a[:]; c = s = 0
    n = len(a)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            c += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]; s += 1; swapped = True
        if not swapped: break
    return a, c, s

def insertion_sort(a):
    a = a[:]; c = s = 0          # s counts element movements (shifts)
    for i in range(1, len(a)):
        key = a[i]; j = i - 1
        while j >= 0:
            c += 1
            if a[j] > key:
                a[j + 1] = a[j]; s += 1; j -= 1
            else: break
        a[j + 1] = key
    return a, c, s

ALGS = {"Selection": selection_sort, "Bubble": bubble_sort, "Insertion": insertion_sort}

def datasets(n, seed=42):
    rnd = random.Random(seed)
    base = list(range(1, n + 1))
    rand = base[:]; rnd.shuffle(rand)
    nearly = base[:]
    for _ in range(int(0.05 * n)):          # ~5% of elements displaced
        i, j = rnd.randrange(n), rnd.randrange(n); nearly[i], nearly[j] = nearly[j], nearly[i]
    # 95% sorted + small batch of new orders appended (the fulfilment-centre scenario)
    k = max(1, int(0.05 * n))
    appended = list(range(1, n - k + 1)) + [rnd.randint(1, n) for _ in range(k)]
    dup = [rnd.choice([1, 2, 3]) for _ in range(n)]      # edge case: many duplicates
    return {
        "Sorted (best)": base,
        "Reverse (worst)": base[::-1],
        "Random": rand,
        "Nearly sorted (5% swapped)": nearly,
        "95% sorted + 5% new batch": appended,
        "Edge: many duplicates": dup,
    }

def run(n):
    rows = []
    for name, data in datasets(n).items():
        for an, f in ALGS.items():
            t = time.perf_counter(); out, c, s = f(data); dt = (time.perf_counter() - t) * 1000
            assert out == sorted(data)
            rows.append(dict(n=n, dataset=name, algorithm=an, comparisons=c, swaps_moves=s, time_ms=round(dt, 3)))
    return rows

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    out_dir = os.path.join(here, "..", "Output_Screenshots")
    n = 1000
    rows = run(n)
    # tiny demonstration
    demo = [64, 25, 12, 22, 11]
    print("Demo input:", demo)
    for an, f in ALGS.items():
        r, c, s = f(demo); print(f"  {an:10s} -> {r}  comparisons={c} swaps/moves={s}")
    print(f"\nn = {n}")
    print(f"{'Dataset':30s}{'Algorithm':11s}{'Comparisons':>13s}{'Swaps/Moves':>13s}{'Time(ms)':>10s}")
    for r in rows:
        print(f"{r['dataset']:30s}{r['algorithm']:11s}{r['comparisons']:>13,}{r['swaps_moves']:>13,}{r['time_ms']:>10.2f}")
    # scaling on 95%-sorted data
    scale = []
    for m in (250, 500, 1000, 2000):
        scale += run(m)
    json.dump({"main": rows, "scale": scale}, open(os.path.join(here, "q1_results.json"), "w"), indent=1)
    # chart 1: comparisons by dataset (n=1000)
    ds = list(dict.fromkeys(r["dataset"] for r in rows))
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    w = 0.27
    for k, an in enumerate(ALGS):
        ax[0].bar([i + (k - 1) * w for i in range(len(ds))], [next(r["comparisons"] for r in rows if r["dataset"] == d and r["algorithm"] == an) for d in ds], w, label=an)
        ax[1].bar([i + (k - 1) * w for i in range(len(ds))], [next(r["swaps_moves"] for r in rows if r["dataset"] == d and r["algorithm"] == an) for d in ds], w, label=an)
    for a_, t in zip(ax, ("Comparisons", "Swaps / element movements")):
        a_.set_xticks(range(len(ds))); a_.set_xticklabels([d.replace(" (", "\n(").replace(" + ", "\n+ ") for d in ds], fontsize=7)
        a_.set_title(f"{t}, n = {n}"); a_.legend(); a_.set_yscale("symlog"); a_.grid(axis="y", alpha=.3)
    plt.tight_layout(); plt.savefig(os.path.join(out_dir, "q1_operation_counts.png"), dpi=130); plt.close()
    # chart 2: scaling on 95%-sorted
    plt.figure(figsize=(6.5, 4.5))
    for an in ALGS:
        pts = [(r["n"], r["comparisons"]) for r in scale if r["dataset"] == "95% sorted + 5% new batch" and r["algorithm"] == an]
        plt.plot(*zip(*pts), marker="o", label=an)
    plt.xlabel("n"); plt.ylabel("comparisons"); plt.title("95% sorted + 5% new batch"); plt.legend(); plt.grid(alpha=.3)
    plt.tight_layout(); plt.savefig(os.path.join(out_dir, "q1_scaling_95pct.png"), dpi=130); plt.close()
