"""Q2 - Sequential search on aircraft tool-issue records."""
import random, time, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def make_records(n):
    return [{"tool": f"T-{i}", "tech": f"E{random.Random(i).randint(100,999)}", "time": "08:00", "bay": i % 12 + 1} for i in range(n)]

def seq_search(records, tool):
    c = 0
    for idx, r in enumerate(records):
        c += 1
        if r["tool"] == tool: return idx, c
    return -1, c

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, "..", "Output_Screenshots")
    sizes = [100, 1000, 10000, 100000]
    rows = []
    print("Successful (best / middle / worst position) and unsuccessful search - comparisons")
    print(f"{'n':>8}{'first':>8}{'middle':>9}{'last':>9}{'miss':>9}{'avg(100 random hits)':>22}{'theory avg (n+1)/2':>20}")
    for n in sizes:
        recs = make_records(n)
        f = seq_search(recs, "T-0")[1]; m = seq_search(recs, f"T-{n//2}")[1]; l = seq_search(recs, f"T-{n-1}")[1]; u = seq_search(recs, "T-X")[1]
        rnd = random.Random(7); avg = sum(seq_search(recs, f"T-{rnd.randrange(n)}")[1] for _ in range(1000)) / 1000
        print(f"{n:>8}{f:>8}{m:>9}{l:>9}{u:>9}{avg:>22.1f}{(n+1)/2:>20.1f}")
        rows.append(dict(n=n, first=f, middle=m, last=l, miss=u, avg_random_hit=avg))
    # Frequency / workload model: total comparisons per hour and time
    print("\nWorkload model (average successful search = n/2; unsuccessful = n). 1 comparison measured below.")
    recs = make_records(100000); t = time.perf_counter()
    for _ in range(20): seq_search(recs, "T-X")
    per_cmp_ns = (time.perf_counter() - t) / (20 * 100000) * 1e9
    print(f"Measured cost per comparison in Python: {per_cmp_ns:.1f} ns")
    scen = [("1 hangar", 300, 60), ("1 hangar, busy", 300, 600), ("20 facilities (single central list)", 6000, 6000), ("20 facilities, heavy", 6000, 60000), ("Enterprise-scale", 100000, 100000)]
    wl = []
    print(f"{'Scenario':40}{'records':>9}{'lookups/h':>11}{'avg cmp/lookup':>16}{'cmp/hour':>17}{'CPU sec/hour':>14}")
    for name, n, q in scen:
        avgc = 0.9 * (n + 1) / 2 + 0.1 * n  # assume 90% hits, 10% misses
        tot = avgc * q; cpu = tot * per_cmp_ns / 1e9
        print(f"{name:40}{n:>9}{q:>11}{avgc:>16,.0f}{tot:>17,.0f}{cpu:>14.3f}")
        wl.append(dict(scenario=name, records=n, lookups_per_hour=q, avg_cmp=avgc, cmp_per_hour=tot, cpu_sec_per_hour=cpu))
    json.dump({"rows": rows, "per_cmp_ns": per_cmp_ns, "workload": wl}, open(os.path.join(here, "q2_results.json"), "w"), indent=1)
    plt.figure(figsize=(6.5, 4.5))
    ns = [r["n"] for r in rows]
    for k, lab in (("first", "best (first)"), ("middle", "middle"), ("last", "worst (last)"), ("miss", "unsuccessful")):
        plt.plot(ns, [r[k] for r in rows], marker="o", label=lab)
    plt.xscale("log"); plt.yscale("log"); plt.xlabel("list size n"); plt.ylabel("comparisons"); plt.legend(); plt.grid(alpha=.3)
    plt.title("Sequential search comparisons"); plt.tight_layout(); plt.savefig(os.path.join(out, "q2_comparisons.png"), dpi=130)
