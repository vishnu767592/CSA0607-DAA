"""Q7 - Redesign of the Q6 exhaustive search: pruned include/exclude search with a bound.
Original = Q6 exhaustive(); Redesign = pruned_search(). Same instances, same capacity."""
import sys, os, time, json, random
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "Q6_Exhaustive_Search", "Implementation_Code"))
from q6_exhaustive_search import exhaustive, make_instance
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.setrecursionlimit(10000)

def pruned_search(w, v, cap, use_bound=True, use_weight_prune=True):
    n = len(w)
    order = sorted(range(n), key=lambda i: v[i] / w[i], reverse=True)     # preprocessing: best ratio first
    W = [w[i] for i in order]; V = [v[i] for i in order]
    st = dict(nodes=0, pruned_w=0, pruned_b=0, best=0, bestset=0)
    def bound(k, cw, cv):                                                  # fractional (relaxed) fill of the remaining items
        room = cap - cw; b = cv
        for i in range(k, n):
            if W[i] <= room: room -= W[i]; b += V[i]
            else: return b + V[i] * room / W[i]
        return b
    def rec(k, cw, cv, mask):
        st["nodes"] += 1
        if cw <= cap and cv > st["best"]: st["best"], st["bestset"] = cv, mask
        if k == n: return
        if use_bound and cw <= cap and bound(k, cw, cv) <= st["best"]: st["pruned_b"] += 1; return
        if cw + W[k] <= cap or not use_weight_prune: rec(k + 1, cw + W[k], cv + V[k], mask | 1 << k)   # include (skipped when it would overload)
        else: st["pruned_w"] += 1
        rec(k + 1, cw, cv, mask)                                           # exclude
    rec(0, 0, 0, 0)
    return st["best"], st["nodes"], st["pruned_w"], st["pruned_b"]

def instance(kind, n, seed):
    r = random.Random(seed)
    if kind == "random": return make_instance(n, seed)
    w = [r.randint(10, 60) for _ in range(n)]
    v = [x + 10 for x in w]                                               # strongly correlated (hard) instance
    return w, v, sum(w) // 2

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, "..", "Output_Screenshots")
    print("Correctness: redesign vs original on the Q6 verification instance")
    print("  value (original, redesign):", exhaustive([2,3,4,5,9],[3,4,5,8,10],10)[0], pruned_search([2,3,4,5,9],[3,4,5,8,10],10)[0])
    bad = 0
    for s in range(300):
        r = random.Random(s); n = r.randint(1, 14); w = [r.randint(1, 30) for _ in range(n)]; v = [r.randint(1, 60) for _ in range(n)]; c = r.randint(1, sum(w))
        if exhaustive(w, v, c)[0] != pruned_search(w, v, c)[0]: bad += 1
    print(f"  300 random small instances compared: mismatches = {bad}\n")
    res = []
    print(f"{'type':>11}{'n':>4}{'orig candidates':>17}{'orig time(s)':>14}{'redesign nodes':>16}{'redesign time(s)':>18}{'node reduction':>16}{'speed-up':>10}{'same optimum':>14}")
    for kind in ("random", "correlated"):
        for n in (10, 14, 18, 20, 22):
            w, v, cap = instance(kind, n, 11)
            t = time.perf_counter(); bo, _, cand, _ = exhaustive(w, v, cap); to = time.perf_counter() - t
            t = time.perf_counter(); br, nodes, pw, pb = pruned_search(w, v, cap); tr = time.perf_counter() - t
            res.append(dict(kind=kind, n=n, orig_cand=cand, orig_t=to, nodes=nodes, new_t=tr, pw=pw, pb=pb, ok=bo == br))
            print(f"{kind:>11}{n:>4}{cand:>17,}{to:>14.3f}{nodes:>16,}{tr:>18.4f}{cand/nodes:>15.1f}x{to/max(tr,1e-9):>9.0f}x{str(bo==br):>14}")
    print("\nRedesign only (exhaustive search infeasible): nodes visited and time")
    big = []
    for kind in ("random", "correlated"):
        for n in (30, 40, 50, 60):
            w, v, cap = instance(kind, n, 11)
            t = time.perf_counter(); br, nodes, pw, pb = pruned_search(w, v, cap); tr = time.perf_counter() - t
            big.append(dict(kind=kind, n=n, nodes=nodes, time_s=tr, two_pow=2 ** (n + 1) - 1)); print(f"  {kind:>10} n={n:3d} nodes={nodes:>12,} (2^(n+1)-1 = {2**(n+1)-1:.2e})  time={tr:.3f}s")
    # ablation at n=22 random
    w, v, cap = instance("random", 22, 11)
    print("\nAblation (random, n=22): which idea removes the work?")
    abl = []
    for name, kw in (("full redesign", {}), ("weight pruning only", dict(use_bound=False)), ("bound only (no weight prune)", dict(use_weight_prune=False)), ("no pruning at all", dict(use_bound=False, use_weight_prune=False))):
        best, nodes, pw, pb = pruned_search(w, v, cap, **kw); print(f"  {name:30s} nodes={nodes:>10,} value={best}"); abl.append(dict(name=name, nodes=nodes))
    json.dump({"res": res, "big": big, "ablation": abl}, open(os.path.join(here, "q7_results.json"), "w"), indent=1)
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.4))
    for kind, mk in (("random", "o-"), ("correlated", "s-")):
        rr = [r for r in res if r["kind"] == kind]; ax[0].semilogy([r["n"] for r in rr], [r["nodes"] for r in rr], mk, label=f"redesign nodes ({kind})")
    ax[0].semilogy([r["n"] for r in res[:5]], [r["orig_cand"] for r in res[:5]], "k--", label="original: 2^n candidates"); ax[0].set_xlabel("n"); ax[0].set_ylabel("candidates / nodes"); ax[0].legend(); ax[0].grid(alpha=.3, which="both"); ax[0].set_title("Work: original vs redesign")
    for kind, mk in (("random", "o-"), ("correlated", "s-")):
        bb = [b for b in big if b["kind"] == kind]; ax[1].semilogy([b["n"] for b in bb], [b["nodes"] for b in bb], mk, label=kind)
    ax[1].semilogy([b["n"] for b in big[:4]], [b["two_pow"] for b in big[:4]], "k--", label="2^(n+1)-1"); ax[1].set_xlabel("n"); ax[1].legend(); ax[1].grid(alpha=.3, which="both"); ax[1].set_title("Redesign at sizes exhaustive search cannot reach")
    plt.tight_layout(); plt.savefig(os.path.join(out, "q7_comparison.png"), dpi=130)
