"""Q7 supplementary: how stable is the improvement across many random instances? (robustness check)"""
import os, sys, statistics as st, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from q7_redesign import pruned_search, instance
here = os.path.dirname(os.path.abspath(__file__)); out = {}
print(f"{'type':>11}{'n':>4}{'seeds':>6}{'median nodes':>14}{"max nodes":>14}{"2^(n+1)-1":>20}{"worst reduction":>21}")
for kind, n, seeds in (("random", 22, 40), ("correlated", 22, 40), ("random", 40, 40), ("correlated", 30, 20), ("correlated", 36, 20)):
    nodes = [pruned_search(*instance(kind, n, s))[1] for s in range(seeds)]
    full = 2 ** (n + 1) - 1
    print(f"{kind:>11}{n:>4}{seeds:>6}{st.median(nodes):>14,.0f}{max(nodes):>14,}{full:>20,}{full/max(nodes):>20,.0f}x")
    out[f"{kind}_{n}"] = dict(median=st.median(nodes), max=max(nodes), full=full)
json.dump(out, open(os.path.join(here, "q7_variance.json"), "w"), indent=1)
