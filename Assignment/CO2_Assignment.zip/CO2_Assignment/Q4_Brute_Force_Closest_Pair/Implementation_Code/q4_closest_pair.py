"""Q4 - Brute-force closest pair (drones). Compares squared distances to avoid sqrt."""
import random, time, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def closest_pair(pts):
    best = float("inf"); pair = None; pairs = dist = 0
    n = len(pts)
    for i in range(n - 1):
        for j in range(i + 1, n):        # j > i : each unordered pair examined once
            pairs += 1; dist += 1
            dx = pts[i][0] - pts[j][0]; dy = pts[i][1] - pts[j][1]
            d2 = dx * dx + dy * dy
            if d2 < best: best, pair = d2, (i, j)
    return pair, best ** 0.5, pairs, dist

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, "..", "Output_Screenshots")
    rnd = random.Random(1)
    # correctness check on a small hand-verifiable set
    demo = [(0, 0), (10, 10), (3, 4), (11, 10), (20, 5)]
    print("Demo points:", demo); p, d, c, _ = closest_pair(demo)
    print(f"Closest pair: {demo[p[0]]} & {demo[p[1]]}  distance={d:.3f}  pairs examined={c} (n(n-1)/2 = {5*4//2})\n")
    sizes = [100, 200, 400, 800, 1600, 3200, 6400]
    rows = []
    print(f"{'n':>6}{'pairs examined':>16}{'n(n-1)/2':>14}{'dist calcs':>14}{'time (s)':>10}{'time/pair (ns)':>16}")
    for n in sizes:
        pts = [(rnd.uniform(0, 10000), rnd.uniform(0, 10000)) for _ in range(n)]
        t = time.perf_counter(); p, d, pairs, dist = closest_pair(pts); dt = time.perf_counter() - t
        assert pairs == n * (n - 1) // 2
        print(f"{n:>6}{pairs:>16,}{n*(n-1)//2:>14,}{dist:>14,}{dt:>10.3f}{dt/pairs*1e9:>16.1f}")
        rows.append(dict(n=n, pairs=pairs, dist=dist, time_s=dt))
    # doubling ratios
    print("\nDoubling n: pair ratio / time ratio")
    for a, b in zip(rows, rows[1:]): print(f"  {a['n']}->{b['n']}: pairs x{b['pairs']/a['pairs']:.2f}  time x{b['time_s']/a['time_s']:.2f}")
    # acceptable response time = 1 s ; extrapolate with measured per-pair cost
    k = sum(r["time_s"] for r in rows[-3:]) / sum(r["pairs"] for r in rows[-3:])
    print(f"\nMeasured cost per pair (largest 3 runs): {k*1e9:.1f} ns")
    for T in (1, 5):
        nmax = int(((1 + (1 + 8 * T / k) ** 0.5) / 2))
        print(f"Acceptable response time {T} s -> n_max ~ {nmax:,} drones")
    for n in (10_000, 100_000, 1_000_000):
        print(f"  n={n:>9,}: predicted time = {k*n*(n-1)/2:,.1f} s = {k*n*(n-1)/2/3600:.2f} h")
    json.dump({"rows": rows, "k_ns": k * 1e9}, open(os.path.join(here, "q4_results.json"), "w"), indent=1)
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.3))
    ns = [r["n"] for r in rows]
    ax[0].plot(ns, [r["pairs"] for r in rows], "o-", label="measured pairs"); ax[0].plot(ns, [n * (n - 1) // 2 for n in ns], "x--", label="n(n-1)/2"); ax[0].set_title("Pairs examined vs theory"); ax[0].legend(); ax[0].grid(alpha=.3)
    ax[1].plot(ns, [r["time_s"] for r in rows], "o-"); ax[1].axhline(1, color="r", ls="--", label="1 s limit"); ax[1].set_title("Execution time (s)"); ax[1].legend(); ax[1].grid(alpha=.3)
    for a in ax: a.set_xlabel("n drones")
    plt.tight_layout(); plt.savefig(os.path.join(out, "q4_growth.png"), dpi=130)
