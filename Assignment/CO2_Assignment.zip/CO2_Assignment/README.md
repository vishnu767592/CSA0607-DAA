# CO2 Assignment - CSA06 Design and Analysis of Algorithms
Brute-force and exhaustive-search techniques (Q1-Q7). Each folder holds `Pseudocode/`, `Implementation_Code/` (Python 3 + matplotlib) and `Output_Screenshots/` (captured program output and charts).

| Folder | Topic |
|---|---|
| Q1_Sorting_Algorithms | Selection / Bubble / Insertion sort under different data conditions |
| Q2_Sequential_Search | Sequential search, operating boundary |
| Q3_Brute_Force_String_Matching | Character comparisons vs text/pattern structure |
| Q4_Brute_Force_Closest_Pair | n(n-1)/2 pair examination and scalability |
| Q5_Brute_Force_Convex_Hull | Geometric derivation and visualisation |
| Q6_Exhaustive_Search | Airlift packing, 2^n growth |
| Q7_Day4_Design_Challenge | Diagnose, redesign (pruned search) and validate |
| Final_Report | CO2_Assignment_Report.docx |

Run any experiment: `python3 Qx_*/Implementation_Code/<file>.py` (Q7 needs the Q6 folder). Raw data: `*_results.json` next to each script.
