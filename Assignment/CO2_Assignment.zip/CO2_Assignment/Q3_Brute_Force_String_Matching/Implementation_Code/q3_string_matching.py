"""Q3 - Brute-force string matching with character-comparison counting."""
import json, os, time
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def brute_force(text, pat):
    n, m = len(text), len(pat); comps = 0; hits = []
    for i in range(n - m + 1):
        j = 0
        while j < m:
            comps += 1
            if text[i + j] != pat[j]: break
            j += 1
        if j == m: hits.append(i)
    return hits, comps

def tests(n=10000, m=50):
    return [
        ("A: Best case - first char never matches", "A" * n, "B" + "A" * (m - 1)),
        ("B: Worst case - mismatch only at last char", "A" * n, "A" * (m - 1) + "B"),
        ("C: Realistic log (signature present)", ("INFO user login ok\n" * (n // 19))[:n - 40] + "ALERT: failed password for root\n" * 1 + "x" * 8, "failed password for root"),
        ("D: Random text, binary alphabet", None, None),
    ]

if __name__ == "__main__":
    import random
    here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, "..", "Output_Screenshots")
    n, m = 10000, 50
    cases = []
    for name, t, p in tests(n, m):
        if t is None:
            r = random.Random(5); t = "".join(r.choice("01") for _ in range(n)); p = "".join(r.choice("01") for _ in range(m))
        cases.append((name, t, p))
    res = []
    print(f"{'Test':50}{'n':>7}{'m':>5}{'matches':>9}{'char comps':>12}{'comps/(n-m+1)':>15}{'(n-m+1)*m':>12}")
    for name, t, p in cases:
        hits, c = brute_force(t, p); N = len(t) - len(p) + 1
        print(f"{name:50}{len(t):>7}{len(p):>5}{len(hits):>9}{c:>12,}{c/N:>15.2f}{N*len(p):>12,}")
        res.append(dict(name=name, n=len(t), m=len(p), matches=len(hits), comparisons=c, per_alignment=c / N, bound=N * len(p)))
    # same n, vary m on worst-case to show m dependence; same n&m, different structure
    print("\nSame text length n=10000, worst-case structure, varying pattern length m:")
    vm = []
    for mm in (5, 10, 25, 50, 100, 200):
        _, c = brute_force("A" * n, "A" * (mm - 1) + "B"); vm.append((mm, c)); print(f"  m={mm:4d}  comparisons={c:,}   (n-m+1)*m={(n-mm+1)*mm:,}")
    print("\nSame n=10000 and m=50: comparisons for structure A vs B:", res[0]["comparisons"], "vs", res[1]["comparisons"], f"-> ratio {res[1]['comparisons']/res[0]['comparisons']:.1f}x")
    json.dump({"cases": res, "vary_m": vm}, open(os.path.join(here, "q3_results.json"), "w"), indent=1)
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.3))
    ax[0].bar([c["name"][:1] for c in res], [c["comparisons"] for c in res], color=["#4c78a8", "#e45756", "#54a24b", "#f58518"]); ax[0].set_yscale("log"); ax[0].set_title("Character comparisons (n=10000, m=50)"); ax[0].grid(axis="y", alpha=.3)
    ax[1].plot(*zip(*vm), marker="o"); ax[1].set_xlabel("pattern length m"); ax[1].set_ylabel("comparisons"); ax[1].set_title("Worst-case structure, n=10000"); ax[1].grid(alpha=.3)
    plt.tight_layout(); plt.savefig(os.path.join(out, "q3_comparisons.png"), dpi=130)
