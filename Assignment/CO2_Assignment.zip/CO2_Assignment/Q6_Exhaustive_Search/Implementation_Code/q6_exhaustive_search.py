"""Q6 - Exhaustive search (0/1 selection) for the humanitarian airlift problem.
A candidate is an n-bit mask: bit i = 1 means package i is loaded. All 2^n masks are generated."""
import random, time, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def make_instance(n, seed=11):
    r = random.Random(seed)
    w = [r.randint(5, 40) for _ in range(n)]
    v = [r.randint(10, 100) for _ in range(n)]
    cap = sum(w) // 2                       # payload = half of total weight
    return w, v, cap

def exhaustive(w, v, cap):
    n = len(w); cand = feas = 0; best_v = -1; best_mask = 0; wchecks = 0
    for mask in range(1 << n):              # generate every candidate
        cand += 1
        tw = tv = 0
        for i in range(n):                  # evaluate candidate (n operations)
            if mask >> i & 1:
                tw += w[i]; tv += v[i]
        wchecks += 1
        if tw <= cap:                       # feasibility
            feas += 1
            if tv > best_v: best_v, best_mask = tv, mask   # keep best
    return best_v, best_mask, cand, feas

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, "..", "Output_Screenshots")
    # ---- correctness on a hand-checkable instance ----
    ids = ["P1", "P2", "P3", "P4", "P5"]; w = [2, 3, 4, 5, 9]; v = [3, 4, 5, 8, 10]; cap = 10
    print("Small verification instance (payload limit = 10)")
    for k in range(5): print(f"  {ids[k]}: weight={w[k]} value={v[k]}")
    print("\nAll 2^5 = 32 combinations:\n  mask   packages        weight value feasible")
    rows = []
    for mask in range(32):
        sel = [ids[i] for i in range(5) if mask >> i & 1]; tw = sum(w[i] for i in range(5) if mask >> i & 1); tv = sum(v[i] for i in range(5) if mask >> i & 1)
        rows.append((mask, sel, tw, tv, tw <= cap)); print(f"  {mask:05b}  {','.join(sel) or '(none)':15s}{tw:6d}{tv:6d}   {'yes' if tw<=cap else 'NO'}")
    bv, bm, cand, feas = exhaustive(w, v, cap)
    brute_list = max((r for r in rows if r[4]), key=lambda r: r[3])
    print(f"\nAlgorithm result: value={bv}, packages={[ids[i] for i in range(5) if bm>>i&1]}, candidates={cand}, feasible={feas}")
    print(f"Independent manual table optimum: value={brute_list[3]}, packages={brute_list[1]}  -> agree: {bv == brute_list[3]}\n")
    # ---- growth ----
    print(f"{'n':>3}{'candidates 2^n':>16}{'feasible':>12}{'feasible %':>12}{'best value':>12}{'time (s)':>10}{'time ratio':>12}")
    data = []; prev = None
    for n in range(10, 23, 2):
        w, v, cap = make_instance(n)
        t = time.perf_counter(); bv, bm, cand, feas = exhaustive(w, v, cap); dt = time.perf_counter() - t
        ratio = f"x{dt/prev:.1f}" if prev else "-"
        print(f"{n:>3}{cand:>16,}{feas:>12,}{100*feas/cand:>11.1f}%{bv:>12}{dt:>10.3f}{ratio:>12}")
        data.append(dict(n=n, candidates=cand, feasible=feas, best=bv, time_s=dt)); prev = dt
    k = data[-1]["time_s"] / (data[-1]["candidates"] * data[-1]["n"])   # seconds per candidate-bit
    print(f"\nCost per (candidate x package) bit-operation: {k*1e9:.1f} ns")
    for T in (2, 10, 60):
        n = 1
        while k * (1 << (n + 1)) * (n + 1) <= T: n += 1
        print(f"Response-time limit {T:>3} s -> largest n ~ {n}")
    for n in (30, 40, 50, 60): print(f"  predicted n={n}: {k*(1<<n)*n:,.0f} s = {k*(1<<n)*n/86400/365:,.2f} years")
    json.dump({"data": data, "k_ns": k * 1e9}, open(os.path.join(here, "q6_results.json"), "w"), indent=1)
    plt.figure(figsize=(6.5, 4.5)); plt.semilogy([d["n"] for d in data], [d["time_s"] for d in data], "o-", label="measured time (s)")
    plt.semilogy([d["n"] for d in data], [d["candidates"] / 1e6 for d in data], "x--", label="2^n / 1e6 candidates"); plt.axhline(2, color="r", ls=":", label="2 s limit")
    plt.xlabel("n packages"); plt.legend(); plt.grid(alpha=.3, which="both"); plt.title("Exhaustive search growth"); plt.tight_layout(); plt.savefig(os.path.join(out, "q6_growth.png"), dpi=130)
