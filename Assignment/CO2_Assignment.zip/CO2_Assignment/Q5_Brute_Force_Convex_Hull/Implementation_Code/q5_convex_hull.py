"""Q5 - Brute-force convex hull derived from the 'all other points on one side of the line' principle.
Line through P1=(x1,y1), P2=(x2,y2):  a*x + b*y = c   with a=y2-y1, b=x1-x2, c=x1*y2-y1*x2
Side of P=(x,y):  s = a*x + b*y - c   (s>0 one side, s<0 other, s=0 on the line)
"""
import math, random, time, json, os
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

def hull(points):
    pts = sorted(set(points)); n = len(pts); tests = 0
    if n < 3: return pts, [], 0
    edges = []
    for i in range(n - 1):
        for j in range(i + 1, n):
            (x1, y1), (x2, y2) = pts[i], pts[j]
            a, b, c = y2 - y1, x1 - x2, x1 * y2 - y1 * x2
            pos = neg = False; ok = True
            for k in range(n):
                if k == i or k == j: continue
                tests += 1
                x, y = pts[k]; s = a * x + b * y - c
                if s > 0: pos = True
                elif s < 0: neg = True
                else:  # collinear: must lie inside segment, otherwise (i,j) is not the extreme pair
                    if not (min(x1, x2) <= x <= max(x1, x2) and min(y1, y2) <= y <= max(y1, y2)): ok = False; break
                if pos and neg: ok = False; break      # early exit: points on both sides -> not a hull edge
            if ok: edges.append((i, j))
    verts = sorted({v for e in edges for v in e})
    cx = sum(pts[v][0] for v in verts) / len(verts); cy = sum(pts[v][1] for v in verts) / len(verts)
    order = sorted(verts, key=lambda v: math.atan2(pts[v][1] - cy, pts[v][0] - cx))
    return [pts[v] for v in order], [(pts[i], pts[j]) for i, j in edges], tests

def hull_full_scan_tests(n):  # worst case without early exit
    return n * (n - 1) // 2 * (n - 2)

def reference_hull(points):  # Andrew monotone chain, independent verifier
    P = sorted(set(points))
    def cross(o, a, b): return (a[0]-o[0])*(b[1]-o[1]) - (a[1]-o[1])*(b[0]-o[0])
    lo = []
    for p in P:
        while len(lo) >= 2 and cross(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    up = []
    for p in reversed(P):
        while len(up) >= 2 and cross(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return set(lo[:-1] + up[:-1])

def plot(ax, pts, h, title):
    ax.scatter(*zip(*pts), s=18, c="#4c78a8", zorder=3, label="stations")
    ring = h + [h[0]]; ax.plot(*zip(*ring), "r-", lw=1.8, zorder=2, label="hull boundary"); ax.scatter(*zip(*h), s=40, c="red", zorder=4)
    ax.set_title(title, fontsize=10); ax.set_aspect("equal"); ax.grid(alpha=.3); ax.legend(fontsize=7)

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__)); out = os.path.join(here, "..", "Output_Screenshots")
    rnd = random.Random(3)
    set1 = [(2, 1), (8, 1), (10, 5), (7, 9), (2, 8), (0, 4), (4, 4), (5, 5), (6, 3), (3, 6), (7, 6), (5, 2)]   # boundary + interior
    # Challenge set: collinear points on edges, duplicate point, interior point on a diagonal
    set2 = [(0, 0), (5, 0), (10, 0), (10, 5), (10, 10), (5, 10), (0, 10), (0, 5), (5, 5), (5, 5), (2, 2), (8, 8), (3, 3)]
    allcol = [(i, 2 * i) for i in range(6)]
    cases = [("Set 1: boundary + interior", set1), ("Set 2: collinear edge points, duplicate, diagonal interior", set2), ("Set 3: all points collinear", allcol)]
    fig, ax = plt.subplots(1, 2, figsize=(11, 5)); results = []
    for k, (name, pts) in enumerate(cases):
        h, edges, tests = hull(pts); ref = reference_hull(pts)
        match = set(h) == ref if len(set(pts)) >= 3 and len(ref) >= 3 else None
        print(f"{name}\n  points={len(set(pts))} (input {len(pts)})  hull vertices={len(h)}  edges accepted={len(edges)}  orientation tests={tests}")
        print(f"  hull (counter-clockwise): {h}\n  matches independent reference (monotone chain): {match}\n")
        results.append(dict(name=name, n=len(set(pts)), hull=len(h), edges=len(edges), tests=tests, match=match))
        if k < 2: plot(ax[k], list(set(pts)), h, name)
    plt.tight_layout(); plt.savefig(os.path.join(out, "q5_hull_visualisation.png"), dpi=130); plt.close()
    # growth
    print(f"{'n':>5}{'hull size':>10}{'side tests (early exit)':>25}{'worst n(n-1)(n-2)/2':>22}{'time (s)':>10}{'verified':>10}")
    grow = []
    for n in (20, 40, 80, 160, 320):
        pts = [(rnd.randint(0, 10**6), rnd.randint(0, 10**6)) for _ in range(n)]
        t = time.perf_counter(); h, e, tests = hull(pts); dt = time.perf_counter() - t
        v = set(h) == reference_hull(pts)
        print(f"{n:>5}{len(h):>10}{tests:>25,}{hull_full_scan_tests(n):>22,}{dt:>10.3f}{str(v):>10}")
        grow.append(dict(n=n, hull=len(h), tests=tests, worst=hull_full_scan_tests(n), time_s=dt, ok=v))
    # worst case for early exit: points on a circle (every pair needs a full scan for hull edges only; others exit late)
    print("\nPoints on a circle (all on hull) - early-exit helps least:")
    circ = []
    for n in (20, 40, 80, 160):
        pts = [(round(10**6 * math.cos(2 * math.pi * i / n)), round(10**6 * math.sin(2 * math.pi * i / n))) for i in range(n)]
        t = time.perf_counter(); h, e, tests = hull(pts); dt = time.perf_counter() - t
        print(f"  n={n:4d} hull={len(h):4d} tests={tests:>10,} worst={hull_full_scan_tests(n):>10,} time={dt:.3f}s"); circ.append(dict(n=n, tests=tests, worst=hull_full_scan_tests(n), time_s=dt))
    json.dump({"cases": results, "growth": grow, "circle": circ}, open(os.path.join(here, "q5_results.json"), "w"), indent=1)
    plt.figure(figsize=(6.5, 4.5)); ns = [g["n"] for g in grow]
    plt.loglog(ns, [g["tests"] for g in grow], "o-", label="measured (random)"); plt.loglog(ns, [g["worst"] for g in grow], "x--", label="n(n-1)(n-2)/2")
    plt.loglog([c["n"] for c in circ], [c["tests"] for c in circ], "s-", label="measured (circle)")
    plt.xlabel("n"); plt.ylabel("orientation (side) tests"); plt.legend(); plt.grid(alpha=.3, which="both"); plt.title("Convex hull work growth"); plt.tight_layout()
    plt.savefig(os.path.join(out, "q5_growth.png"), dpi=130)
